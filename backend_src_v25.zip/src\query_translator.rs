use log::info;
use serde::{Serialize, Deserialize};
use std::collections::HashMap;

/// Maximum Arabic terms to prevent BM25 noise on long queries
const MAX_ARABIC_TERMS: usize = 12;

// ─── Language Detection ───

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[derive(Default)]
pub enum QueryLang {
    Indonesian,
    English,
    Arabic,
    Mixed,
    #[default]
    Unknown,
}

impl std::fmt::Display for QueryLang {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            QueryLang::Indonesian => write!(f, "id"),
            QueryLang::English => write!(f, "en"),
            QueryLang::Arabic => write!(f, "ar"),
            QueryLang::Mixed => write!(f, "mixed"),
            QueryLang::Unknown => write!(f, "unknown"),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum FiqhDomain {
    Ibadah,
    Thaharah,
    Muamalat,
    Munakahat,
    Jinayat,
    Aqidah,
    Tasawuf,
    Tafsir,
    Hadits,
    Akhlak,
    Siyasah,
    UsulFiqh,
    Unknown,
}

impl std::fmt::Display for FiqhDomain {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            FiqhDomain::Ibadah => write!(f, "عبادات"),
            FiqhDomain::Thaharah => write!(f, "طهارة"),
            FiqhDomain::Muamalat => write!(f, "معاملات"),
            FiqhDomain::Munakahat => write!(f, "مناكحات"),
            FiqhDomain::Jinayat => write!(f, "جنايات"),
            FiqhDomain::Aqidah => write!(f, "عقيدة"),
            FiqhDomain::Tasawuf => write!(f, "تصوف"),
            FiqhDomain::Tafsir => write!(f, "تفسير"),
            FiqhDomain::Hadits => write!(f, "حديث"),
            FiqhDomain::Akhlak => write!(f, "أخلاق"),
            FiqhDomain::Siyasah => write!(f, "سياسة شرعية"),
            FiqhDomain::UsulFiqh => write!(f, "أصول الفقه"),
            FiqhDomain::Unknown => write!(f, "عام"),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TranslatedQuery {
    pub original: String,
    pub arabic_terms: Vec<String>,
    pub latin_terms: Vec<String>,
    pub detected_language: QueryLang,
    pub detected_domain: FiqhDomain,
    pub tantivy_query: String,
    pub confidence_note: String,
}

// ─── Main Query Translator ───

pub struct QueryTranslator {
    term_map: HashMap<String, Vec<&'static str>>,
    domain_keywords: HashMap<String, (FiqhDomain, i32)>,
}

impl QueryTranslator {
    pub fn new() -> Self {
        let mut translator = QueryTranslator {
            term_map: HashMap::new(),
            domain_keywords: HashMap::new(),
        };
        translator.build_term_dictionary();
        translator.build_domain_detector();
        translator
    }

    /// Main entry point: translate any query into Arabic search terms
    pub fn translate(&self, raw_query: &str) -> TranslatedQuery {
        let query = raw_query.trim().to_string();
        let detected_language = self.detect_language(&query);
        let detected_domain = self.detect_domain(&query);

        let mut arabic_terms: Vec<String> = Vec::new();
        let mut latin_terms: Vec<String> = Vec::new();

        match detected_language {
            QueryLang::Arabic => {
                // Query is already Arabic — use as-is + strip harakat
                let cleaned = strip_harakat(&query);
                arabic_terms.push(cleaned.clone());
                // Also add individual words for broader search
                for word in cleaned.split_whitespace() {
                    if word.len() > 4 { // skip very short Arabic particles
                        arabic_terms.push(word.to_string());
                    }
                }
            }
            QueryLang::Indonesian | QueryLang::English | QueryLang::Mixed | QueryLang::Unknown => {
                let is_long_query = query.len() > 200;

                if is_long_query {
                    // ═══ LONG QUERY MODE ═══
                    // Extract question sentence(s) to focus search on actual question
                    // Context/description words cause BM25 noise with 20-30+ terms
                    let (question_text, context_text) = extract_question_and_context(&query);

                    info!(
                        "Long query split: question='{}…', context='{}…'",
                        &question_text[..question_text.len().min(80)],
                        &context_text[..context_text.len().min(80)]
                    );

                    // Process question sentence(s) with full single-word + phrase expansion
                    let question_words = tokenize_query(&question_text);
                    for word in &question_words {
                        let lower = word.to_lowercase();
                        if !is_query_stopword(&lower) {
                            latin_terms.push(lower.clone());
                            if let Some(expansions) = self.term_map.get(&lower) {
                                for exp in expansions {
                                    arabic_terms.push(exp.to_string());
                                }
                            } else {
                                // ═══ NOVEL: Morphological root extraction for long queries too ═══
                                let roots = extract_indonesian_roots(&lower);
                                for root in &roots {
                                    if let Some(root_expansions) = self.term_map.get(root) {
                                        for exp in root_expansions {
                                            arabic_terms.push(exp.to_string());
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Phrase expansion on question words
                    let question_phrases = self.expand_phrases(&question_words);
                    for exp in question_phrases {
                        arabic_terms.push(exp);
                    }

                    // From context, extract ONLY phrase matches (no single-word noise)
                    if !context_text.is_empty() {
                        let context_words = tokenize_query(&context_text);
                        let context_phrases = self.expand_phrases(&context_words);
                        for exp in context_phrases {
                            arabic_terms.push(exp);
                        }
                    }

                    // Also run phrase expansion on FULL query to catch cross-sentence phrases
                    let all_words = tokenize_query(&query);
                    let full_phrases = self.expand_phrases(&all_words);
                    for exp in full_phrases {
                        arabic_terms.push(exp);
                    }

                    // ═══ NOVEL: Query Intent Pattern Detection for long queries ═══
                    let intent_expansions = detect_query_intent_patterns(&all_words);
                    for exp in intent_expansions {
                        arabic_terms.push(exp);
                    }
                } else {
                    // ═══ SHORT QUERY MODE (enhanced with morphological root extraction) ═══
                    let words = tokenize_query(&query);
                    for word in &words {
                        let lower = word.to_lowercase();
                        latin_terms.push(lower.clone());

                        // Check single-word expansion
                        if let Some(expansions) = self.term_map.get(&lower) {
                            for exp in expansions {
                                arabic_terms.push(exp.to_string());
                            }
                        } else if !is_query_stopword(&lower) {
                            // ═══ NOVEL: Indonesian Morphological Root Extraction ═══
                            // If the word isn't in the dictionary, try extracting
                            // its root by stripping Indonesian affixes.
                            // e.g., "membatalkan" → "batal" → found! → بطلان/باطل
                            let roots = extract_indonesian_roots(&lower);
                            for root in &roots {
                                if let Some(root_expansions) = self.term_map.get(root) {
                                    for exp in root_expansions {
                                        arabic_terms.push(exp.to_string());
                                    }
                                }
                            }
                        }
                    }

                    // Check multi-word phrases (bigrams, trigrams)
                    let phrase_expansions = self.expand_phrases(&words);
                    for exp in phrase_expansions {
                        arabic_terms.push(exp);
                    }

                    // ═══ NOVEL: Query Intent Pattern Detection ═══
                    // Detect semantic patterns like "membatalkan X" → مبطلات
                    let intent_expansions = detect_query_intent_patterns(&words);
                    for exp in intent_expansions {
                        arabic_terms.push(exp);
                    }
                }

                // If no Arabic terms found, try the full query as-is
                if arabic_terms.is_empty() {
                    latin_terms.push(query.clone());
                }
            }
        }

        // Deduplicate
        arabic_terms.sort();
        arabic_terms.dedup();
        latin_terms.sort();
        latin_terms.dedup();

        // ═══ TERM LIMITING ═══
        // Cap Arabic terms to prevent BM25 noise (especially for long queries)
        // Prioritize: multi-word phrases > longer singles > shorter singles
        // Longer Arabic words are more discriminative (e.g., الاستحاضة > حج)
        if arabic_terms.len() > MAX_ARABIC_TERMS {
            let phrases: Vec<String> = arabic_terms.iter()
                .filter(|t| t.contains(' '))
                .cloned()
                .collect();
            let mut singles: Vec<String> = arabic_terms.iter()
                .filter(|t| !t.contains(' '))
                .cloned()
                .collect();
            // Sort singles by char count descending — longer = more specific
            singles.sort_by(|a, b| b.chars().count().cmp(&a.chars().count()));
            arabic_terms.clear();
            // Keep all phrases first (up to limit)
            for p in phrases.into_iter().take(MAX_ARABIC_TERMS) {
                arabic_terms.push(p);
            }
            // Fill remaining slots with longest single-word terms
            let remaining = MAX_ARABIC_TERMS.saturating_sub(arabic_terms.len());
            for s in singles.into_iter().take(remaining) {
                arabic_terms.push(s);
            }
            info!("Arabic terms capped to {} (was over limit)", arabic_terms.len());
        }

        // Build Tantivy query string
        let tantivy_query = self.build_tantivy_query(&arabic_terms, &latin_terms);

        let confidence_note = if arabic_terms.is_empty() && detected_language != QueryLang::Arabic {
            "لم يتم العثور على مصطلحات عربية مطابقة. سيتم البحث بالنص الأصلي.".to_string()
        } else if arabic_terms.len() > 5 {
            "تم توسيع البحث إلى عدة مصطلحات عربية لتغطية أشمل.".to_string()
        } else {
            String::new()
        };

        info!(
            "Query translated: '{}' → lang={}, domain={}, arabic_terms={:?}, tantivy='{}'",
            query, detected_language, detected_domain, arabic_terms, tantivy_query
        );

        TranslatedQuery {
            original: query,
            arabic_terms,
            latin_terms,
            detected_language,
            detected_domain,
            tantivy_query,
            confidence_note,
        }
    }

    /// Translate with configuration flags for ablation study
    /// Allows disabling phrase mapping and/or multi-variant expansion
    pub fn translate_with_config(
        &self,
        raw_query: &str,
        enable_phrases: bool,
        enable_multi_variant: bool,
    ) -> TranslatedQuery {
        let query = raw_query.trim().to_string();
        let detected_language = self.detect_language(&query);
        let detected_domain = self.detect_domain(&query);

        let mut arabic_terms: Vec<String> = Vec::new();
        let mut latin_terms: Vec<String> = Vec::new();

        match detected_language {
            QueryLang::Arabic => {
                let cleaned = strip_harakat(&query);
                arabic_terms.push(cleaned.clone());
                for word in cleaned.split_whitespace() {
                    if word.len() > 4 {
                        arabic_terms.push(word.to_string());
                    }
                }
            }
            _ => {
                let words = tokenize_query(&query);
                for word in &words {
                    let lower = word.to_lowercase();
                    latin_terms.push(lower.clone());

                    if let Some(expansions) = self.term_map.get(&lower) {
                        if enable_multi_variant {
                            // Normal: add all variants
                            for exp in expansions {
                                arabic_terms.push(exp.to_string());
                            }
                        } else {
                            // Ablation: only first variant (single mapping)
                            if let Some(first) = expansions.first() {
                                arabic_terms.push(first.to_string());
                            }
                        }
                    }
                }

                // Phrase expansion (can be disabled)
                if enable_phrases {
                    let phrase_expansions = self.expand_phrases(&words);
                    for exp in phrase_expansions {
                        arabic_terms.push(exp);
                    }
                }

                if arabic_terms.is_empty() {
                    latin_terms.push(query.clone());
                }
            }
        }

        arabic_terms.sort();
        arabic_terms.dedup();
        latin_terms.sort();
        latin_terms.dedup();

        // Apply term limiting (same strategy as translate())
        if arabic_terms.len() > MAX_ARABIC_TERMS {
            let phrases: Vec<String> = arabic_terms.iter()
                .filter(|t| t.contains(' '))
                .cloned()
                .collect();
            let mut singles: Vec<String> = arabic_terms.iter()
                .filter(|t| !t.contains(' '))
                .cloned()
                .collect();
            singles.sort_by(|a, b| b.chars().count().cmp(&a.chars().count()));
            arabic_terms.clear();
            for p in phrases.into_iter().take(MAX_ARABIC_TERMS) {
                arabic_terms.push(p);
            }
            let remaining = MAX_ARABIC_TERMS.saturating_sub(arabic_terms.len());
            for s in singles.into_iter().take(remaining) {
                arabic_terms.push(s);
            }
        }

        let tantivy_query = self.build_tantivy_query(&arabic_terms, &latin_terms);
        let confidence_note = String::new();

        TranslatedQuery {
            original: query,
            arabic_terms,
            latin_terms,
            detected_language,
            detected_domain,
            tantivy_query,
            confidence_note,
        }
    }

    /// Public wrapper for build_tantivy_query — used by search.rs for stemmer expansion
    pub fn build_tantivy_query_from_terms(&self, arabic_terms: &[String], latin_terms: &[String]) -> String {
        self.build_tantivy_query(arabic_terms, latin_terms)
    }

    // ─── Language Detection ───

    fn detect_language(&self, query: &str) -> QueryLang {
        let mut arabic_chars = 0u32;
        let mut latin_chars = 0u32;
        let mut total_chars = 0u32;

        for c in query.chars() {
            if c.is_whitespace() || c.is_ascii_punctuation() {
                continue;
            }
            total_chars += 1;
            if is_arabic_char(c) {
                arabic_chars += 1;
            } else if c.is_ascii_alphabetic() {
                latin_chars += 1;
            }
        }

        if total_chars == 0 {
            return QueryLang::Unknown;
        }

        let arabic_ratio = arabic_chars as f32 / total_chars as f32;
        let latin_ratio = latin_chars as f32 / total_chars as f32;

        if arabic_ratio > 0.7 {
            QueryLang::Arabic
        } else if arabic_ratio > 0.2 && latin_ratio > 0.2 {
            QueryLang::Mixed
        } else if latin_ratio > 0.5 {
            // Distinguish Indonesian from English
            let lower = query.to_lowercase();
            let indonesian_markers = [
                "apa", "bagaimana", "apakah", "boleh", "hukum", "gak", "gk", "ga",
                "tidak", "bisa", "kalau", "bolehkah", "gimana", "kenapa", "mengapa",
                "siapa", "kapan", "dari", "untuk", "yang", "atau", "dan", "dengan",
                "dalam", "jika", "ketika", "saat", "tentang", "mengenai",
                "shalat", "solat", "wudhu", "puasa", "zakat", "haji", "nikah",
                "cerai", "talak", "riba", "waris", "masjid", "imam",
            ];
            let english_markers = [
                "what", "how", "is", "can", "the", "does", "should", "must",
                "when", "where", "which", "why", "about", "prayer", "fasting",
                "marriage", "divorce", "ruling", "permissible", "forbidden",
                "allowed", "halal", "haram", "islamic", "sharia",
            ];

            let id_score: i32 = indonesian_markers
                .iter()
                .filter(|m| lower.contains(**m))
                .count() as i32;
            let en_score: i32 = english_markers
                .iter()
                .filter(|m| lower.contains(**m))
                .count() as i32;

            if id_score > en_score {
                QueryLang::Indonesian
            } else if en_score > id_score {
                QueryLang::English
            } else {
                // Check for common Indonesian patterns
                if lower.contains("nya") || lower.contains("kah") || lower.contains("lah") {
                    QueryLang::Indonesian
                } else {
                    QueryLang::Indonesian // Default to Indonesian for Islamic context
                }
            }
        } else {
            QueryLang::Unknown
        }
    }

    // ─── Domain Detection ───

    fn detect_domain(&self, query: &str) -> FiqhDomain {
        let lower = query.to_lowercase();
        let mut domain_scores: HashMap<&str, i32> = HashMap::new();

        for (keyword, (domain, weight)) in &self.domain_keywords {
            if lower.contains(keyword.as_str()) {
                let domain_key = match domain {
                    FiqhDomain::Ibadah => "ibadah",
                    FiqhDomain::Thaharah => "thaharah",
                    FiqhDomain::Muamalat => "muamalat",
                    FiqhDomain::Munakahat => "munakahat",
                    FiqhDomain::Jinayat => "jinayat",
                    FiqhDomain::Aqidah => "aqidah",
                    FiqhDomain::Tasawuf => "tasawuf",
                    FiqhDomain::Tafsir => "tafsir",
                    FiqhDomain::Hadits => "hadits",
                    FiqhDomain::Akhlak => "akhlak",
                    FiqhDomain::Siyasah => "siyasah",
                    FiqhDomain::UsulFiqh => "usulfiqh",
                    FiqhDomain::Unknown => "unknown",
                };
                *domain_scores.entry(domain_key).or_default() += weight;
            }
        }

        // Also check Arabic text directly
        let arabic_domain_markers: Vec<(&str, &str)> = vec![
            ("صلاة", "ibadah"), ("صلوات", "ibadah"), ("صوم", "ibadah"), ("صيام", "ibadah"),
            ("زكاة", "ibadah"), ("حج", "ibadah"), ("عمرة", "ibadah"), ("أذان", "ibadah"),
            ("طهارة", "thaharah"), ("وضوء", "thaharah"), ("غسل", "thaharah"), ("نجاسة", "thaharah"),
            ("حيض", "thaharah"), ("جنابة", "thaharah"), ("تيمم", "thaharah"),
            ("بيع", "muamalat"), ("ربا", "muamalat"), ("إجارة", "muamalat"), ("رهن", "muamalat"),
            ("شركة", "muamalat"), ("وقف", "muamalat"), ("هبة", "muamalat"),
            ("نكاح", "munakahat"), ("طلاق", "munakahat"), ("خلع", "munakahat"),
            ("عدة", "munakahat"), ("نفقة", "munakahat"), ("مهر", "munakahat"),
            ("حد", "jinayat"), ("قصاص", "jinayat"), ("تعزير", "jinayat"), ("سرقة", "jinayat"),
            ("توحيد", "aqidah"), ("إيمان", "aqidah"), ("شرك", "aqidah"), ("كفر", "aqidah"),
            ("بدعة", "aqidah"), ("ردة", "aqidah"),
            ("تفسير", "tafsir"), ("تأويل", "tafsir"), ("آية", "tafsir"),
            ("حديث", "hadits"), ("سنة", "hadits"), ("رواية", "hadits"), ("إسناد", "hadits"),
            ("قياس", "usulfiqh"), ("إجماع", "usulfiqh"), ("اجتهاد", "usulfiqh"),
            ("استحسان", "usulfiqh"), ("استصحاب", "usulfiqh"), ("مقاصد", "usulfiqh"),
            ("نسخ", "usulfiqh"), ("علة", "usulfiqh"), ("مصلحة", "usulfiqh"),
        ];

        for (marker, domain_key) in &arabic_domain_markers {
            if query.contains(marker) {
                *domain_scores.entry(domain_key).or_default() += 2; // Arabic matches get higher weight
            }
        }

        if let Some((top_domain, _)) = domain_scores.iter().max_by_key(|(_, &v)| v) {
            match *top_domain {
                "ibadah" => FiqhDomain::Ibadah,
                "thaharah" => FiqhDomain::Thaharah,
                "muamalat" => FiqhDomain::Muamalat,
                "munakahat" => FiqhDomain::Munakahat,
                "jinayat" => FiqhDomain::Jinayat,
                "aqidah" => FiqhDomain::Aqidah,
                "tasawuf" => FiqhDomain::Tasawuf,
                "tafsir" => FiqhDomain::Tafsir,
                "hadits" => FiqhDomain::Hadits,
                "akhlak" => FiqhDomain::Akhlak,
                "siyasah" => FiqhDomain::Siyasah,
                "usulfiqh" => FiqhDomain::UsulFiqh,
                _ => FiqhDomain::Unknown,
            }
        } else {
            FiqhDomain::Unknown
        }
    }

    // ─── Multi-word Phrase Expansion ───

    fn expand_phrases(&self, words: &[String]) -> Vec<String> {
        let mut expansions = Vec::new();
        let lower_words: Vec<String> = words.iter().map(|w| w.to_lowercase()).collect();

        // Define multi-word phrase mappings
        let phrase_map: Vec<(&[&str], Vec<&str>)> = vec![
            // Ibadah phrases
            (&["shalat", "jumat"], vec!["صلاة الجمعة", "الجمعة"]),
            (&["solat", "jumat"], vec!["صلاة الجمعة", "الجمعة"]),
            (&["sholat", "jumat"], vec!["صلاة الجمعة", "الجمعة"]),
            (&["sholat", "jumaat"], vec!["صلاة الجمعة", "الجمعة"]),
            (&["sholat", "jum'at"], vec!["صلاة الجمعة", "الجمعة"]),
            (&["shalat", "jum'at"], vec!["صلاة الجمعة", "الجمعة"]),
            (&["salat", "jumat"], vec!["صلاة الجمعة", "الجمعة"]),
            (&["friday", "prayer"], vec!["صلاة الجمعة", "الجمعة"]),
            (&["shalat", "jamak"], vec!["الجمع بين الصلاتين", "جمع الصلاة"]),
            (&["shalat", "qashar"], vec!["قصر الصلاة", "القصر"]),
            (&["shalat", "qasar"], vec!["قصر الصلاة", "القصر"]),
            (&["shalat", "jenazah"], vec!["صلاة الجنازة", "الجنازة"]),
            (&["shalat", "janazah"], vec!["صلاة الجنازة", "الجنازة"]),
            (&["shalat", "tarawih"], vec!["صلاة التراويح", "التراويح"]),
            (&["shalat", "tahajjud"], vec!["صلاة التهجد", "التهجد", "قيام الليل"]),
            (&["shalat", "istikharah"], vec!["صلاة الاستخارة", "الاستخارة"]),
            (&["shalat", "dhuha"], vec!["صلاة الضحى", "الضحى"]),
            (&["shalat", "witir"], vec!["صلاة الوتر", "الوتر"]),
            (&["shalat", "ied"], vec!["صلاة العيد", "صلاة العيدين"]),
            (&["shalat", "id"], vec!["صلاة العيد", "صلاة العيدين"]),
            (&["shalat", "gerhana"], vec!["صلاة الكسوف", "صلاة الخسوف"]),
            (&["shalat", "istisqa"], vec!["صلاة الاستسقاء"]),
            (&["shalat", "sambil"], vec!["الصلاة", "حمل"]), // contextual - shalat sambil [doing something]
            
            // Thaharah phrases
            (&["hadats", "besar"], vec!["الحدث الأكبر", "جنابة", "الجنابة"]),
            (&["hadats", "kecil"], vec!["الحدث الأصغر"]),
            (&["air", "kencing"], vec!["بول", "البول"]),
            (&["air", "seni"], vec!["بول", "البول"]),
            (&["air", "mani"], vec!["مني", "المني"]),
            (&["batal", "wudhu"], vec!["نواقض الوضوء", "ينقض الوضوء"]),
            (&["batal", "wudu"], vec!["نواقض الوضوء", "ينقض الوضوء"]),
            (&["membatalkan", "wudhu"], vec!["نواقض الوضوء", "ينقض الوضوء"]),
            
            // Nikah phrases
            (&["nikah", "siri"], vec!["نكاح سري", "نكاح بغير ولي", "نكاح بغير شهود"]),
            (&["nikah", "sirri"], vec!["نكاح سري", "نكاح بغير ولي", "نكاح بغير شهود"]),
            (&["nikah", "mut'ah"], vec!["نكاح المتعة", "المتعة"]),
            (&["nikah", "mutah"], vec!["نكاح المتعة", "المتعة"]),
            (&["wali", "nikah"], vec!["ولي النكاح", "الولي في النكاح", "ولاية النكاح"]),
            (&["saksi", "nikah"], vec!["شهود النكاح", "الشهادة في النكاح"]),
            (&["mas", "kawin"], vec!["مهر", "الصداق", "المهر"]),
            (&["cerai", "gugat"], vec!["خلع", "الخلع"]),
            
            // Muamalat phrases
            (&["jual", "beli"], vec!["بيع", "البيع", "المعاملات"]),
            (&["bunga", "bank"], vec!["ربا", "الربا", "الفائدة"]),
            (&["bagi", "hasil"], vec!["مضاربة", "المضاربة"]),
            (&["utang", "piutang"], vec!["دين", "الدين", "القرض"]),
            (&["gadai", "emas"], vec!["رهن الذهب", "رهن"]),
            (&["asuransi", "syariah"], vec!["التأمين", "تكافل", "التأمين التكافلي"]),
            
            // Aqidah phrases
            (&["qadha", "qadar"], vec!["قضاء وقدر", "القضاء والقدر"]),
            (&["qada", "qadar"], vec!["قضاء وقدر", "القضاء والقدر"]),
            (&["makhluk", "hidup"], vec!["ذوات الأرواح", "تصوير"]),
            (&["hari", "kiamat"], vec!["يوم القيامة", "الساعة", "الآخرة"]),
            (&["hari", "akhir"], vec!["اليوم الآخر", "الآخرة"]),
            (&["azab", "kubur"], vec!["عذاب القبر"]),
            
            // Hadits phrases
            (&["hadits", "sahih"], vec!["حديث صحيح", "الصحيح"]),
            (&["hadits", "dhaif"], vec!["حديث ضعيف", "الضعيف"]),
            (&["hadits", "hasan"], vec!["حديث حسن"]),
            (&["hadits", "maudhu"], vec!["حديث موضوع", "الموضوع"]),
            
            // Misc phrases
            (&["hukum", "foto"], vec!["تصوير", "التصوير", "ذوات الأرواح"]),
            (&["hukum", "gambar"], vec!["تصوير", "التصوير", "ذوات الأرواح"]),
            (&["hukum", "musik"], vec!["الغناء", "المعازف", "الموسيقى"]),
            (&["hukum", "rokok"], vec!["التدخين", "الدخان"]),
            (&["hukum", "vaksin"], vec!["التطعيم", "اللقاح"]),
            (&["hukum", "tato"], vec!["الوشم"]),
            (&["hukum", "merokok"], vec!["التدخين", "الدخان"]),
            (&["makanan", "haram"], vec!["المحرمات من الطعام", "الأطعمة المحرمة"]),
            (&["binatang", "haram"], vec!["الحيوانات المحرمة", "حرمة الأكل"]),

            // ═══ HEALTH / SICKNESS PHRASES ═══
            (&["puasa", "sakit"], vec!["إفطار المريض", "صيام المريض", "فطر المريض", "رخصة الإفطار"]),
            (&["boleh", "puasa"], vec!["جواز الصيام", "هل يجوز الصيام"]),
            (&["tidak", "puasa"], vec!["إفطار", "ترك الصيام", "رخصة الإفطار"]),
            (&["sakit", "puasa"], vec!["إفطار المريض", "الصيام والمرض"]),
            (&["puasa", "tidak", "boleh"], vec!["رخصة الإفطار", "إفطار", "الأعذار المبيحة للفطر"]),
            (&["darurat", "puasa"], vec!["الضرورة والصيام", "إفطار الاضطرار"]),
            (&["sakit", "shalat"], vec!["صلاة المريض", "كيفية صلاة المريض", "رخص الصلاة"]),
            (&["tidak", "shalat"], vec!["ترك الصلاة", "السقوط عن الصلاة"]),
            (&["hamil", "puasa"], vec!["صيام الحامل", "إفطار الحامل"]),
            (&["menyusui", "puasa"], vec!["صيام المرضع", "إفطار المرضع"]),
            (&["musafir", "puasa"], vec!["إفطار المسافر", "صيام المسافر"]),
            (&["safar", "puasa"], vec!["إفطار المسافر", "قصر الصيام"]),

            // ═══ MARRIAGE/DIVORCE PHRASES ═══
            (&["suami", "impoten"], vec!["العيوب في النكاح", "عنة الزوج", "العنين", "الفسخ بالعيب"]),
            (&["istri", "cerai"], vec!["خلع", "طلب الطلاق", "شقاق", "الخلع"]),
            (&["istri", "minta", "cerai"], vec!["خلع", "طلب الطلاق من الزوجة", "الشقاق"]),
            (&["cerai", "impoten"], vec!["فسخ النكاح بالعيب", "العنة", "خيار العيب"]),
            (&["cerai", "suami"], vec!["طلاق", "طلب الطلاق", "الخلع"]),
            (&["perceraian", "pengadilan"], vec!["الطلاق القضائي", "حكم القاضي بالطلاق"]),
            (&["suami", "tidak", "mau", "cerai"], vec!["امتناع الزوج من الطلاق", "الشقاق", "التفريق القضائي"]),

            // ═══ WARIS (INHERITANCE) PHRASES ═══
            (&["waris", "anak", "perempuan"], vec!["ميراث البنت", "نصيب البنت", "ميراث البنات", "فرض البنت"]),
            (&["waris", "perempuan"], vec!["ميراث البنت", "ميراث النساء", "نصيب البنت", "ميراث البنات"]),
            (&["waris", "anak"], vec!["ميراث الأولاد", "ميراث الولد", "نصيب الأولاد"]),
            (&["anak", "perempuan"], vec!["بنت", "البنت", "البنات"]),
            (&["bagian", "waris"], vec!["الفرائض", "فروض الإرث", "أصحاب الفروض"]),

            // ═══ QUNUT & PRAYER TIME PHRASES ═══
            (&["qunut", "subuh"], vec!["قنوت الفجر", "القنوت في صلاة الصبح", "قنوت الصبح"]),
            (&["qunut", "fajar"], vec!["قنوت الفجر", "القنوت في صلاة الفجر"]),
            (&["qunut", "witir"], vec!["قنوت الوتر", "دعاء قنوت الوتر"]),
            (&["qunut", "witr"], vec!["قنوت الوتر", "دعاء قنوت الوتر"]),
            (&["doa", "qunut"], vec!["دعاء القنوت", "القنوت"]),
            (&["shalat", "subuh"], vec!["صلاة الفجر", "صلاة الصبح"]),
            (&["shalat", "dzuhur"], vec!["صلاة الظهر", "الظهر"]),
            (&["shalat", "ashar"], vec!["صلاة العصر", "العصر"]),
            (&["shalat", "maghrib"], vec!["صلاة المغرب", "المغرب"]),
            (&["shalat", "isya"], vec!["صلاة العشاء", "العشاء"]),

            // ═══ GELATIN & FOOD PHRASES ═══
            (&["gelatin", "babi"], vec!["الجيلاتين من الخنزير", "الاستحالة", "التداوي بالمحرم", "حكم الجيلاتين"]),
            (&["makan", "gelatin"], vec!["أكل الجيلاتين", "حكم الجيلاتين"]),
            (&["makan", "babi"], vec!["أكل لحم الخنزير", "حرمة أكل الخنزير"]),
            (&["makan", "haram"], vec!["المحرمات من الطعام", "الأطعمة المحرمة"]),

            // ═══ BANK/FINANCE PHRASES ═══
            (&["bank", "konvensional"], vec!["البنوك الربوية", "الفائدة المصرفية", "فائدة البنك", "التعامل مع البنوك"]),
            (&["bank", "syariah"], vec!["البنوك الإسلامية", "المصارف الإسلامية"]),
            (&["riba", "bank"], vec!["ربا البنوك", "فائدة البنك", "الربا المصرفي"]),

            // ═══ PHOTO/VISUAL MEDIA PHRASES ═══
            (&["foto", "makhluk"], vec!["تصوير ذوات الأرواح", "حكم التصوير", "المصوِّر"]),
            (&["foto", "hidup"], vec!["تصوير ذوات الأرواح", "صور الأحياء"]),
            (&["gambar", "makhluk"], vec!["تصوير ذوات الأرواح", "رسم ذوات الأرواح"]),
            (&["selfie", "hukum"], vec!["تصوير", "التصوير الفوتوغرافي"]),
            
            // English phrases
            (&["friday", "prayer"], vec!["صلاة الجمعة", "الجمعة"]),
            (&["night", "prayer"], vec!["قيام الليل", "صلاة التهجد"]),
            (&["funeral", "prayer"], vec!["صلاة الجنازة"]),
            (&["marriage", "contract"], vec!["عقد النكاح", "النكاح"]),
            (&["breast", "feeding"], vec!["الرضاعة", "رضاع"]),
            (&["breast", "milk"], vec!["الرضاعة", "حكم الرضاع"]),
            (&["interest", "rate"], vec!["ربا", "الربا", "الفائدة"]),
            (&["islamic", "finance"], vec!["المعاملات المالية", "الاقتصاد الإسلامي"]),
            (&["menstrual", "blood"], vec!["دم الحيض", "الحيض"]),

            // ═══ ADDITIONAL INDONESIAN PHRASES ═══
            (&["shalat", "rakaat"], vec!["ركعات الصلاة", "عدد الركعات"]),
            (&["shalat", "rakat"], vec!["ركعات الصلاة", "عدد الركعات"]),
            (&["shalat", "berapa"], vec!["ركعات الصلاة", "عدد الركعات"]),
            (&["shalat", "mati"], vec!["صلاة الجنازة", "الصلاة على الميت"]),
            (&["shalat", "mayit"], vec!["صلاة الجنازة", "الصلاة على الميت"]),
            (&["shalat", "sakit"], vec!["صلاة المريض", "كيفية صلاة المريض"]),
            (&["shalat", "duduk"], vec!["صلاة القاعد", "الصلاة جالسا"]),
            (&["tata", "cara"], vec![]), // generic modifier, no expansion needed
            (&["hukum", "merokok"], vec!["حكم التدخين", "التدخين"]),
            (&["hukum", "musik"], vec!["حكم الغناء", "المعازف", "الموسيقى"]),
            (&["hukum", "foto"], vec!["حكم التصوير", "تصوير ذوات الأرواح"]),
            (&["hukum", "rokok"], vec!["حكم التدخين", "التدخين"]),
            (&["hukum", "mati"], vec!["حكم الموت", "الاحتضار", "أحكام الميت"]),
            (&["orang", "mati"], vec!["أحكام الميت", "الجنازة", "تغسيل الميت"]),
            (&["orang", "meninggal"], vec!["أحكام الميت", "الجنازة", "تغسيل الميت"]),
            (&["suami", "istri"], vec!["الزوج والزوجة", "حقوق الزوجين", "العشرة بين الزوجين"]),
            (&["hak", "istri"], vec!["حقوق الزوجة", "النفقة", "حق الزوجة"]),
            (&["hak", "suami"], vec!["حقوق الزوج", "حق الزوج", "طاعة الزوج"]),
            // Kafarat / sumpah / nadzar
            (&["kafarat", "sumpah"], vec!["كفارة اليمين", "كفارة الأيمان"]),
            (&["kaffarah", "sumpah"], vec!["كفارة اليمين", "كفارة الأيمان"]),
            (&["sumpah", "palsu"], vec!["اليمين الغموس", "اليمين الكاذبة"]),
            (&["sumpah", "bohong"], vec!["اليمين الغموس", "اليمين الكاذبة"]),
            (&["hukum", "sumpah"], vec!["حكم اليمين", "أحكام الأيمان"]),
            (&["kafarat", "puasa"], vec!["كفارة الصيام", "كفارة الإفطار"]),
            (&["nadzar", "hukum"], vec!["حكم النذر", "أحكام النذور"]),

            // ═══ MISSING PHRASES (added v8) ═══
            (&["ahli", "kitab"], vec!["أهل الكتاب", "ذبائح أهل الكتاب"]),
            (&["sembelihan", "ahli"], vec!["ذبائح أهل الكتاب", "ذبيحة الكتابي"]),
            (&["sembelihan", "kitab"], vec!["ذبائح أهل الكتاب", "أكل ذبيحة الكتابي"]),
            (&["daging", "ular"], vec!["أكل لحم الحية", "حكم أكل الحيات", "الحشرات"]),
            (&["daging", "babi"], vec!["لحم الخنزير", "أكل لحم الخنزير"]),
            (&["daging", "haram"], vec!["اللحوم المحرمة", "حرمة الأكل"]),
            (&["ibu", "hamil"], vec!["الحامل", "المرأة الحامل"]),
            (&["puasa", "hamil"], vec!["صيام الحامل", "إفطار الحامل", "حكم صوم الحامل"]),
            (&["puasa", "ramadhan"], vec!["صيام رمضان", "صوم رمضان"]),
            (&["puasa", "ramadan"], vec!["صيام رمضان", "صوم رمضان"]),
            (&["zakat", "mal"], vec!["زكاة المال", "نصاب المال", "حول الزكاة"]),
            (&["zakat", "emas"], vec!["زكاة الذهب", "نصاب الذهب"]),
            (&["zakat", "fitrah"], vec!["زكاة الفطر", "صدقة الفطر"]),
            (&["nisab", "zakat"], vec!["نصاب الزكاة", "نصاب المال"]),
            (&["nisab", "haul"], vec!["النصاب والحول", "شروط الزكاة"]),
            (&["jual", "online"], vec!["البيع عبر الإنترنت", "البيع الإلكتروني", "بيع المعاطاة"]),
            (&["beli", "online"], vec!["الشراء عبر الإنترنت", "البيع الإلكتروني"]),
            (&["gadai", "pegadaian"], vec!["الرهن", "رهن", "أحكام الرهن"]),
            (&["nikah", "tanpa"], vec!["نكاح بغير", "النكاح بدون ولي"]),
            (&["tanpa", "wali"], vec!["بغير ولي", "بدون ولي"]),
            (&["vaksin", "haram"], vec!["اللقاح المحرم", "التطعيم بالمحرم", "الاضطرار"]),
            (&["bahan", "haram"], vec!["المواد المحرمة", "الاستحالة", "التداوي بالمحرم"]),
            (&["tawakal", "allah"], vec!["التوكل على الله", "حقيقة التوكل"]),
            (&["tawakkal", "allah"], vec!["التوكل على الله", "حقيقة التوكل"]),
            (&["pegang", "bayi"], vec!["حمل الطفل", "حمل الصبي في الصلاة"]),
            (&["shalat", "pegang"], vec!["حمل في الصلاة", "حمل الطفل في الصلاة"]),
            (&["musik", "nyanyian"], vec!["الغناء والمعازف", "حكم الغناء", "حكم المعازف"]),
            (&["mencuri", "islam"], vec!["السرقة في الإسلام", "حد السرقة", "حكم السرقة"]),

            // ═══ v10: LONG QUERY FIX — missing phrases ═══
            // Wudhu + bandage (Q5 fix)
            (&["wudhu", "perban"], vec!["المسح على الجبيرة", "الجبيرة", "أحكام الجبائر"]),
            (&["wudu", "perban"], vec!["المسح على الجبيرة", "الجبيرة", "أحكام الجبائر"]),
            (&["perban", "shalat"], vec!["المسح على الجبيرة", "الجبيرة"]),
            (&["perban", "kaki"], vec!["المسح على الجبيرة", "الجبيرة"]),
            (&["masah", "perban"], vec!["المسح على الجبيرة", "الجبيرة"]),
            (&["masah", "jabira"], vec!["المسح على الجبيرة", "الجبيرة"]),
            // Talak + anger (Q7 fix)
            (&["talak", "marah"], vec!["طلاق الغضبان", "الطلاق في الغضب", "الغضب"]),
            (&["talak", "emosi"], vec!["طلاق الغضبان", "الطلاق في الغضب", "الغضب"]),
            (&["cerai", "marah"], vec!["طلاق الغضبان", "الطلاق في الغضب"]),
            (&["cerai", "emosi"], vec!["طلاق الغضبان", "الطلاق في الغضب"]),
            (&["talak", "whatsapp"], vec!["الطلاق بالكتابة", "طلاق الكناية"]),
            (&["talak", "pesan"], vec!["الطلاق بالكتابة", "طلاق الكناية"]),
            (&["talak", "sms"], vec!["الطلاق بالكتابة", "طلاق الكناية"]),
            // Kurban + pooling (Q8 fix)
            (&["kurban", "patungan"], vec!["الاشتراك في الأضحية", "الأضحية المشتركة"]),
            (&["qurban", "patungan"], vec!["الاشتراك في الأضحية", "الأضحية المشتركة"]),
            (&["kurban", "bersama"], vec!["الاشتراك في الأضحية", "الأضحية المشتركة"]),
            (&["qurban", "bersama"], vec!["الاشتراك في الأضحية", "الأضحية المشتركة"]),
            (&["kurban", "sapi"], vec!["الأضحية من البقر", "ذبح البقر"]),
            (&["qurban", "sapi"], vec!["الأضحية من البقر", "ذبح البقر"]),
            // Nikah siri + nasab (Q3 fix)
            (&["nikah", "nasab"], vec!["نسب الولد", "النسب في النكاح"]),
            (&["anak", "nasab"], vec!["نسب الولد", "النسب"]),
            (&["nikah", "siri", "anak"], vec!["نسب ولد الزنا", "نسب الولد من النكاح السري"]),
            (&["nikah", "akta"], vec!["توثيق النكاح", "إثبات النكاح"]),

            // ═══ v12: EVAL AUDIT — Critical missing phrases ═══

            // "membatalkan puasa" (pu01 fix — was returning wrong results)
            (&["membatalkan", "puasa"], vec!["مبطلات الصيام", "مفسدات الصوم", "نواقض الصيام", "ما يفسد الصوم"]),
            (&["batalkan", "puasa"], vec!["مبطلات الصيام", "مفسدات الصوم"]),
            (&["batal", "puasa"], vec!["مبطلات الصيام", "بطلان الصيام", "ما يبطل الصوم"]),
            (&["membatalkan", "shalat"], vec!["مبطلات الصلاة", "ما يبطل الصلاة", "نواقض الصلاة"]),
            (&["batal", "shalat"], vec!["مبطلات الصلاة", "بطلان الصلاة"]),
            (&["membatalkan", "wudhu"], vec!["نواقض الوضوء", "ما ينقض الوضوء"]),

            // "beda agama" (cm02 fix — was returning generic nikah results)
            (&["beda", "agama"], vec!["اختلاف الدين", "نكاح الكتابية", "زواج المختلفين في الدين", "نكاح المشرك"]),
            (&["berbeda", "agama"], vec!["اختلاف الدين", "نكاح الكتابية", "زواج المختلفين في الدين"]),
            (&["nikah", "beda"], vec!["نكاح الكتابية", "اختلاف الدين في النكاح", "نكاح المشركة"]),
            (&["nikah", "agama"], vec!["نكاح الكتابية", "اختلاف الدين في النكاح"]),
            (&["nikah", "non", "muslim"], vec!["نكاح الكتابية", "زواج غير المسلم"]),
            (&["nikah", "non"], vec!["نكاح الكتابية", "زواج غير المسلم"]),
            (&["kawin", "beda"], vec!["نكاح الكتابية", "اختلاف الدين في النكاح"]),

            // "celana pendek" / aurat shalat (cm01 fix)
            (&["celana", "pendek"], vec!["ستر العورة", "كشف العورة", "اللباس القصير", "حد العورة"]),
            (&["shalat", "celana"], vec!["ستر العورة في الصلاة", "لباس المصلي", "العورة"]),
            (&["shalat", "pendek"], vec!["ستر العورة في الصلاة", "كشف العورة"]),
            (&["aurat", "shalat"], vec!["عورة المصلي", "ستر العورة في الصلاة", "حد العورة في الصلاة"]),
            (&["aurat", "laki"], vec!["عورة الرجل", "حد عورة الرجل"]),
            (&["aurat", "perempuan"], vec!["عورة المرأة", "حد عورة المرأة"]),
            (&["pakai", "shalat"], vec!["لباس المصلي", "ستر العورة", "اللباس في الصلاة"]),

            // "sifat dua puluh" (aq08 fix)
            (&["sifat", "dua"], vec!["الصفات العشرون", "صفات الله الواجبة"]),
            (&["sifat", "puluh"], vec!["الصفات العشرون", "صفات الله العشرون"]),
            (&["sifat", "allah"], vec!["صفات الله", "الصفات الإلهية", "صفات الله الواجبة"]),
            (&["sifat", "wajib"], vec!["الصفات الواجبة", "صفات الله الواجبة"]),
            (&["sifat", "mustahil"], vec!["الصفات المستحيلة", "صفات الله المستحيلة"]),
            (&["sifat", "jaiz"], vec!["الصفات الجائزة"]),

            // "sujud sahwi" (ib08 fix)
            (&["sujud", "sahwi"], vec!["سجود السهو", "سجدة السهو"]),
            (&["sujud", "sahw"], vec!["سجود السهو", "سجدة السهو"]),
            (&["sujud", "tilawah"], vec!["سجود التلاوة", "سجدة التلاوة"]),
            (&["sujud", "syukur"], vec!["سجود الشكر", "سجدة الشكر"]),

            // "operasi plastik" (zero result fix)
            (&["operasi", "plastik"], vec!["جراحة التجميل", "عمليات التجميل", "حكم التجميل"]),
            (&["bedah", "plastik"], vec!["جراحة التجميل", "عمليات التجميل"]),
            (&["operasi", "kecantikan"], vec!["جراحة التجميل", "عمليات التجميل"]),

            // "ihram miqat" (zero result fix)
            (&["ihram", "miqat"], vec!["الإحرام من الميقات", "المواقيت"]),
            (&["ihram", "dari"], vec!["الإحرام من الميقات", "ميقات الإحرام"]),

            // "adab murid guru" (zero result fix)
            (&["adab", "murid"], vec!["آداب المتعلم", "أدب طالب العلم"]),
            (&["adab", "guru"], vec!["آداب المعلم", "أدب المعلم"]),
            (&["murid", "guru"], vec!["المتعلم والمعلم", "آداب المتعلم مع المعلم"]),
            (&["adab", "belajar"], vec!["آداب التعلم", "أدب طالب العلم"]),
            (&["adab", "ilmu"], vec!["آداب طلب العلم"]),
            (&["adab", "makan"], vec!["آداب الأكل", "آداب الطعام"]),
            (&["adab", "tidur"], vec!["آداب النوم"]),
            (&["adab", "masjid"], vec!["آداب المسجد"]),

            // Tauhid specifics (aq01-02 fix)
            (&["tauhid", "rububiyah"], vec!["توحيد الربوبية"]),
            (&["tauhid", "uluhiyah"], vec!["توحيد الألوهية", "توحيد العبادة"]),
            (&["tauhid", "asma"], vec!["توحيد الأسماء والصفات"]),
            (&["syirik", "kecil"], vec!["الشرك الأصغر"]),
            (&["syirik", "besar"], vec!["الشرك الأكبر"]),
            (&["syirik", "akbar"], vec!["الشرك الأكبر"]),
            (&["syirik", "asghar"], vec!["الشرك الأصغر"]),

            // Muamalat specifics
            (&["akad", "mudharabah"], vec!["عقد المضاربة", "المضاربة"]),
            (&["akad", "murabahah"], vec!["عقد المرابحة", "المرابحة"]),
            (&["akad", "salam"], vec!["عقد السلم", "بيع السلم"]),
            (&["akad", "istisna"], vec!["عقد الاستصناع"]),
            (&["jual", "kredit"], vec!["البيع بالتقسيط", "بيع الأجل"]),
            (&["jual", "cicilan"], vec!["البيع بالتقسيط", "بيع النسيئة"]),
            (&["hukum", "dropship"], vec!["حكم بيع ما لا يملك", "البيع قبل القبض"]),

            // Jinayat specifics (jn02 fix)
            (&["qishas", "diyat"], vec!["القصاص والدية", "أحكام القصاص والدية"]),
            (&["qishash", "diyat"], vec!["القصاص والدية", "أحكام القصاص والدية"]),
            (&["hukum", "korupsi"], vec!["حكم الاختلاس", "حكم أكل المال بالباطل", "الغلول"]),
            (&["hukum", "suap"], vec!["حكم الرشوة", "الرشوة"]),

            // Contemporary issues
            (&["hukum", "kredit"], vec!["حكم البيع بالتقسيط", "البيع بالأجل"]),
            (&["hukum", "asuransi"], vec!["حكم التأمين", "التأمين"]),
            (&["hukum", "saham"], vec!["حكم الأسهم", "حكم الاستثمار"]),
            (&["hukum", "kripto"], vec!["حكم العملات الرقمية"]),
            (&["hukum", "kloning"], vec!["حكم الاستنساخ"]),
            (&["hukum", "aborsi"], vec!["حكم الإجهاض", "الإجهاض"]),
            (&["hukum", "transplantasi"], vec!["حكم نقل الأعضاء", "زراعة الأعضاء"]),
            (&["hukum", "kb"], vec!["حكم تنظيم النسل", "منع الحمل"]),
            (&["hukum", "kontrasepsi"], vec!["حكم منع الحمل", "العزل"]),
            (&["hukum", "tahlilan"], vec!["حكم التهليل", "إهداء الثواب للميت"]),
            (&["hukum", "demo"], vec!["حكم المظاهرات", "الخروج"]),

            // "imam perempuan" (ib13 fix — was wrongly categorized as munakahat)
            (&["imam", "perempuan"], vec!["إمامة المرأة", "صلاة المرأة إماماً"]),
            (&["imam", "wanita"], vec!["إمامة المرأة", "صلاة المرأة إماماً"]),
            (&["perempuan", "imam"], vec!["إمامة المرأة"]),
            (&["perempuan", "shalat"], vec!["صلاة المرأة", "عورة المرأة في الصلاة"]),

            // Qadha qadar (aq06 fix)
            (&["qadha", "qadar"], vec!["قضاء وقدر", "القضاء والقدر"]),
            (&["takdir", "qadar"], vec!["القدر", "القضاء والقدر"]),
            (&["qada", "qadr"], vec!["القضاء والقدر"]),

            // Zakat refinements (zk04 fix)
            (&["zakat", "emas"], vec!["زكاة الذهب", "نصاب الذهب", "حكم زكاة الذهب"]),
            (&["zakat", "perak"], vec!["زكاة الفضة", "نصاب الفضة"]),
            (&["zakat", "pertanian"], vec!["زكاة الزروع", "الزروع والثمار"]),
            (&["zakat", "hewan"], vec!["زكاة الأنعام", "زكاة المواشي"]),
            (&["zakat", "perdagangan"], vec!["زكاة عروض التجارة", "زكاة التجارة"]),
            (&["zakat", "penghasilan"], vec!["زكاة المال", "زكاة الدخل"]),

            // ═══ v15 batch 2: COLLOQUIAL & MODERN PHRASES ═══
            // Shalat + jamaah
            (&["shalat", "jamaah"], vec!["صلاة الجماعة", "الجماعة", "فضل الجماعة"]),
            (&["sholat", "jamaah"], vec!["صلاة الجماعة", "الجماعة"]),
            (&["shalat", "berjamaah"], vec!["صلاة الجماعة", "الجماعة", "فضل الجماعة"]),
            // Shalat tahajud (single j - common misspelling)
            (&["shalat", "tahajud"], vec!["صلاة التهجد", "التهجد", "قيام الليل"]),
            (&["sholat", "tahajud"], vec!["صلاة التهجد", "التهجد", "قيام الليل"]),
            // Engagement & dating
            (&["nikah", "gantung"], vec!["تأخير الدخول", "النكاح بغير دخول"]),
            (&["kawin", "lari"], vec!["نكاح بغير ولي", "نكاح الفرار"]),
            (&["nikah", "massal"], vec!["النكاح الجماعي", "عقد النكاح"]),
            (&["nikah", "kua"], vec!["توثيق النكاح"]),
            // Animals — food queries
            (&["makan", "anjing"], vec!["أكل لحم الكلب", "حرمة الكلب"]),
            (&["makan", "kucing"], vec!["أكل لحم السنور", "حكم أكل الهر"]),
            (&["makan", "ular"], vec!["أكل لحم الحية", "حكم أكل الحيات"]),
            (&["makan", "cacing"], vec!["أكل الحشرات", "أكل الديدان"]),
            (&["makan", "jengkrik"], vec!["أكل الحشرات", "أكل الجراد"]),
            (&["makan", "kelinci"], vec!["أكل الأرنب", "حكم أكل الأرنب"]),
            (&["makan", "buaya"], vec!["أكل التمساح", "حيوان البحر"]),
            (&["makan", "kuda"], vec!["أكل لحم الخيل", "حكم أكل الفرس"]),
            (&["makan", "kepiting"], vec!["أكل السرطان", "حكم أكل القشريات"]),
            (&["makan", "udang"], vec!["أكل الروبيان", "حيوان البحر"]),
            (&["makan", "gurita"], vec!["أكل حيوان البحر", "الأخطبوط"]),
            (&["makan", "kodok"], vec!["أكل الضفدع", "حكم أكل الضفادع"]),
            // Social media / modern
            (&["hukum", "tiktok"], vec!["حكم اللهو", "اللهو والعبث"]),
            (&["hukum", "instagram"], vec!["حكم التصوير", "تصوير"]),
            (&["hukum", "youtube"], vec!["حكم النظر", "التصوير"]),
            (&["hukum", "anime"], vec!["تصوير ذوات الأرواح", "حكم الرسوم"]),
            (&["hukum", "cosplay"], vec!["التشبه", "التشبه بالكفار"]),
            (&["hukum", "pacaran"], vec!["حكم الخلوة", "الاختلاط", "النظر"]),
            (&["hukum", "dating"], vec!["حكم الخلوة", "الاختلاط"]),
            (&["hukum", "judi"], vec!["حكم القمار", "الميسر"]),
            (&["hukum", "narkoba"], vec!["حكم المخدرات", "حكم المسكر"]),
            (&["hukum", "ganja"], vec!["حكم المخدرات", "حكم المسكر"]),
            // Financial modern
            (&["cicilan", "motor"], vec!["البيع بالتقسيط", "الأجل", "الربا"]),
            (&["cicilan", "riba"], vec!["البيع بالتقسيط والربا", "الفائدة"]),
            (&["kredit", "riba"], vec!["البيع بالتقسيط", "الربا", "الفائدة"]),
            (&["kredit", "motor"], vec!["البيع بالتقسيط", "بيع النسيئة"]),
            (&["kredit", "rumah"], vec!["البيع بالتقسيط", "بيع النسيئة"]),
            (&["hukum", "pinjaman"], vec!["حكم القرض", "القرض"]),
            (&["pinjaman", "online"], vec!["القرض", "الربا"]),
            (&["hukum", "reksadana"], vec!["حكم الاستثمار", "صناديق الاستثمار"]),
            (&["hukum", "forex"], vec!["حكم الصرف", "المضاربة"]),
            // Dress code
            (&["hukum", "cadar"], vec!["حكم النقاب", "ستر الوجه"]),
            (&["hukum", "jilbab"], vec!["حكم الحجاب", "وجوب الحجاب"]),
            (&["hukum", "jenggot"], vec!["حكم اللحية", "إعفاء اللحية"]),
            // Medical
            (&["hukum", "euthanasia"], vec!["حكم قتل المريض", "قتل الرحمة"]),
            (&["hukum", "autopsi"], vec!["حكم تشريح الجثة"]),
            (&["hukum", "transfusi"], vec!["حكم نقل الدم"]),
            (&["donor", "darah"], vec!["التبرع بالدم", "نقل الدم"]),
            (&["donor", "organ"], vec!["التبرع بالأعضاء", "نقل الأعضاء"]),
            // Superstition & astrology
            (&["hukum", "zodiak"], vec!["حكم التنجيم", "الكهانة"]),
            (&["hukum", "horoskop"], vec!["حكم التنجيم", "الكهانة"]),
            (&["hukum", "santet"], vec!["حكم السحر", "السحر"]),
            (&["hukum", "dukun"], vec!["حكم الكهانة", "إتيان الكاهن"]),
            // Non-Muslim holidays
            (&["hukum", "valentine"], vec!["حكم أعياد الكفار", "التشبه بالكفار"]),
            (&["hukum", "halloween"], vec!["حكم أعياد الكفار", "التشبه بالكفار"]),
            (&["hukum", "natal"], vec!["حكم أعياد الكفار", "التهنئة بالأعياد"]),
            (&["ucapan", "natal"], vec!["تهنئة الكفار بأعيادهم", "حكم التهنئة"]),
            // Misc colloquial
            (&["hukum", "bekam"], vec!["حكم الحجامة", "الحجامة"]),
            (&["hukum", "ruqyah"], vec!["حكم الرقية", "الرقية الشرعية"]),
            (&["hukum", "hipnotis"], vec!["حكم التنويم", "التنويم المغناطيسي"]),
            (&["hukum", "yoga"], vec!["حكم اليوغا", "التشبه"]),
            (&["hukum", "meditasi"], vec!["حكم التأمل"]),
            (&["hukum", "taaruf"], vec!["حكم التعارف", "الخطبة"]),
            (&["shalat", "kotor"], vec!["طهارة مكان الصلاة", "نجاسة"]),
            (&["shalat", "kaos"], vec!["لباس المصلي", "ستر العورة"]),
            (&["wudhu", "toilet"], vec!["الطهارة في بيت الخلاء", "الاستنجاء"]),
            (&["masjid", "wudhu"], vec!["دخول المسجد", "الطهارة لدخول المسجد"]),

            // ═══ v15 batch 3: SKENARIO & KONTEMPORER phrases ═══
            // Prayer scenarios
            (&["imam", "lupa"], vec!["سهو الإمام", "سجود السهو"]),
            (&["imam", "batal"], vec!["بطلان صلاة الإمام", "استخلاف"]),
            (&["makmum", "datang"], vec!["المسبوق", "إدراك الركعة"]),
            (&["makmum", "salah"], vec!["خطأ المأموم", "سجود السهو"]),
            (&["imam", "anak"], vec!["إمامة الصبي", "صلاة خلف الصبي"]),
            (&["shalat", "gelap"], vec!["الصلاة في الظلام", "صلاة الليل"]),
            (&["saf", "putus"], vec!["قطع الصف", "اتصال الصف"]),
            // Wudu scenarios
            (&["wudhu", "cat"], vec!["الحائل", "وصول الماء"]),
            (&["wudhu", "kutek"], vec!["الحائل", "طلاء الأظافر", "وصول الماء"]),
            (&["wudhu", "kuku"], vec!["الأظافر", "وصول الماء", "طهارة الأعضاء"]),
            (&["wudhu", "plester"], vec!["المسح على الجبيرة", "الجبيرة"]),
            (&["wudhu", "cincin"], vec!["الخاتم", "وصول الماء", "تحريك الخاتم"]),
            (&["wudhu", "air"], vec!["ماء الطهارة", "المياه"]),
            (&["wudhu", "pesawat"], vec!["الطهارة", "التيمم عند عدم الماء"]),
            // Fasting scenarios
            (&["puasa", "mimpi"], vec!["الاحتلام في الصيام", "احتلام الصائم"]),
            (&["puasa", "lupa"], vec!["أكل الصائم ناسياً", "النسيان في الصيام"]),
            (&["puasa", "sakit"], vec!["الصيام مع المرض", "إفطار المريض"]),
            (&["puasa", "dokter"], vec!["حكم الصائم عند الطبيب"]),
            (&["puasa", "operasi"], vec!["الصيام مع العملية", "إفطار المريض"]),
            (&["puasa", "tetes"], vec!["القطرة للصائم", "حكم القطرة في الصيام"]),
            (&["puasa", "berenang"], vec!["السباحة للصائم"]),
            (&["puasa", "ciuman"], vec!["القبلة للصائم", "حكم تقبيل الزوجة"]),
            (&["puasa", "niat"], vec!["نية الصيام", "تبييت النية"]),
            // Nikah scenarios
            (&["nikah", "hamil"], vec!["نكاح الحامل", "نكاح الحامل من الزنا"]),
            (&["nikah", "zina"], vec!["نكاح الزانية", "الزنا والنكاح"]),
            (&["nikah", "iddah"], vec!["النكاح في العدة", "عدة المنكوحة"]),
            (&["wali", "meninggal"], vec!["انتقال الولاية", "ولاية الحاكم"]),
            (&["wali", "kakek"], vec!["ولاية الجد", "الولي في النكاح"]),
            (&["wali", "paman"], vec!["ولاية العم", "ترتيب الأولياء"]),
            (&["ijab", "qabul"], vec!["الإيجاب والقبول", "صيغة العقد"]),
            (&["mas", "kawin"], vec!["المهر", "الصداق"]),
            (&["akad", "zoom"], vec!["العقد عن بعد", "حكم العقد بالهاتف"]),
            (&["akad", "online"], vec!["العقد عن بعد", "اتحاد المجلس"]),
            // Inheritance scenarios
            (&["suami", "meninggal"], vec!["ميراث الزوجة", "نصيب الزوجة"]),
            (&["istri", "meninggal"], vec!["ميراث الزوج", "نصيب الزوج"]),
            (&["pewaris", "hutang"], vec!["ديون الميت", "قضاء الدين"]),
            (&["anak", "angkat"], vec!["التبني", "حكم التبني", "الكفالة"]),
            (&["beda", "agama"], vec!["اختلاف الدين", "ميراث المختلفين ديناً"]),
            (&["wasiat", "sepertiga"], vec!["الوصية", "الثلث"]),
            // Contemporary medical/tech
            (&["operasi", "plastik"], vec!["جراحة التجميل", "عمليات التجميل"]),
            (&["ganti", "kelamin"], vec!["تغيير الجنس", "تحويل الجنس"]),
            (&["bayi", "tabung"], vec!["أطفال الأنابيب", "التلقيح الاصطناعي"]),
            (&["cukur", "alis"], vec!["النمص", "حكم نمص الحواجب"]),
            (&["jabat", "tangan"], vec!["المصافحة", "مصافحة الأجنبية"]),
            (&["ulang", "tahun"], vec!["الاحتفال بالمولد", "حكم أعياد الميلاد"]),
            // Zakat modern
            (&["zakat", "crypto"], vec!["زكاة المال", "زكاة العملات"]),
            (&["zakat", "nft"], vec!["زكاة المال", "زكاة العروض"]),
            // Space/extreme scenarios
            (&["shalat", "luar angkasa"], vec!["تحديد القبلة", "صلاة المسافر"]),
            (&["kiblat", "luar angkasa"], vec!["تحديد القبلة", "الاجتهاد في القبلة"]),
            (&["puasa", "kutub"], vec!["الصيام في البلاد", "تقدير الأوقات"]),
            // Modern social
            (&["hukum", "paylater"], vec!["حكم البيع بالأجل", "القرض بالفائدة"]),
            (&["hukum", "pinjol"], vec!["حكم القرض", "الربا"]),
            (&["hukum", "adopsi"], vec!["حكم التبني", "الكفالة"]),
            (&["pelihara", "anjing"], vec!["اقتناء الكلب", "حكم الكلب"]),
            (&["pelihara", "kucing"], vec!["اقتناء الهر", "حكم الهر"]),
            (&["bunuh", "ular"], vec!["قتل الحية", "حكم قتل الحيات"]),
            (&["bunuh", "semut"], vec!["قتل النمل", "حكم قتل الحشرات"]),
            (&["bunuh", "nyamuk"], vec!["قتل البعوض", "حكم قتل الحشرات"]),
            (&["bunuh", "cicak"], vec!["قتل الوزغ", "حكم قتل الوزغ"]),
            // ═══ English phrase expansions ═══
            // Prayer phrases
            (&["missed", "prayer"], vec!["قضاء الصلاة", "الفوائت"]),
            (&["night", "prayer"], vec!["قيام الليل", "صلاة الليل", "التهجد"]),
            (&["eclipse", "prayer"], vec!["صلاة الكسوف", "صلاة الخسوف"]),
            (&["rain", "prayer"], vec!["صلاة الاستسقاء", "الاستسقاء"]),
            (&["funeral", "prayer"], vec!["صلاة الجنازة", "الجنازة"]),
            (&["eid", "prayer"], vec!["صلاة العيد", "صلاة العيدين"]),
            (&["congregational", "prayer"], vec!["صلاة الجماعة", "الجماعة"]),
            (&["prayer", "direction"], vec!["استقبال القبلة", "تحديد القبلة"]),
            (&["prayer", "conditions"], vec!["شروط الصلاة", "أركان الصلاة"]),
            (&["prayer", "pillars"], vec!["أركان الصلاة", "فرائض الصلاة"]),
            // Fasting phrases
            (&["breaking", "fast"], vec!["إفطار", "الفطر", "مفطرات"]),
            (&["making", "fast"], vec!["قضاء الصوم", "الصيام"]),
            (&["voluntary", "fasting"], vec!["صوم التطوع", "صيام النافلة"]),
            // Marriage/family phrases
            (&["waiting", "period"], vec!["عدة", "العدة", "عدة المطلقة"]),
            (&["child", "custody"], vec!["حضانة", "حضانة الطفل", "الحضانة"]),
            (&["bride", "price"], vec!["مهر", "المهر", "الصداق"]),
            (&["marriage", "contract"], vec!["عقد النكاح", "العقد"]),
            (&["marriage", "guardian"], vec!["ولي النكاح", "الولي"]),
            (&["wedding", "feast"], vec!["وليمة العرس", "الوليمة"]),
            (&["prohibited", "marriage"], vec!["المحرمات من النساء", "حرمة النكاح"]),
            (&["mixed", "marriage"], vec!["نكاح الكتابية", "زواج المختلفين"]),
            // Financial phrases
            (&["buying", "selling"], vec!["البيع والشراء", "البيوع"]),
            (&["interest", "rate"], vec!["ربا", "الربا", "فائدة"]),
            (&["business", "partnership"], vec!["شركة", "المشاركة", "المضاربة"]),
            (&["organ", "donation"], vec!["التبرع بالأعضاء", "نقل الأعضاء"]),
            (&["blood", "donation"], vec!["التبرع بالدم", "نقل الدم"]),
            // Dress/appearance phrases
            (&["gold", "men"], vec!["لبس الذهب للرجال", "تحريم الذهب"]),
            (&["silk", "men"], vec!["لبس الحرير للرجال", "تحريم الحرير"]),
            (&["women", "covering"], vec!["حجاب المرأة", "ستر العورة"]),
            // Jihad/warfare phrases
            (&["rules", "war"], vec!["أحكام الجهاد", "آداب الحرب"]),
            (&["prisoners", "war"], vec!["أسرى", "أحكام الأسرى"]),
            // Worship phrases
            (&["reading", "quran"], vec!["قراءة القرآن", "تلاوة القرآن"]),
            (&["pilgrimage", "rites"], vec!["مناسك الحج", "أركان الحج"]),
            // ═══ Batch 5: Usul fiqh, betrothal, comparative phrases ═══
            (&["maqashid", "syariah"], vec!["مقاصد الشريعة", "المقاصد الشرعية"]),
            (&["maqasid", "syariah"], vec!["مقاصد الشريعة", "المقاصد الشرعية"]),
            (&["sadd", "dzariah"], vec!["سد الذرائع", "سد الذريعة"]),
            (&["sadd", "dzari'ah"], vec!["سد الذرائع", "سد الذريعة"]),
            (&["hifzh", "nafs"], vec!["حفظ النفس"]),
            (&["hifzh", "akal"], vec!["حفظ العقل"]),
            (&["hifzh", "nasab"], vec!["حفظ النسب", "حفظ النسل"]),
            (&["hifzh", "maal"], vec!["حفظ المال"]),
            (&["hifzh", "din"], vec!["حفظ الدين"]),
            (&["maslahah", "mursalah"], vec!["المصلحة المرسلة", "المصالح المرسلة"]),
            (&["nasikh", "mansukh"], vec!["الناسخ والمنسوخ", "النسخ"]),
            (&["menurut", "syafii"], vec!["عند الشافعي", "مذهب الشافعي", "قال الشافعي"]),
            (&["menurut", "hanafi"], vec!["عند الحنفي", "مذهب الحنفي", "قال أبو حنيفة"]),
            (&["menurut", "maliki"], vec!["عند المالكي", "مذهب مالك", "قال مالك"]),
            (&["menurut", "hanbali"], vec!["عند الحنبلي", "مذهب أحمد", "قال أحمد"]),
            (&["pendapat", "syafii"], vec!["رأي الشافعي", "قول الشافعي", "مذهب الشافعي"]),
            (&["pendapat", "hanafi"], vec!["رأي أبي حنيفة", "قول أبي حنيفة", "مذهب الحنفي"]),
            (&["pendapat", "maliki"], vec!["رأي مالك", "قول مالك", "مذهب المالكي"]),
            (&["pendapat", "hanbali"], vec!["رأي أحمد", "قول أحمد", "مذهب الحنبلي"]),
            (&["mazhab", "syafii"], vec!["المذهب الشافعي", "مذهب الشافعي"]),
            (&["mazhab", "hanafi"], vec!["المذهب الحنفي", "مذهب الحنفي"]),
            (&["mazhab", "maliki"], vec!["المذهب المالكي", "مذهب مالك"]),
            (&["mazhab", "hanbali"], vec!["المذهب الحنبلي", "مذهب أحمد"]),
            (&["ahli", "kitab"], vec!["أهل الكتاب"]),
            (&["meminang", "wanita"], vec!["خطبة المرأة", "الخطبة على الخطبة"]),
            (&["melamar", "wanita"], vec!["خطبة المرأة", "الخطبة على الخطبة"]),
            (&["pinang", "iddah"], vec!["خطبة المعتدة", "الخطبة في العدة"]),
            (&["tarji'", "adzan"], vec!["ترجيع الأذان", "الترجيع في الأذان"]),
            (&["khilaf", "ulama"], vec!["اختلاف العلماء", "خلاف الفقهاء"]),
            (&["perbedaan", "mazhab"], vec!["اختلاف المذاهب", "الخلاف بين المذاهب"]),

            // ─── V17: Scholar name pairs (phrase match is more accurate than single-word) ───
            (&["abu", "bakar"], vec!["أبو بكر", "أبو بكر الصديق"]),
            (&["abu", "dawud"], vec!["سنن أبي داود", "أبو داود"]),
            (&["ibnu", "taimiyah"], vec!["ابن تيمية"]),
            (&["ibnu", "qayyim"], vec!["ابن القيم", "ابن قيم الجوزية"]),
            (&["ibnu", "hajar"], vec!["ابن حجر", "ابن حجر العسقلاني"]),
            (&["ibnu", "majah"], vec!["سنن ابن ماجه", "ابن ماجه"]),
            (&["ibnu", "rusyd"], vec!["ابن رشد", "أبو الوليد"]),
            (&["ibnu", "khaldun"], vec!["ابن خلدون"]),
            (&["ibnu", "sina"], vec!["ابن سينا"]),
            (&["ibn", "taimiyah"], vec!["ابن تيمية"]),
            (&["ibn", "qayyim"], vec!["ابن القيم"]),
            (&["ibn", "hajar"], vec!["ابن حجر", "ابن حجر العسقلاني"]),
            (&["ibn", "majah"], vec!["سنن ابن ماجه", "ابن ماجه"]),
            (&["ibn", "rusyd"], vec!["ابن رشد"]),
            (&["ibn", "khaldun"], vec!["ابن خلدون"]),
            (&["ibn", "sina"], vec!["ابن سينا"]),
            (&["khalid", "walid"], vec!["خالد بن الوليد", "سيف الله"]),
            (&["umar", "khattab"], vec!["عمر بن الخطاب", "الخليفة الثاني"]),
            (&["utsman", "affan"], vec!["عثمان بن عفان", "الخليفة الثالث"]),
            (&["hamzah", "muthalib"], vec!["حمزة بن عبد المطلب", "أسد الله"]),
            (&["khadijah", "khuwailid"], vec!["خديجة بنت خويلد", "أم المؤمنين"]),
            (&["aisyah", "bakar"], vec!["عائشة بنت أبي بكر", "أم المؤمنين"]),
            (&["fatimah", "zahra"], vec!["فاطمة الزهراء", "سيدة النساء"]),
            (&["jalaluddin", "suyuthi"], vec!["جلال الدين السيوطي", "السيوطي"]),

            // ─── V17: Islamic month name pairs ───
            (&["rabiul", "awal"], vec!["ربيع الأول", "شهر المولد"]),
            (&["rabiul", "akhir"], vec!["ربيع الآخر", "ربيع الثاني"]),
            (&["jumadil", "awal"], vec!["جمادى الأولى"]),
            (&["jumadil", "akhir"], vec!["جمادى الآخرة", "جمادى الثانية"]),
            (&["bulan", "muharram"], vec!["شهر محرم", "المحرم"]),
            (&["bulan", "rajab"], vec!["شهر رجب", "رجب"]),
            (&["nisfu", "sya'ban"], vec!["ليلة النصف من شعبان", "نصف شعبان"]),
            (&["nisfu", "syaban"], vec!["ليلة النصف من شعبان", "نصف شعبان"]),

            // ─── V17: Book title pairs ───
            (&["fathul", "qarib"], vec!["فتح القريب", "التقريب"]),
            (&["fathul", "muin"], vec!["فتح المعين", "زين الدين"]),
            (&["raudhatut", "thalibin"], vec!["روضة الطالبين", "النووي"]),
            (&["riyadhus", "shalihin"], vec!["رياض الصالحين", "النووي"]),
            (&["bulughul", "maram"], vec!["بلوغ المرام", "ابن حجر العسقلاني"]),
            (&["tuhfatul", "muhtaj"], vec!["تحفة المحتاج", "ابن حجر الهيتمي"]),
            (&["nihayatul", "muhtaj"], vec!["نهاية المحتاج", "الرملي"]),
            (&["mughnil", "muhtaj"], vec!["مغني المحتاج", "الشربيني"]),
            (&["kifayatul", "akhyar"], vec!["كفاية الأخيار"]),
            (&["nailul", "authar"], vec!["نيل الأوطار", "الشوكاني"]),
            (&["sunan", "dawud"], vec!["سنن أبي داود", "أبو داود"]),
            (&["sunan", "tirmidzi"], vec!["سنن الترمذي", "الترمذي"]),
            (&["sunan", "nasai"], vec!["سنن النسائي", "النسائي"]),
            (&["sunan", "majah"], vec!["سنن ابن ماجه", "ابن ماجه"]),
            (&["musnad", "ahmad"], vec!["مسند أحمد", "مسند الإمام أحمد"]),

            // ─── V17 BATCH 8: Sirah / Islamic history pairs ───
            (&["fathu", "makkah"], vec!["فتح مكة", "الفتح الأعظم"]),
            (&["isra", "miraj"], vec!["الإسراء والمعراج", "رحلة الإسراء"]),
            (&["piagam", "madinah"], vec!["وثيقة المدينة", "صحيفة المدينة"]),
            (&["khulafaur", "rasyidin"], vec!["الخلفاء الراشدون"]),
            (&["bani", "umayyah"], vec!["بنو أمية", "الدولة الأموية"]),
            (&["bani", "abbasiyah"], vec!["بنو العباس", "الدولة العباسية"]),
            (&["khalifah", "bakar"], vec!["أبو بكر الصديق", "الخليفة الأول"]),
            (&["khalifah", "umar"], vec!["عمر بن الخطاب", "الخليفة الثاني"]),
            (&["khalifah", "utsman"], vec!["عثمان بن عفان", "الخليفة الثالث"]),
            (&["khalifah", "ali"], vec!["علي بن أبي طالب", "الخليفة الرابع"]),
            (&["drama", "korea"], vec!["مسلسل", "مشاهدة المسلسلات"]),

            // ─── V17 BATCH 8: Usul fiqh related pairs ───
            (&["am", "khas"], vec!["العام والخاص", "عام وخاص"]),
            (&["haqiqi", "majazi"], vec!["الحقيقة والمجاز", "حقيقي ومجازي"]),
            (&["mujmal", "mubayyan"], vec!["المجمل والمبيَّن"]),
            (&["rukhshah", "azimah"], vec!["الرخصة والعزيمة"]),
            (&["amar", "makruf"], vec!["الأمر بالمعروف", "النهي عن المنكر"]),
            (&["nahi", "munkar"], vec!["النهي عن المنكر", "الأمر بالمعروف"]),

            // ─── V18 BATCH 11: Battle / war pairs ───
            (&["perang", "badr"], vec!["غزوة بدر", "معركة بدر"]),
            (&["perang", "uhud"], vec!["غزوة أحد", "معركة أحد"]),
            (&["perang", "khandaq"], vec!["غزوة الخندق", "الأحزاب"]),
            (&["peristiwa", "badr"], vec!["غزوة بدر"]),
            (&["peristiwa", "uhud"], vec!["غزوة أحد"]),

            // ─── V18 BATCH 11: Scholar / sahabi name pairs ───
            (&["khalid", "walid"], vec!["خالد بن الوليد", "سيف الله المسلول"]),
            (&["hamzah", "muthalib"], vec!["حمزة بن عبد المطلب", "أسد الله"]),
            (&["khadijah", "khuwailid"], vec!["خديجة بنت خويلد", "أم المؤمنين"]),
            (&["fatimah", "zahra"], vec!["فاطمة الزهراء", "سيدة النساء"]),
            (&["ibn", "sina"], vec!["ابن سينا", "أبو علي سينا"]),
            (&["ibnu", "sina"], vec!["ابن سينا", "أبو علي سينا"]),
            (&["ibn", "rusyd"], vec!["ابن رشد", "أبو الوليد رشد"]),
            (&["ibnu", "rusyd"], vec!["ابن رشد"]),
            (&["ibn", "khaldun"], vec!["ابن خلدون"]),
            (&["ibnu", "khaldun"], vec!["ابن خلدون"]),
            (&["ibn", "hajar"], vec!["ابن حجر", "ابن حجر العسقلاني"]),
            (&["ibnu", "hajar"], vec!["ابن حجر", "ابن حجر الهيتمي"]),
            (&["10", "sahabat"], vec!["العشرة المبشرين بالجنة"]),
            (&["jalaluddin", "suyuthi"], vec!["جلال الدين السيوطي"]),
            (&["aisyah", "bakar"], vec!["عائشة بنت أبي بكر", "أم المؤمنين"]),
            (&["ibn", "taimiyah"], vec!["ابن تيمية", "شيخ الإسلام"]),
            (&["ibnu", "taimiyah"], vec!["ابن تيمية", "شيخ الإسلام"]),
            (&["ibn", "qayyim"], vec!["ابن القيم", "ابن قيم الجوزية"]),
            (&["ibnu", "qayyim"], vec!["ابن القيم"]),
            (&["ibnu", "haitami"], vec!["ابن حجر الهيتمي"]),

            // ─── BATCH 17: Specific Hajj, prayer times, hadith types, keutamaan ───
            // Five daily prayers by specific name
            (&["shalat", "subuh"], vec!["صلاة الصبح", "صلاة الفجر"]),
            (&["shalat", "dzuhur"], vec!["صلاة الظهر"]),
            (&["shalat", "ashar"], vec!["صلاة العصر"]),
            (&["shalat", "maghrib"], vec!["صلاة المغرب"]),
            (&["shalat", "isya"], vec!["صلاة العشاء"]),
            (&["shalat", "isha"], vec!["صلاة العشاء"]),
            (&["shalat", "fajr"], vec!["صلاة الفجر", "صلاة الصبح"]),
            // Jumrah at Hajj
            (&["jumrah", "aqabah"], vec!["جمرة العقبة", "رمي جمرة العقبة"]),
            (&["jumrah", "ula"], vec!["الجمرة الأولى", "رمي الجمرات"]),
            (&["jumrah", "wustha"], vec!["الجمرة الوسطى"]),
            (&["melempar", "jumrah"], vec!["رمي الجمرات", "الرمي"]),
            (&["melontar", "jumrah"], vec!["رمي الجمرات", "الرمي"]),
            // Hadith classification types
            (&["hadits", "shahih"], vec!["الحديث الصحيح", "صحيح"]),
            (&["hadits", "sahih"], vec!["الحديث الصحيح", "صحيح"]),
            (&["hadits", "hasan"], vec!["الحديث الحسن", "حسن"]),
            (&["hadits", "dhaif"], vec!["الحديث الضعيف", "ضعيف"]),
            (&["hadits", "daif"], vec!["الحديث الضعيف", "ضعيف"]),
            (&["hadits", "mawdhu"], vec!["الحديث الموضوع", "موضوع"]),
            (&["hadits", "qudsi"], vec!["الحديث القدسي", "قدسي"]),
            (&["hadits", "mutawatir"], vec!["الحديث المتواتر", "متواتر"]),
            (&["hadits", "ahad"], vec!["حديث الآحاد", "الآحاد"]),
            (&["ilmu", "hadits"], vec!["علوم الحديث", "مصطلح الحديث"]),
            (&["ulumul", "hadits"], vec!["علوم الحديث", "مصطلح الحديث"]),
            (&["mustalah", "hadits"], vec!["مصطلح الحديث", "علم مصطلح الحديث"]),
            // Keutamaan (fadilah) phrases
            (&["keutamaan", "shalawat"], vec!["فضل الصلاة على النبي", "الصلاة على النبي"]),
            (&["keutamaan", "istighfar"], vec!["فضل الاستغفار", "ثواب الاستغفار"]),
            (&["keutamaan", "silaturahmi"], vec!["فضل صلة الرحم", "صلة الرحم"]),
            (&["keutamaan", "shalat"], vec!["فضل الصلاة", "ثواب الصلاة"]),
            (&["keutamaan", "quran"], vec!["فضل القرآن", "فضل تلاوة القرآن"]),
            (&["keutamaan", "puasa"], vec!["فضل الصيام", "ثواب الصوم"]),
            (&["keutamaan", "sedekah"], vec!["فضل الصدقة", "ثواب الصدقة"]),
            (&["keutamaan", "zikir"], vec!["فضل الذكر", "ثواب الذكر"]),
            (&["keutamaan", "sabar"], vec!["فضل الصبر", "ثواب الصبر"]),
            (&["keutamaan", "taubat"], vec!["فضل التوبة", "ثواب التوبة"]),
            // Ilmu kalam theological schools
            (&["ilmu", "kalam"], vec!["علم الكلام", "الكلام"]),
            (&["asy'ariyah", "maturidiyah"], vec!["الأشعرية والماتريدية", "أهل السنة والجماعة"]),
            (&["ahlus", "sunnah"], vec!["أهل السنة والجماعة", "السنة"]),
            (&["ahlussunnah", "waljamaah"], vec!["أهل السنة والجماعة"]),
            // Kitab + bab queries
            (&["bab", "thaharah"], vec!["باب الطهارة", "الطهارة"]),
            (&["bab", "shalat"], vec!["باب الصلاة", "الصلاة"]),
            (&["bab", "puasa"], vec!["باب الصوم", "الصيام"]),
            (&["bab", "zakat"], vec!["باب الزكاة", "الزكاة"]),
            (&["bab", "haji"], vec!["باب الحج", "الحج"]),
            (&["bab", "nikah"], vec!["باب النكاح", "النكاح"]),
            (&["bab", "talak"], vec!["باب الطلاق", "الطلاق"]),
            (&["bab", "jual"], vec!["باب البيع", "البيوع"]),
            (&["bab", "qadha"], vec!["باب القضاء", "القضاء والقدر"]),
            // Takbiran / ied
            (&["takbiran", "ied"], vec!["تكبيرات العيد", "التكبير في العيد"]),
            (&["ied", "fitri"], vec!["عيد الفطر", "العيد"]),
            (&["ied", "adha"], vec!["عيد الأضحى", "العيد"]),
            (&["idul", "fitri"], vec!["عيد الفطر"]),
            (&["idul", "adha"], vec!["عيد الأضحى"]),
            // Malam (night) practices
            (&["malam", "nisfu"], vec!["ليلة النصف من شعبان"]),
            (&["malam", "isra"], vec!["ليلة الإسراء", "الإسراء والمعراج"]),
            (&["malam", "lailatul"], vec!["ليلة القدر"]),
            (&["lailatul", "qadar"], vec!["ليلة القدر"]),
            (&["malam", "jumat"], vec!["ليلة الجمعة"]),
        ];

        for (phrase_words, phrase_arabic) in &phrase_map {
            // All phrase words must appear somewhere in the query (not necessarily adjacent)
            // Use smart matching: short words (<4 chars) require exact match to prevent
            // false positives like "tidak".contains("id") matching ("shalat","id")→صلاة العيد
            let all_match = phrase_words.iter().all(|pw| {
                lower_words.iter().any(|w| {
                    if pw.len() < 4 {
                        w == pw  // short phrase words: exact match only
                    } else {
                        w == pw || w.contains(pw)  // longer: allow substring (catches berwudhu→wudhu)
                    }
                })
            });
            if all_match {
                for arab in phrase_arabic {
                    expansions.push(arab.to_string());
                }
            }
        }

        // Deduplicate
        expansions.sort();
        expansions.dedup();
        expansions
    }

    // ─── Tantivy Query Construction ───

    fn build_tantivy_query(&self, arabic_terms: &[String], latin_terms: &[String]) -> String {
        let mut parts = Vec::new();

        // Arabic terms get higher boost
        for term in arabic_terms {
            // If term has spaces (phrase), wrap in quotes
            if term.contains(' ') {
                parts.push(format!("\"{}\"^3", term));
            } else {
                parts.push(format!("{}^2", term));
            }
        }

        // Latin terms (original query words) get lower boost for fallback
        for term in latin_terms {
            if term.len() > 2 {
                parts.push(term.clone());
            }
        }

        if parts.is_empty() {
            // Return original for safety
            return arabic_terms
                .first()
                .or(latin_terms.first())
                .cloned()
                .unwrap_or_default();
        }

        parts.join(" OR ")
    }

    // ─── Dictionary Builder ───

    fn build_term_dictionary(&mut self) {
        // ═══ IBADAH MAHDAH ═══
        for key in &["shalat", "solat", "salat", "prayer", "prayers", "salah", "sholat"] {
            self.term_map.insert(key.to_string(), vec!["صلاة", "الصلاة", "الصلوات"]);
        }
        // Jum'ah — standalone entries: covers "jumat", "jum'at", "jumuah", etc.
        for key in &["jumat", "jumaat", "jum'at", "jumaah", "jumah", "jumuah", "jum'ah"] {
            self.term_map.insert(key.to_string(), vec!["الجمعة", "صلاة الجمعة", "يوم الجمعة"]);
        }
        for key in &["friday"] {
            self.term_map.insert(key.to_string(), vec!["الجمعة", "يوم الجمعة", "صلاة الجمعة"]);
        }
        for key in &["wudhu", "wudu", "ablution", "wudhuk", "wuduk"] {
            self.term_map.insert(key.to_string(), vec!["وضوء", "الوضوء", "الطهارة"]);
        }
        for key in &["tayammum", "tayamum"] {
            self.term_map.insert(key.to_string(), vec!["تيمم", "التيمم"]);
        }
        for key in &["puasa", "shaum", "shiyam", "fasting", "saum", "siyam"] {
            self.term_map.insert(key.to_string(), vec!["صوم", "صيام", "الصيام"]);
        }
        for key in &["zakat", "zakah", "zakaah"] {
            self.term_map.insert(key.to_string(), vec!["زكاة", "الزكاة", "زكاة المال"]);
        }
        for key in &["haji", "hajj", "pilgrimage"] {
            self.term_map.insert(key.to_string(), vec!["حج", "الحج", "المناسك"]);
        }
        for key in &["umroh", "umrah", "umra"] {
            self.term_map.insert(key.to_string(), vec!["عمرة", "العمرة"]);
        }
        for key in &["sujud", "prostration"] {
            self.term_map.insert(key.to_string(), vec!["سجود", "السجود"]);
        }
        for key in &["ruku", "rukuk", "bowing"] {
            self.term_map.insert(key.to_string(), vec!["ركوع", "الركوع"]);
        }
        for key in &["qunut", "qunoot"] {
            self.term_map.insert(key.to_string(), vec!["قنوت", "القنوت", "دعاء القنوت"]);
        }
        for key in &["subuh", "shubuh", "subh", "fajar"] {
            self.term_map.insert(key.to_string(), vec!["صبح", "الصبح", "الفجر", "صلاة الفجر"]);
        }
        for key in &["dzuhur", "zuhur", "dhuhr", "zhuhur", "lohor"] {
            self.term_map.insert(key.to_string(), vec!["ظهر", "الظهر", "صلاة الظهر"]);
        }
        for key in &["ashar", "asar", "ashr"] {
            self.term_map.insert(key.to_string(), vec!["عصر", "العصر", "صلاة العصر"]);
        }
        for key in &["maghrib", "magrib"] {
            self.term_map.insert(key.to_string(), vec!["مغرب", "المغرب", "صلاة المغرب"]);
        }
        for key in &["isya", "isha", "isya'"] {
            self.term_map.insert(key.to_string(), vec!["عشاء", "العشاء", "صلاة العشاء"]);
        }
        for key in &["adzan", "azan", "azaan", "adhan"] {
            self.term_map.insert(key.to_string(), vec!["أذان", "الأذان"]);
        }
        for key in &["iqamah", "iqamat", "iqomah"] {
            self.term_map.insert(key.to_string(), vec!["إقامة", "الإقامة"]);
        }
        for key in &["itikaf", "i'tikaf", "iktikaf"] {
            self.term_map.insert(key.to_string(), vec!["اعتكاف", "الاعتكاف"]);
        }
        for key in &["qurban", "kurban", "udhiyah", "udhiyyah", "sacrifice"] {
            self.term_map.insert(key.to_string(), vec!["أضحية", "الأضحية", "الذبح"]);
        }
        for key in &["aqiqah", "akikah"] {
            self.term_map.insert(key.to_string(), vec!["عقيقة", "العقيقة"]);
        }
        for key in &["fidyah"] {
            self.term_map.insert(key.to_string(), vec!["فدية", "الفدية"]);
        }
        for key in &["kaffarah", "kafarah", "kifarat", "kafarat", "kaffarat"] {
            self.term_map.insert(key.to_string(), vec!["كفارة", "الكفارة", "الكفارات"]);
        }
        for key in &["sumpah", "yamin", "oath", "bersumpah"] {
            self.term_map.insert(key.to_string(), vec!["يمين", "الأيمان", "حلف", "القسم"]);
        }
        for key in &["palsu", "bohong", "dusta", "false"] {
            self.term_map.insert(key.to_string(), vec!["كاذبة", "الكذب", "الغموس", "اليمين الغموس"]);
        }
        for key in &["nadzar", "nazar", "vow"] {
            self.term_map.insert(key.to_string(), vec!["نذر", "النذر", "النذور"]);
        }
        for key in &["dzikir", "zikir", "dhikr", "remembrance"] {
            self.term_map.insert(key.to_string(), vec!["ذكر", "الأذكار"]);
        }
        for key in &["doa", "du'a", "supplication", "duaa"] {
            self.term_map.insert(key.to_string(), vec!["دعاء", "الدعاء"]);
        }

        // ═══ THAHARAH ═══
        for key in &["najis", "najasa", "impure", "impurity"] {
            self.term_map.insert(key.to_string(), vec!["نجاسة", "النجس", "المتنجس"]);
        }
        for key in &["junub", "junubi"] {
            self.term_map.insert(key.to_string(), vec!["جنابة", "الحدث الأكبر"]);
        }
        for key in &["haid", "haidh", "menstruasi", "menstruation", "haidz"] {
            self.term_map.insert(key.to_string(), vec!["حيض", "المحيض", "الحيض"]);
        }
        for key in &["nifas", "postpartum"] {
            self.term_map.insert(key.to_string(), vec!["نفاس", "النفاس"]);
        }
        for key in &["istihadhah", "istihadzah", "istihadoh"] {
            self.term_map.insert(key.to_string(), vec!["استحاضة", "الاستحاضة", "المستحاضة"]);
        }
        for key in &["mandi", "ghusl", "bathing"] {
            self.term_map.insert(key.to_string(), vec!["غسل", "الغسل"]);
        }
        for key in &["suci", "bersuci", "purification"] {
            self.term_map.insert(key.to_string(), vec!["طهارة", "الطهارة", "التطهير"]);
        }
        for key in &["mani", "sperma", "semen"] {
            self.term_map.insert(key.to_string(), vec!["مني", "المني"]);
        }
        for key in &["madzi", "madhy", "madhiy"] {
            self.term_map.insert(key.to_string(), vec!["مذي", "المذي"]);
        }
        for key in &["wadi", "wadiy"] {
            self.term_map.insert(key.to_string(), vec!["ودي", "الودي"]);
        }
        for key in &["kencing", "urine"] {
            self.term_map.insert(key.to_string(), vec!["بول", "البول"]);
        }
        for key in &["tinja", "kotoran", "feces"] {
            self.term_map.insert(key.to_string(), vec!["غائط", "الغائط"]);
        }
        for key in &["darah", "blood"] {
            self.term_map.insert(key.to_string(), vec!["دم", "الدم"]);
        }
        // v10: missing Thaharah terms
        for key in &["perban", "diperban", "gips", "balut", "jabira", "jabirah"] {
            self.term_map.insert(key.to_string(), vec!["جبيرة", "الجبيرة", "المسح على الجبيرة"]);
        }

        // ═══ MUAMALAT ═══
        for key in &["riba", "bunga", "interest", "usury"] {
            self.term_map.insert(key.to_string(), vec!["ربا", "الربا", "فائدة", "ربا الفضل", "ربا النسيئة"]);
        }
        for key in &["jual", "beli", "trade"] {
            self.term_map.insert(key.to_string(), vec!["بيع", "البيع", "المعاملات"]);
        }
        for key in &["transaksi", "transaction"] {
            self.term_map.insert(key.to_string(), vec!["معاملة", "المعاملات"]);
        }
        for key in &["utang", "hutang", "debt", "piutang"] {
            self.term_map.insert(key.to_string(), vec!["دين", "الدين", "قرض", "القرض"]);
        }
        for key in &["gadai", "pawn", "collateral"] {
            self.term_map.insert(key.to_string(), vec!["رهن", "الرهن"]);
        }
        for key in &["sewa", "ijarah", "rent", "rental"] {
            self.term_map.insert(key.to_string(), vec!["إجارة", "الإجارة"]);
        }
        for key in &["mudharabah", "mudhorobah", "mudarabah"] {
            self.term_map.insert(key.to_string(), vec!["مضاربة", "المضاربة"]);
        }
        for key in &["musyarakah", "musharakah", "partnership"] {
            self.term_map.insert(key.to_string(), vec!["مشاركة", "الشركة"]);
        }
        for key in &["wakaf", "waqf", "endowment"] {
            self.term_map.insert(key.to_string(), vec!["وقف", "الوقف", "الأوقاف"]);
        }
        for key in &["hibah", "gift"] {
            self.term_map.insert(key.to_string(), vec!["هبة", "الهبة"]);
        }
        for key in &["wasiat", "will", "testament"] {
            self.term_map.insert(key.to_string(), vec!["وصية", "الوصية"]);
        }
        for key in &["waris", "warisan", "inheritance"] {
            self.term_map.insert(key.to_string(), vec!["ميراث", "الميراث", "التركة", "الإرث", "الفرائض"]);
        }
        for key in &["halal"] {
            self.term_map.insert(key.to_string(), vec!["حلال", "الحلال", "المباح"]);
        }
        for key in &["haram", "forbidden", "prohibited"] {
            self.term_map.insert(key.to_string(), vec!["حرام", "الحرام", "المحرم"]);
        }
        for key in &["makruh", "disliked"] {
            self.term_map.insert(key.to_string(), vec!["مكروه", "الكراهة"]);
        }
        for key in &["mubah", "permissible", "allowed"] {
            self.term_map.insert(key.to_string(), vec!["مباح", "الإباحة"]);
        }
        for key in &["sunnah", "sunah", "recommended"] {
            self.term_map.insert(key.to_string(), vec!["سنة", "مستحب", "مندوب"]);
        }
        for key in &["wajib", "fardhu", "obligatory", "fard"] {
            self.term_map.insert(key.to_string(), vec!["واجب", "فرض", "الوجوب"]);
        }

        // ═══ MUNAKAHAT ═══
        for key in &["nikah", "kawin", "marriage", "pernikahan", "menikah"] {
            self.term_map.insert(key.to_string(), vec!["نكاح", "زواج", "التزويج", "عقد النكاح"]);
        }
        for key in &["cerai", "talak", "divorce", "perceraian"] {
            self.term_map.insert(key.to_string(), vec!["طلاق", "الطلاق", "فراق"]);
        }
        for key in &["khuluk", "khulu", "khul'"] {
            self.term_map.insert(key.to_string(), vec!["خلع", "الخلع"]);
        }
        for key in &["iddah", "idah"] {
            self.term_map.insert(key.to_string(), vec!["عدة", "العدة"]);
        }
        for key in &["nafkah", "nafaqah", "alimony"] {
            self.term_map.insert(key.to_string(), vec!["نفقة", "النفقة"]);
        }
        for key in &["mahar", "dowry"] {
            self.term_map.insert(key.to_string(), vec!["مهر", "صداق", "المهر", "الصداق"]);
        }
        for key in &["poligami", "polygamy", "poligini"] {
            self.term_map.insert(key.to_string(), vec!["تعدد الزوجات", "التعدد"]);
        }
        for key in &["walimah", "resepsi"] {
            self.term_map.insert(key.to_string(), vec!["وليمة", "الوليمة"]);
        }
        for key in &["wali"] {
            self.term_map.insert(key.to_string(), vec!["ولي", "الولي", "الولاية"]);
        }
        for key in &["mahram", "muhrim"] {
            self.term_map.insert(key.to_string(), vec!["محرم", "المحارم"]);
        }
        for key in &["impoten", "impotent"] {
            self.term_map.insert(key.to_string(), vec!["عنين", "العنة", "الجب", "العيوب في النكاح"]);
        }
        for key in &["fasakh", "fasak", "annulment"] {
            self.term_map.insert(key.to_string(), vec!["فسخ", "فسخ النكاح"]);
        }
        for key in &["suami", "husband"] {
            self.term_map.insert(key.to_string(), vec!["زوج", "الزوج"]);
        }
        for key in &["istri", "wife"] {
            self.term_map.insert(key.to_string(), vec!["زوجة", "الزوجة"]);
        }
        for key in &["anak", "child", "children"] {
            self.term_map.insert(key.to_string(), vec!["ولد", "الولد", "الأولاد"]);
        }
        for key in &["perempuan", "wanita", "daughter", "girl"] {
            self.term_map.insert(key.to_string(), vec!["بنت", "البنت", "النساء", "الإناث"]);
        }
        for key in &["laki", "lelaki", "pria", "son", "boy"] {
            self.term_map.insert(key.to_string(), vec!["ابن", "الابن", "الذكور"]);
        }
        for key in &["yatim", "orphan"] {
            self.term_map.insert(key.to_string(), vec!["يتيم", "اليتيم"]);
        }
        for key in &["susuan", "radha'ah", "breastfeeding"] {
            self.term_map.insert(key.to_string(), vec!["رضاعة", "الرضاع", "الرضاعة"]);
        }
        for key in &["nusyuz", "nushuz", "disobedience"] {
            self.term_map.insert(key.to_string(), vec!["نشوز", "النشوز"]);
        }
        // v10: missing Munakahat terms
        for key in &["nasab", "keturunan", "lineage", "nasib"] {
            self.term_map.insert(key.to_string(), vec!["نسب", "النسب", "نسب الولد"]);
        }
        for key in &["marah", "amarah", "anger", "angry"] {
            self.term_map.insert(key.to_string(), vec!["غضب", "الغضب"]);
        }
        for key in &["emosi", "emotional", "kalap"] {
            self.term_map.insert(key.to_string(), vec!["غضب", "الغضب", "الانفعال"]);
        }
        for key in &["patungan", "urunan", "iuran", "pooling"] {
            self.term_map.insert(key.to_string(), vec!["اشتراك", "الاشتراك", "المشاركة"]);
        }
        for key in &["li'an", "lian"] {
            self.term_map.insert(key.to_string(), vec!["لعان", "اللعان"]);
        }
        for key in &["ila'", "ila"] {
            self.term_map.insert(key.to_string(), vec!["إيلاء", "الإيلاء"]);
        }
        for key in &["zhihar", "dzihar", "zihar"] {
            self.term_map.insert(key.to_string(), vec!["ظهار", "الظهار"]);
        }
        for key in &["rujuk", "ruju'", "reconciliation"] {
            self.term_map.insert(key.to_string(), vec!["رجعة", "الرجعة"]);
        }

        // ═══ AQIDAH ═══
        for key in &["tauhid", "tawhid", "monotheism"] {
            self.term_map.insert(key.to_string(), vec!["توحيد", "التوحيد"]);
        }
        for key in &["syirik", "shirk", "polytheism", "musyrik"] {
            self.term_map.insert(key.to_string(), vec!["شرك", "الشرك"]);
        }
        for key in &["murtad", "apostasy", "riddah", "ridda"] {
            self.term_map.insert(key.to_string(), vec!["ردة", "الردة", "المرتد"]);
        }
        for key in &["bid'ah", "bidah", "innovation"] {
            self.term_map.insert(key.to_string(), vec!["بدعة", "البدعة", "البدع"]);
        }
        for key in &["kafir", "kufr", "disbelief"] {
            self.term_map.insert(key.to_string(), vec!["كفر", "الكفر"]);
        }
        for key in &["iman", "faith", "keimanan"] {
            self.term_map.insert(key.to_string(), vec!["إيمان", "الإيمان"]);
        }
        for key in &["tawakkal", "tawakkul", "tawakal", "tawakul", "reliance"] {
            self.term_map.insert(key.to_string(), vec!["توكل", "التوكل", "التوكل على الله"]);
        }
        for key in &["tawassul", "tawasul"] {
            self.term_map.insert(key.to_string(), vec!["توسل", "التوسل"]);
        }
        for key in &["syafaat", "syafa'at", "intercession"] {
            self.term_map.insert(key.to_string(), vec!["شفاعة", "الشفاعة"]);
        }
        for key in &["takdir", "destiny", "fate"] {
            self.term_map.insert(key.to_string(), vec!["قدر", "القدر", "القضاء والقدر"]);
        }

        // ═══ JINAYAT ═══
        for key in &["hudud", "had", "punishment"] {
            self.term_map.insert(key.to_string(), vec!["حدود", "الحدود", "حد"]);
        }
        for key in &["qishash", "qisas", "retaliation"] {
            self.term_map.insert(key.to_string(), vec!["قصاص", "القصاص"]);
        }
        for key in &["diyat", "diyah", "bloodmoney"] {
            self.term_map.insert(key.to_string(), vec!["دية", "الدية"]);
        }
        for key in &["ta'zir", "tazir", "discretionary"] {
            self.term_map.insert(key.to_string(), vec!["تعزير", "التعزير"]);
        }
        for key in &["pencurian", "mencuri", "theft", "stealing"] {
            self.term_map.insert(key.to_string(), vec!["سرقة", "السرقة"]);
        }
        for key in &["zina", "adultery", "fornication"] {
            self.term_map.insert(key.to_string(), vec!["زنا", "الزنا", "حد الزنا"]);
        }
        for key in &["qadzaf", "qadhaf", "slander"] {
            self.term_map.insert(key.to_string(), vec!["قذف", "القذف"]);
        }
        for key in &["khamr", "miras", "alcohol", "wine"] {
            self.term_map.insert(key.to_string(), vec!["خمر", "الخمر", "المسكر"]);
        }
        for key in &["bunuh", "membunuh", "murder", "killing"] {
            self.term_map.insert(key.to_string(), vec!["قتل", "القتل"]);
        }

        // ═══ TAFSIR ═══
        for key in &["tafsir", "interpretation"] {
            self.term_map.insert(key.to_string(), vec!["تفسير", "التفسير"]);
        }
        for key in &["ta'wil", "takwil"] {
            self.term_map.insert(key.to_string(), vec!["تأويل", "التأويل"]);
        }
        for key in &["asbab", "nuzul", "revelation"] {
            self.term_map.insert(key.to_string(), vec!["أسباب النزول", "سبب النزول"]);
        }
        for key in &["nasikh", "mansukh", "abrogation"] {
            self.term_map.insert(key.to_string(), vec!["ناسخ", "منسوخ", "النسخ"]);
        }
        for key in &["ayat", "ayah", "verse"] {
            self.term_map.insert(key.to_string(), vec!["آية", "الآية"]);
        }
        for key in &["surat", "surah", "chapter"] {
            self.term_map.insert(key.to_string(), vec!["سورة", "السورة"]);
        }

        // ═══ HADITS ═══
        for key in &["hadits", "hadis", "hadith"] {
            self.term_map.insert(key.to_string(), vec!["حديث", "الحديث", "الأحاديث"]);
        }
        for key in &["sanad", "chain"] {
            self.term_map.insert(key.to_string(), vec!["إسناد", "السند"]);
        }
        for key in &["rawi", "narrator"] {
            self.term_map.insert(key.to_string(), vec!["راوي", "الرواة"]);
        }
        for key in &["mustalah", "terminology"] {
            self.term_map.insert(key.to_string(), vec!["مصطلح الحديث"]);
        }

        // ═══ TASAWUF ═══
        for key in &["tasawuf", "sufism", "tasawwuf"] {
            self.term_map.insert(key.to_string(), vec!["تصوف", "التصوف"]);
        }
        for key in &["ihsan"] {
            self.term_map.insert(key.to_string(), vec!["إحسان", "الإحسان"]);
        }
        for key in &["taubat", "taubah", "repentance"] {
            self.term_map.insert(key.to_string(), vec!["توبة", "التوبة"]);
        }
        for key in &["ikhlas", "sincerity"] {
            self.term_map.insert(key.to_string(), vec!["إخلاص", "الإخلاص"]);
        }
        for key in &["sabar", "patience"] {
            self.term_map.insert(key.to_string(), vec!["صبر", "الصبر"]);
        }
        for key in &["syukur", "gratitude"] {
            self.term_map.insert(key.to_string(), vec!["شكر", "الشكر"]);
        }
        for key in &["taqwa", "piety"] {
            self.term_map.insert(key.to_string(), vec!["تقوى", "التقوى"]);
        }
        for key in &["khusyu", "khushu", "humility"] {
            self.term_map.insert(key.to_string(), vec!["خشوع", "الخشوع"]);
        }
        for key in &["riya", "riya'", "showoff"] {
            self.term_map.insert(key.to_string(), vec!["رياء", "الرياء"]);
        }
        for key in &["ujub", "vanity"] {
            self.term_map.insert(key.to_string(), vec!["عجب", "العُجب"]);
        }
        for key in &["hasad", "hasud", "envy"] {
            self.term_map.insert(key.to_string(), vec!["حسد", "الحسد"]);
        }
        for key in &["ghibah", "backbiting"] {
            self.term_map.insert(key.to_string(), vec!["غيبة", "الغيبة"]);
        }
        for key in &["namimah", "slander", "gossip"] {
            self.term_map.insert(key.to_string(), vec!["نميمة", "النميمة"]);
        }

        // ═══ COMMON TERMS ═══
        for key in &["hukum", "ruling", "law"] {
            self.term_map.insert(key.to_string(), vec!["حكم", "الحكم", "أحكام"]);
        }
        for key in &["fatwa", "verdict"] {
            self.term_map.insert(key.to_string(), vec!["فتوى", "الفتوى", "الفتاوى"]);
        }
        for key in &["mazhab", "madzhab", "madhab", "school"] {
            self.term_map.insert(key.to_string(), vec!["مذهب", "المذهب"]);
        }
        for key in &["syafi'i", "syafii", "shafi'i", "shafii"] {
            self.term_map.insert(key.to_string(), vec!["الشافعي", "شافعي"]);
        }
        for key in &["hanafi"] {
            self.term_map.insert(key.to_string(), vec!["الحنفي", "حنفي"]);
        }
        for key in &["maliki"] {
            self.term_map.insert(key.to_string(), vec!["المالكي", "مالكي"]);
        }
        for key in &["hanbali"] {
            self.term_map.insert(key.to_string(), vec!["الحنبلي", "حنبلي"]);
        }
        for key in &["ijma", "ijma'", "consensus"] {
            self.term_map.insert(key.to_string(), vec!["إجماع", "الإجماع"]);
        }
        for key in &["qiyas", "analogy"] {
            self.term_map.insert(key.to_string(), vec!["قياس", "القياس"]);
        }
        for key in &["ijtihad"] {
            self.term_map.insert(key.to_string(), vec!["اجتهاد", "الاجتهاد"]);
        }
        for key in &["dalil", "evidence", "proof"] {
            self.term_map.insert(key.to_string(), vec!["دليل", "الدليل", "الأدلة"]);
        }
        for key in &["khilaf", "ikhtilaf", "disagreement"] {
            self.term_map.insert(key.to_string(), vec!["خلاف", "اختلاف", "الخلاف"]);
        }
        for key in &["darurat", "darura", "necessity", "emergency"] {
            self.term_map.insert(key.to_string(), vec!["ضرورة", "الضرورة", "الاضطرار"]);
        }
        for key in &["maslahah", "maslahat", "benefit"] {
            self.term_map.insert(key.to_string(), vec!["مصلحة", "المصلحة", "المصالح"]);
        }
        for key in &["mafsadah", "mafsadat", "harm"] {
            self.term_map.insert(key.to_string(), vec!["مفسدة", "المفسدة", "المفاسد"]);
        }
        for key in &["niat", "niyyah", "intention"] {
            self.term_map.insert(key.to_string(), vec!["نية", "النية"]);
        }
        for key in &["syarat", "condition", "requirement"] {
            self.term_map.insert(key.to_string(), vec!["شرط", "الشروط"]);
        }
        for key in &["rukun", "pillar"] {
            self.term_map.insert(key.to_string(), vec!["ركن", "الأركان"]);
        }
        for key in &["boleh", "bolehkah", "allowed", "permissible"] {
            self.term_map.insert(key.to_string(), vec!["جواز", "الجواز", "يجوز", "حلال"]);
        }
        for key in &["ulama", "scholar", "scholars"] {
            self.term_map.insert(key.to_string(), vec!["علماء", "العلماء", "عالم"]);
        }
        for key in &["imam"] {
            self.term_map.insert(key.to_string(), vec!["إمام", "الإمام"]);
        }
        for key in &["masjid", "mosque", "musholla", "musala"] {
            self.term_map.insert(key.to_string(), vec!["مسجد", "المسجد", "المساجد"]);
        }
        for key in &["jenazah", "janazah", "funeral", "mayit", "mayat"] {
            self.term_map.insert(key.to_string(), vec!["جنازة", "الجنازة", "الميت"]);
        }
        for key in &["kubur", "makam", "grave"] {
            self.term_map.insert(key.to_string(), vec!["قبر", "القبر", "القبور"]);
        }
        for key in &["sedekah", "shadaqah", "charity"] {
            self.term_map.insert(key.to_string(), vec!["صدقة", "الصدقة"]);
        }
        for key in &["infaq", "infak", "spending"] {
            self.term_map.insert(key.to_string(), vec!["إنفاق", "الإنفاق"]);
        }
        for key in &["khitan", "sunat", "circumcision"] {
            self.term_map.insert(key.to_string(), vec!["ختان", "الختان"]);
        }
        for key in &["rakaat", "rakat", "raka'at", "rakah"] {
            self.term_map.insert(key.to_string(), vec!["ركعة", "الركعات", "ركعات"]);
        }
        for key in &["mati", "meninggal", "wafat", "death", "kematian"] {
            self.term_map.insert(key.to_string(), vec!["الموت", "المتوفى", "الوفاة", "الميت"]);
        }
        for key in &["nafilah", "nawafil"] {
            self.term_map.insert(key.to_string(), vec!["سنة", "النوافل", "المستحب", "المندوب"]);
        }
        for key in &["dilarang"] {
            self.term_map.insert(key.to_string(), vec!["حرام", "التحريم", "المحرمات"]);
        }
        for key in &["lawful"] {
            self.term_map.insert(key.to_string(), vec!["حلال", "الحلال", "المباح", "الجائز"]);
        }
        for key in &["dibenci"] {
            self.term_map.insert(key.to_string(), vec!["مكروه", "المكروه"]);
        }
        for key in &["fardu"] {
            self.term_map.insert(key.to_string(), vec!["واجب", "الواجب", "فرض", "الفرض"]);
        }
        for key in &["taubat", "tobat", "tawbah", "repentance"] {
            self.term_map.insert(key.to_string(), vec!["توبة", "التوبة"]);
        }
        for key in &["syafaat", "shafa'ah", "intercession"] {
            self.term_map.insert(key.to_string(), vec!["شفاعة", "الشفاعة"]);
        }

        // ═══ MODERN ISSUES ═══
        for key in &["vaksin", "vaccine", "imunisasi"] {
            self.term_map.insert(key.to_string(), vec!["التطعيم", "اللقاح"]);
        }
        for key in &["rokok", "cigarette", "smoking", "merokok"] {
            self.term_map.insert(key.to_string(), vec!["التدخين", "الدخان"]);
        }
        for key in &["foto", "photograph", "gambar", "picture"] {
            self.term_map.insert(key.to_string(), vec!["تصوير", "التصوير", "الصورة"]);
        }
        for key in &["musik", "music"] {
            self.term_map.insert(key.to_string(), vec!["الغناء", "المعازف", "الموسيقى"]);
        }
        for key in &["tato", "tattoo"] {
            self.term_map.insert(key.to_string(), vec!["الوشم"]);
        }
        for key in &["transplantasi", "transplant"] {
            self.term_map.insert(key.to_string(), vec!["نقل الأعضاء", "زراعة الأعضاء"]);
        }
        for key in &["aborsi", "abortion", "menggugurkan"] {
            self.term_map.insert(key.to_string(), vec!["إجهاض", "الإجهاض"]);
        }
        for key in &["bayi", "tabung", "ivf"] {
            self.term_map.insert(key.to_string(), vec!["التلقيح الصناعي", "أطفال الأنابيب"]);
        }
        for key in &["kloning", "cloning"] {
            self.term_map.insert(key.to_string(), vec!["الاستنساخ", "الاستنساخ البشري", "استنساخ"]);
        }
        for key in &["gelatin", "jelly"] {
            self.term_map.insert(key.to_string(), vec!["الجيلاتين", "الاستحالة"]);
        }
        for key in &["makan", "eat", "eating", "makanan", "food"] {
            self.term_map.insert(key.to_string(), vec!["أكل", "الأكل", "الطعام", "الأطعمة"]);
        }
        for key in &["minum", "drink", "minuman", "beverage"] {
            self.term_map.insert(key.to_string(), vec!["شرب", "الشرب", "المشروبات"]);
        }
        for key in &["konvensional", "conventional"] {
            self.term_map.insert(key.to_string(), vec!["الربوي", "التقليدي"]);
        }
        for key in &["babi", "pork", "pig"] {
            self.term_map.insert(key.to_string(), vec!["خنزير", "لحم الخنزير"]);
        }
        for key in &["alkohol", "alcohol"] {
            self.term_map.insert(key.to_string(), vec!["كحول", "الكحول", "خمر"]);
        }
        for key in &["obat", "medicine", "pengobatan"] {
            self.term_map.insert(key.to_string(), vec!["دواء", "التداوي", "العلاج"]);
        }
        for key in &["bank", "perbankan", "banking"] {
            self.term_map.insert(key.to_string(), vec!["البنك", "المصرف", "البنوك"]);
        }
        for key in &["kripto", "crypto", "bitcoin"] {
            self.term_map.insert(key.to_string(), vec!["العملات الرقمية", "البتكوين"]);
        }
        for key in &["saham", "stocks", "investasi"] {
            self.term_map.insert(key.to_string(), vec!["الأسهم", "الاستثمار"]);
        }

        // ═══ HEALTH & MEDICAL ═══
        for key in &["sakit", "sick", "ill", "illness", "penyakit", "disease"] {
            self.term_map.insert(key.to_string(), vec!["مرض", "المريض", "الأمراض"]);
        }
        for key in &["darurat", "emergency", "terpaksa", "necessity", "keterpaksaan"] {
            self.term_map.insert(key.to_string(), vec!["ضرورة", "الضرورة", "الاضطرار"]);
        }
        for key in &["iftar", "buka puasa", "tidak puasa"] {
            self.term_map.insert(key.to_string(), vec!["إفطار", "الإفطار", "ترك الصوم"]);
        }
        for key in &["saat", "ketika", "waktu", "when", "during"] {
            self.term_map.insert(key.to_string(), vec![]);
        }
        for key in &["dokter", "physician", "medis", "medical"] {
            self.term_map.insert(key.to_string(), vec!["الطب", "الطبيب"]);
        }

        // ═══ MARRIAGE DEFECTS ═══
        for key in &["impoten", "impotent", "lemah syahwat"] {
            self.term_map.insert(key.to_string(), vec!["عنة", "العنين", "العنة", "الجب"]);
        }
        for key in &["khuluk", "cerai gugat", "khul"] {
            self.term_map.insert(key.to_string(), vec!["خلع", "الخلع"]);
        }
        for key in &["shiqaq", "syiqaq", "perselisihan suami istri"] {
            self.term_map.insert(key.to_string(), vec!["شقاق", "الشقاق"]);
        }
        for key in &["hakim", "judge", "pengadilan", "court"] {
            self.term_map.insert(key.to_string(), vec!["القاضي", "الحاكم", "القضاء"]);
        }

        // ═══ MISSING COMMON TERMS (added v8) ═══

        // Religious core terms
        for key in &["allah", "god"] {
            self.term_map.insert(key.to_string(), vec!["الله", "سبحانه وتعالى"]);
        }
        for key in &["ramadhan", "ramadan", "romadhon"] {
            self.term_map.insert(key.to_string(), vec!["رمضان", "شهر رمضان"]);
        }
        for key in &["muhammad", "nabi", "rasul", "prophet"] {
            self.term_map.insert(key.to_string(), vec!["النبي", "الرسول", "محمد"]);
        }

        // Financial terms
        for key in &["nisab", "nishab"] {
            self.term_map.insert(key.to_string(), vec!["نصاب", "النصاب"]);
        }
        for key in &["haul"] {
            self.term_map.insert(key.to_string(), vec!["حول", "الحول"]);
        }
        for key in &["emas", "gold"] {
            self.term_map.insert(key.to_string(), vec!["ذهب", "الذهب"]);
        }
        for key in &["perak", "silver"] {
            self.term_map.insert(key.to_string(), vec!["فضة", "الفضة"]);
        }
        for key in &["uang", "money", "harta", "wealth"] {
            self.term_map.insert(key.to_string(), vec!["مال", "المال", "الأموال"]);
        }
        for key in &["online", "daring"] {
            self.term_map.insert(key.to_string(), vec!["الإلكتروني", "عبر الإنترنت"]);
        }

        // Food and animals
        for key in &["daging", "meat"] {
            self.term_map.insert(key.to_string(), vec!["لحم", "اللحم", "اللحوم"]);
        }
        for key in &["ular", "snake"] {
            self.term_map.insert(key.to_string(), vec!["حية", "الحية", "الأفعى", "حكم أكل الحيات"]);
        }
        for key in &["sembelihan", "penyembelihan", "menyembelih", "slaughter"] {
            self.term_map.insert(key.to_string(), vec!["ذبيحة", "الذبح", "الذبائح", "التذكية"]);
        }
        for key in &["binatang", "hewan", "animal"] {
            self.term_map.insert(key.to_string(), vec!["حيوان", "الحيوانات"]);
        }
        for key in &["ikan", "fish"] {
            self.term_map.insert(key.to_string(), vec!["سمك", "السمك"]);
        }
        for key in &["ayam", "chicken"] {
            self.term_map.insert(key.to_string(), vec!["دجاج", "الدجاج"]);
        }
        for key in &["kambing", "goat"] {
            self.term_map.insert(key.to_string(), vec!["غنم", "الغنم", "شاة"]);
        }
        for key in &["sapi", "cow", "cattle"] {
            self.term_map.insert(key.to_string(), vec!["بقر", "البقر"]);
        }
        for key in &["anjing", "dog"] {
            self.term_map.insert(key.to_string(), vec!["كلب", "الكلب"]);
        }
        for key in &["kucing", "cat"] {
            self.term_map.insert(key.to_string(), vec!["هر", "الهرة", "القط"]);
        }

        // Body/health terms
        for key in &["hamil", "kehamilan", "pregnant", "pregnancy"] {
            self.term_map.insert(key.to_string(), vec!["حمل", "الحمل", "الحامل"]);
        }
        for key in &["ibu", "mother"] {
            self.term_map.insert(key.to_string(), vec!["أم", "الأم"]);
        }
        for key in &["menyusui", "breastfeed"] {
            self.term_map.insert(key.to_string(), vec!["رضاعة", "الرضاعة", "المرضع"]);
        }
        for key in &["bayi", "baby", "infant"] {
            self.term_map.insert(key.to_string(), vec!["طفل", "الطفل", "الرضيع", "الصبي"]);
        }
        for key in &["tua", "lansia", "elderly", "old"] {
            self.term_map.insert(key.to_string(), vec!["شيخ", "كبير السن", "العجوز"]);
        }

        // Position/action terms
        for key in &["duduk", "sitting", "sit"] {
            self.term_map.insert(key.to_string(), vec!["جالس", "قاعد", "القعود", "الجلوس"]);
        }
        for key in &["berdiri", "standing", "stand"] {
            self.term_map.insert(key.to_string(), vec!["قائم", "القيام", "الوقوف"]);
        }
        for key in &["berbaring", "lying", "rebahan"] {
            self.term_map.insert(key.to_string(), vec!["مضطجع", "الاضطجاع", "مستلقي"]);
        }
        for key in &["pegang", "memegang", "hold", "carrying"] {
            self.term_map.insert(key.to_string(), vec!["حمل", "يحمل", "الحمل"]);
        }

        // Media/entertainment
        for key in &["nyanyian", "nyanyi", "singing", "song"] {
            self.term_map.insert(key.to_string(), vec!["غناء", "الغناء", "الأغاني"]);
        }
        for key in &["video", "film", "movie"] {
            self.term_map.insert(key.to_string(), vec!["الفيلم", "المرئيات"]);
        }

        // Travel
        for key in &["perjalanan", "safar", "travel", "musafir", "traveler"] {
            self.term_map.insert(key.to_string(), vec!["سفر", "السفر", "المسافر"]);
        }

        // Legal/validity terms
        for key in &["sah", "valid", "sahih"] {
            self.term_map.insert(key.to_string(), vec!["صحة", "صحيح", "الصحة"]);
        }
        for key in &["batal", "invalid", "void"] {
            self.term_map.insert(key.to_string(), vec!["بطلان", "باطل", "البطلان"]);
        }
        for key in &["fasid", "defective"] {
            self.term_map.insert(key.to_string(), vec!["فاسد", "الفساد"]);
        }

        // People of the book
        for key in &["nasrani", "kristen", "christian"] {
            self.term_map.insert(key.to_string(), vec!["نصراني", "النصارى", "أهل الكتاب"]);
        }
        for key in &["yahudi", "jewish", "jew"] {
            self.term_map.insert(key.to_string(), vec!["يهودي", "اليهود", "أهل الكتاب"]);
        }

        // Bid'ah variant handling
        for key in &["bid", "bidah", "bid'ah"] {
            self.term_map.insert(key.to_string(), vec!["بدعة", "البدعة", "البدع"]);
        }

        // Concept/definition terms
        for key in &["pengertian", "definisi", "meaning", "definition"] {
            self.term_map.insert(key.to_string(), vec!["تعريف", "معنى", "المعنى"]);
        }
        for key in &["batasan", "limit", "boundary"] {
            self.term_map.insert(key.to_string(), vec!["حدود", "ضابط", "الضوابط"]);
        }
        for key in &["perbedaan", "difference", "beda"] {
            self.term_map.insert(key.to_string(), vec!["فرق", "الفرق", "الاختلاف"]);
        }
        for key in &["cara", "tata", "method", "kaifiyah", "kaifiyyah"] {
            self.term_map.insert(key.to_string(), vec!["كيفية", "الكيفية"]);
        }

        // Asuransi standalone
        for key in &["asuransi", "insurance"] {
            self.term_map.insert(key.to_string(), vec!["التأمين", "تأمين", "تكافل"]);
        }

        // Misc common words that appear in Islamic queries
        for key in &["tanpa", "tanpa", "without"] {
            self.term_map.insert(key.to_string(), vec!["بغير", "بدون"]);
        }
        for key in &["setelah", "sesudah", "after"] {
            self.term_map.insert(key.to_string(), vec!["بعد", "بعد ذلك"]);
        }
        for key in &["mengandung", "menggunakan", "containing", "using"] {
            self.term_map.insert(key.to_string(), vec![]);
        }
        for key in &["bahan", "ingredient", "material"] {
            self.term_map.insert(key.to_string(), vec!["مادة", "المواد"]);
        }

        // ═══ MISSING TERMS — from 120-query eval audit (v12) ═══

        // Hajj terms (caused ZERO RESULTS)
        for key in &["ihram", "ihrom", "ihram"] {
            self.term_map.insert(key.to_string(), vec!["إحرام", "الإحرام"]);
        }
        for key in &["miqat", "miqot", "mikat"] {
            self.term_map.insert(key.to_string(), vec!["ميقات", "المواقيت", "الميقات"]);
        }
        for key in &["tawaf", "thawaf", "towaf"] {
            self.term_map.insert(key.to_string(), vec!["طواف", "الطواف"]);
        }
        for key in &["sa'i", "sai", "sa'y"] {
            self.term_map.insert(key.to_string(), vec!["سعي", "السعي"]);
        }
        for key in &["wukuf", "wuquf"] {
            self.term_map.insert(key.to_string(), vec!["وقوف", "الوقوف بعرفة"]);
        }
        for key in &["jamarat", "jumroh", "jamrah"] {
            self.term_map.insert(key.to_string(), vec!["جمرات", "رمي الجمرات"]);
        }
        for key in &["dam", "denda haji"] {
            self.term_map.insert(key.to_string(), vec!["دم", "فدية"]);
        }

        // Akhlak / Adab terms (caused ZERO RESULTS)
        for key in &["adab", "etika", "akhlak", "etiquette", "manners"] {
            self.term_map.insert(key.to_string(), vec!["أدب", "آداب", "الآداب", "الأدب"]);
        }
        for key in &["murid", "santri", "student", "pelajar"] {
            self.term_map.insert(key.to_string(), vec!["تلميذ", "طالب", "طالب العلم", "المتعلم"]);
        }
        for key in &["guru", "ustadz", "teacher", "kyai"] {
            self.term_map.insert(key.to_string(), vec!["معلم", "أستاذ", "شيخ", "المعلم"]);
        }
        for key in &["hormat", "menghormati", "respect"] {
            self.term_map.insert(key.to_string(), vec!["احترام", "تعظيم", "إكرام"]);
        }

        // Medical / modern terms (caused ZERO RESULTS)
        for key in &["operasi", "bedah", "surgery"] {
            self.term_map.insert(key.to_string(), vec!["جراحة", "عملية", "العمليات الجراحية"]);
        }
        for key in &["plastik", "kecantikan", "cosmetic"] {
            self.term_map.insert(key.to_string(), vec!["تجميل", "التجميل", "عمليات التجميل"]);
        }
        for key in &["dropship", "dropshipping", "reseller"] {
            self.term_map.insert(key.to_string(), vec!["بيع ما لا يملك", "البيع قبل القبض", "السلم", "بيع المعدوم"]);
        }
        for key in &["tahlilan", "tahlil", "yasinan"] {
            self.term_map.insert(key.to_string(), vec!["التهليل", "قراءة الفاتحة", "إهداء الثواب", "الدعاء للميت"]);
        }

        // Aqidah specifics (caused LOW COVERAGE)
        for key in &["sifat", "attribute", "attributes"] {
            self.term_map.insert(key.to_string(), vec!["صفة", "صفات", "الصفات"]);
        }
        for key in &["rububiyah", "rububiyyah"] {
            self.term_map.insert(key.to_string(), vec!["الربوبية", "توحيد الربوبية"]);
        }
        for key in &["uluhiyah", "uluhiyyah", "ubudiyah"] {
            self.term_map.insert(key.to_string(), vec!["الألوهية", "توحيد الألوهية", "العبودية"]);
        }
        for key in &["asma", "asmaul", "nama"] {
            self.term_map.insert(key.to_string(), vec!["أسماء", "الأسماء", "أسماء الله"]);
        }
        for key in &["husna"] {
            self.term_map.insert(key.to_string(), vec!["الحسنى", "أسماء الله الحسنى"]);
        }
        for key in &["dua", "duapuluh", "twenty", "20"] {
            self.term_map.insert(key.to_string(), vec!["عشرون", "العشرون"]);
        }
        for key in &["puluh", "belas", "ratus"] {
            self.term_map.insert(key.to_string(), vec![]); // numeric modifiers, no Arabic needed
        }
        for key in &["kecil", "small", "minor", "kecilnya"] {
            self.term_map.insert(key.to_string(), vec!["أصغر", "الأصغر", "صغير"]);
        }
        for key in &["besar", "big", "major", "besarnya"] {
            self.term_map.insert(key.to_string(), vec!["أكبر", "الأكبر", "كبير"]);
        }

        // Ibadah specifics (caused LOW COVERAGE)
        for key in &["sahwi", "sahw"] {
            self.term_map.insert(key.to_string(), vec!["سهو", "السهو", "سجود السهو"]);
        }
        for key in &["tilawah", "tilawat"] {
            self.term_map.insert(key.to_string(), vec!["تلاوة", "التلاوة", "سجود التلاوة"]);
        }
        for key in &["aurat", "awrat", "aurot"] {
            self.term_map.insert(key.to_string(), vec!["عورة", "العورة", "ستر العورة"]);
        }
        for key in &["celana", "pants", "trousers"] {
            self.term_map.insert(key.to_string(), vec!["سروال", "لباس", "اللباس"]);
        }
        for key in &["pendek", "short"] {
            self.term_map.insert(key.to_string(), vec!["قصير"]);
        }
        for key in &["imam", "imamah"] {
            self.term_map.insert(key.to_string(), vec!["إمام", "الإمام", "الإمامة"]);
        }
        for key in &["makmum", "makmun", "musalli"] {
            self.term_map.insert(key.to_string(), vec!["مأموم", "المأموم", "المصلي"]);
        }
        for key in &["muadzin", "muazin", "bilal"] {
            self.term_map.insert(key.to_string(), vec!["مؤذن", "المؤذن"]);
        }
        for key in &["khutbah", "khotbah", "sermon"] {
            self.term_map.insert(key.to_string(), vec!["خطبة", "الخطبة"]);
        }

        // Munakahat specifics (caused WRONG RESULTS)
        for key in &["agama", "religion", "din"] {
            self.term_map.insert(key.to_string(), vec!["دين", "الدين", "الأديان"]);
        }
        for key in &["beda", "berbeda", "different"] {
            self.term_map.insert(key.to_string(), vec!["اختلاف", "مختلف", "الاختلاف"]);
        }
        for key in &["murtad", "murtadd", "apostate"] {
            self.term_map.insert(key.to_string(), vec!["ردة", "الردة", "المرتد"]);
        }

        // Jinayat specifics (caused LOW COVERAGE)
        for key in &["korupsi", "corruption"] {
            self.term_map.insert(key.to_string(), vec!["الفساد", "الإختلاس", "أكل المال بالباطل", "الغلول"]);
        }
        for key in &["suap", "risywah", "bribery", "bribe"] {
            self.term_map.insert(key.to_string(), vec!["رشوة", "الرشوة"]);
        }

        // Contemporary / modern fiqh
        for key in &["lgbt", "homoseksual", "homosexual"] {
            self.term_map.insert(key.to_string(), vec!["اللواط", "لوط", "قوم لوط", "السحاق"]);
        }
        for key in &["kb", "kontrasepsi", "contraception"] {
            self.term_map.insert(key.to_string(), vec!["تنظيم النسل", "منع الحمل", "العزل"]);
        }
        for key in &["donor", "mendonorkan"] {
            self.term_map.insert(key.to_string(), vec!["التبرع", "نقل الأعضاء"]);
        }
        for key in &["organ", "organs"] {
            self.term_map.insert(key.to_string(), vec!["أعضاء", "الأعضاء", "زراعة الأعضاء"]);
        }
        for key in &["kredit", "cicilan", "installment", "credit"] {
            self.term_map.insert(key.to_string(), vec!["البيع بالتقسيط", "الأقساط", "البيع بالأجل"]);
        }
        for key in &["mlm", "multi level", "network marketing"] {
            self.term_map.insert(key.to_string(), vec!["التسويق الشبكي", "بيع الغرر"]);
        }
        for key in &["demo", "demonstrasi", "unjuk rasa", "protest"] {
            self.term_map.insert(key.to_string(), vec!["المظاهرات", "الخروج على الحاكم"]);
        }

        // Action verbs commonly used in queries
        for key in &["membatalkan", "cancel", "invalidate"] {
            self.term_map.insert(key.to_string(), vec!["مبطلات", "نواقض", "مفسدات", "إبطال"]);
        }
        for key in &["mewajibkan", "obligate"] {
            self.term_map.insert(key.to_string(), vec!["يوجب", "الإيجاب", "الوجوب"]);
        }
        for key in &["mengharamkan", "prohibit", "forbid"] {
            self.term_map.insert(key.to_string(), vec!["يحرم", "التحريم", "الحرمة"]);
        }
        for key in &["menghalalkan", "legalize"] {
            self.term_map.insert(key.to_string(), vec!["يحل", "الإباحة", "الحل"]);
        }
        for key in &["menikahi", "menikahkan"] {
            self.term_map.insert(key.to_string(), vec!["نكاح", "تزويج", "عقد النكاح"]);
        }
        for key in &["menceraikan", "mencerai"] {
            self.term_map.insert(key.to_string(), vec!["طلاق", "التطليق"]);
        }

        // Shalat-related verbs
        for key in &["sholat", "sholaat"] {
            self.term_map.insert(key.to_string(), vec!["صلاة", "الصلاة", "الصلوات"]);
        }

        // ═══ v15: Common misspelling variants from 10K eval ═══
        // Wudhu variants
        for key in &["wudhlu", "wudlu", "wudu", "wudho", "wudoo"] {
            self.term_map.insert(key.to_string(), vec!["وضوء", "الوضوء", "الطهارة"]);
        }
        // Puasa variants
        for key in &["puoso", "shiyam", "shaum", "syiyam"] {
            self.term_map.insert(key.to_string(), vec!["صوم", "صيام", "الصيام"]);
        }
        // Zakat variants
        for key in &["zakaat", "dzakat", "dzakaat"] {
            self.term_map.insert(key.to_string(), vec!["زكاة", "الزكاة", "زكاة المال"]);
        }
        // Haji variants
        for key in &["hajj", "hadzj", "hadj"] {
            self.term_map.insert(key.to_string(), vec!["حج", "الحج", "المناسك"]);
        }
        // Tayammum variants
        for key in &["tayyamum", "tayamum", "tayamom"] {
            self.term_map.insert(key.to_string(), vec!["تيمم", "التيمم"]);
        }
        // Talak variants
        for key in &["talaq", "tholaq", "tolak", "thalaq"] {
            self.term_map.insert(key.to_string(), vec!["طلاق", "الطلاق"]);
        }
        // Nikah variants
        for key in &["nikakh", "nikaah", "nikha"] {
            self.term_map.insert(key.to_string(), vec!["نكاح", "زواج", "عقد النكاح"]);
        }
        // Khulu' variants
        for key in &["khulug", "khuluq", "khuluk"] {
            self.term_map.insert(key.to_string(), vec!["خلع", "الخلع"]);
        }
        // Fasakh variants
        for key in &["fasah", "fasak", "fasakh"] {
            self.term_map.insert(key.to_string(), vec!["فسخ", "فسخ النكاح"]);
        }
        // Ruku' variants
        for key in &["ruko'", "rukuk", "ruku'", "rukoo"] {
            self.term_map.insert(key.to_string(), vec!["ركوع", "الركوع"]);
        }
        // Sujud variants
        for key in &["sujud", "sujood", "sajdah", "sajda"] {
            self.term_map.insert(key.to_string(), vec!["سجود", "السجود", "السجدة"]);
        }
        // Modern terms for colloquial queries
        for key in &["whatsapp", "wa", "chat"] {
            self.term_map.insert(key.to_string(), vec!["رسالة", "مكتوب", "كتابة"]);
        }
        for key in &["bitcoin", "kripto", "crypto"] {
            self.term_map.insert(key.to_string(), vec!["عملة", "نقد", "صرف", "مال"]);
        }
        for key in &["bank", "perbankan", "banking"] {
            self.term_map.insert(key.to_string(), vec!["مصرف", "ربا", "فائدة"]);
        }
        for key in &["asuransi", "insurance"] {
            self.term_map.insert(key.to_string(), vec!["تأمين", "التأمين", "ضمان"]);
        }
        for key in &["vaksin", "vaccine", "imunisasi"] {
            self.term_map.insert(key.to_string(), vec!["تطعيم", "لقاح", "تلقيح"]);
        }
        for key in &["alkohol", "alcohol", "rhum", "rum"] {
            self.term_map.insert(key.to_string(), vec!["خمر", "كحول", "مسكر"]);
        }
        for key in &["game", "gaming", "permainan"] {
            self.term_map.insert(key.to_string(), vec!["لعب", "لهو", "قمار"]);
        }
        for key in &["musik", "music", "lagu", "nyanyi"] {
            self.term_map.insert(key.to_string(), vec!["غناء", "معازف", "موسيقى"]);
        }
        for key in &["foto", "gambar", "picture", "selfie"] {
            self.term_map.insert(key.to_string(), vec!["تصوير", "صورة", "ذوات الأرواح"]);
        }
        for key in &["pacaran", "dating"] {
            self.term_map.insert(key.to_string(), vec!["خلوة", "اختلاط", "نظر"]);
        }
        for key in &["dropship", "reseller", "makelar"] {
            self.term_map.insert(key.to_string(), vec!["سمسار", "وكالة", "بيع ما لا يملك"]);
        }

        // Numbers/time words used in fiqh queries
        for key in &["tiga", "three", "3"] {
            self.term_map.insert(key.to_string(), vec!["ثلاث", "ثلاثة"]);
        }
        for key in &["empat", "four", "4"] {
            self.term_map.insert(key.to_string(), vec!["أربع", "أربعة"]);
        }

        // ══════ v15 batch 2: High-impact fiqh terms from gap analysis ══════
        
        // Congregational prayer & mosque
        for key in &["jamaah", "berjamaah", "jemaah", "berjemaah", "congregation"] {
            self.term_map.insert(key.to_string(), vec!["جماعة", "الجماعة", "صلاة الجماعة"]);
        }
        // Jinn & sorcery
        for key in &["jin", "jinn", "genie"] {
            self.term_map.insert(key.to_string(), vec!["جن", "الجن", "الجن والشياطين"]);
        }
        for key in &["sihir", "santet", "sorcery", "witchcraft"] {
            self.term_map.insert(key.to_string(), vec!["سحر", "السحر"]);
        }
        for key in &["ruqyah", "rukiah", "rukyah"] {
            self.term_map.insert(key.to_string(), vec!["رقية", "الرقية", "الرقية الشرعية"]);
        }
        for key in &["kesurupan", "possessed", "possession"] {
            self.term_map.insert(key.to_string(), vec!["مس", "المس", "الجن"]);
        }
        // Women's dress code
        for key in &["cadar", "niqab", "niqob"] {
            self.term_map.insert(key.to_string(), vec!["نقاب", "النقاب"]);
        }
        for key in &["jilbab", "hijab", "kerudung", "veil"] {
            self.term_map.insert(key.to_string(), vec!["حجاب", "الحجاب", "جلباب"]);
        }
        // Direction of prayer
        for key in &["kiblat", "qiblat", "qibla", "qiblah"] {
            self.term_map.insert(key.to_string(), vec!["قبلة", "القبلة", "استقبال القبلة"]);
        }
        // Invalidators of wudu
        for key in &["kentut", "buang angin", "flatulence"] {
            self.term_map.insert(key.to_string(), vec!["ريح", "الريح", "حدث", "الحدث"]);
        }
        // Beard
        for key in &["jenggot", "janggut", "beard"] {
            self.term_map.insert(key.to_string(), vec!["لحية", "اللحية", "إعفاء اللحية"]);
        }
        // Engagement & courtship
        for key in &["tunangan", "pertunangan", "engagement"] {
            self.term_map.insert(key.to_string(), vec!["خطبة", "الخطبة"]);
        }
        for key in &["taaruf", "ta'aruf", "ta'arruf"] {
            self.term_map.insert(key.to_string(), vec!["تعارف", "التعارف"]);
        }
        // Puberty
        for key in &["baligh", "balig", "puberty", "aqil baligh"] {
            self.term_map.insert(key.to_string(), vec!["بلوغ", "البلوغ", "بالغ"]);
        }
        // Widow/divorcee
        for key in &["janda", "duda", "widow", "divorcee"] {
            self.term_map.insert(key.to_string(), vec!["مطلقة", "أرملة", "عدة"]);
        }
        // Cupping therapy
        for key in &["bekam", "hijamah", "cupping"] {
            self.term_map.insert(key.to_string(), vec!["حجامة", "الحجامة"]);
        }
        // Gambling
        for key in &["judi", "gambling", "taruhan", "gacha", "lotre", "lottery"] {
            self.term_map.insert(key.to_string(), vec!["قمار", "القمار", "ميسر", "الميسر"]);
        }
        // Insurance (BPJS is Indonesian national health insurance)
        for key in &["bpjs", "jaminan sosial"] {
            self.term_map.insert(key.to_string(), vec!["تأمين", "التأمين", "ضمان"]);
        }
        // Euthanasia & medical ethics
        for key in &["euthanasia", "eutanasia", "suntik mati"] {
            self.term_map.insert(key.to_string(), vec!["قتل الرحمة", "قتل المريض"]);
        }
        for key in &["autopsi", "otopsi", "autopsy"] {
            self.term_map.insert(key.to_string(), vec!["تشريح", "تشريح الجثة"]);
        }
        for key in &["transfusi", "transfusion", "donor darah"] {
            self.term_map.insert(key.to_string(), vec!["نقل الدم", "التبرع بالدم"]);
        }
        // Contraception & sterilization
        for key in &["kondom", "kontrasepsi", "contraception", "kb"] {
            self.term_map.insert(key.to_string(), vec!["منع الحمل", "وسائل منع الحمل", "تنظيم النسل", "عزل"]);
        }
        for key in &["sterilisasi", "vasektomi", "tubektomi", "sterilization"] {
            self.term_map.insert(key.to_string(), vec!["تعقيم", "قطع النسل", "منع الحمل"]);
        }
        for key in &["inseminasi", "bayi tabung", "ivf", "insemination"] {
            self.term_map.insert(key.to_string(), vec!["تلقيح", "التلقيح الاصطناعي"]);
        }
        // Drugs & intoxicants
        for key in &["narkoba", "narkotika", "drugs", "ganja", "marijuana"] {
            self.term_map.insert(key.to_string(), vec!["مخدرات", "المخدرات", "مسكر"]);
        }
        // Gender interaction
        for key in &["ikhtilat", "campur baur", "mixing"] {
            self.term_map.insert(key.to_string(), vec!["اختلاط", "الاختلاط"]);
        }
        // Astrology & fortune-telling
        for key in &["zodiak", "zodiac", "horoskop", "horoscope", "ramalan"] {
            self.term_map.insert(key.to_string(), vec!["تنجيم", "التنجيم", "كهانة"]);
        }
        for key in &["dukun", "paranormal", "fortune teller"] {
            self.term_map.insert(key.to_string(), vec!["كاهن", "كهانة", "عراف"]);
        }
        // Non-Muslim celebrations
        for key in &["valentine", "hallowen", "halloween"] {
            self.term_map.insert(key.to_string(), vec!["أعياد الكفار", "تشبه بالكفار"]);
        }
        for key in &["natal", "christmas", "tahun baru"] {
            self.term_map.insert(key.to_string(), vec!["أعياد الكفار", "تشبه بالكفار", "عيد الميلاد"]);
        }
        // Financial instruments
        for key in &["reksadana", "reksa dana", "mutual fund"] {
            self.term_map.insert(key.to_string(), vec!["صناديق الاستثمار", "استثمار"]);
        }
        for key in &["obligasi", "bonds", "surat utang"] {
            self.term_map.insert(key.to_string(), vec!["سندات", "دين", "ربا"]);
        }
        for key in &["pinjaman", "ngutang", "loan", "pinjol", "paylater"] {
            self.term_map.insert(key.to_string(), vec!["قرض", "القرض", "دين", "الدين"]);
        }
        for key in &["forex", "trading", "saham", "stocks"] {
            self.term_map.insert(key.to_string(), vec!["تجارة", "بيع", "صرف", "مضاربة"]);
        }
        // Dawah & Islamic propagation
        for key in &["dakwah", "dawah", "tabligh"] {
            self.term_map.insert(key.to_string(), vec!["دعوة", "الدعوة", "تبليغ"]);
        }
        // Hypnosis & alternative medicine
        for key in &["hipnotis", "hipnoterapi", "hypnosis"] {
            self.term_map.insert(key.to_string(), vec!["تنويم", "التنويم", "التنويم المغناطيسي"]);
        }
        for key in &["yoga", "meditasi", "meditation"] {
            self.term_map.insert(key.to_string(), vec!["رياضة", "تأمل"]);
        }
        // Itikaf misspelling
        for key in &["tikaf", "iktikaf", "itikaf"] {
            self.term_map.insert(key.to_string(), vec!["اعتكاف", "الاعتكاف"]);
        }
        // Prayer rows
        for key in &["saf", "shaf", "barisan shalat"] {
            self.term_map.insert(key.to_string(), vec!["صف", "الصف", "الصفوف"]);
        }
        // Marriage contract
        for key in &["ijab", "ijab qabul", "akad nikah"] {
            self.term_map.insert(key.to_string(), vec!["إيجاب", "الإيجاب والقبول", "عقد النكاح"]);
        }
        for key in &["qabul", "kabul"] {
            self.term_map.insert(key.to_string(), vec!["قبول", "الإيجاب والقبول"]);
        }
        // Dowry
        for key in &["mahar", "maskawin", "mas kawin", "dowry"] {
            self.term_map.insert(key.to_string(), vec!["مهر", "المهر", "صداق"]);
        }
        // Iddah (waiting period)
        for key in &["iddah", "idah", "masa tunggu"] {
            self.term_map.insert(key.to_string(), vec!["عدة", "العدة"]);
        }
        // Nusyuz (marital disobedience)
        for key in &["nusyuz", "nushuz", "durhaka", "pembangkangan"] {
            self.term_map.insert(key.to_string(), vec!["نشوز", "النشوز"]);
        }
        // Walimah (wedding feast)
        for key in &["walimah", "walimatul urs", "resepsi nikah"] {
            self.term_map.insert(key.to_string(), vec!["وليمة", "الوليمة", "وليمة العرس"]);
        }
        // Qurban specifics
        for key in &["kurban", "qurban", "berkurban", "sacrifice"] {
            self.term_map.insert(key.to_string(), vec!["أضحية", "الأضحية", "ذبح", "قربان"]);
        }
        // Aqiqah
        for key in &["aqiqah", "akikah", "aqikah"] {
            self.term_map.insert(key.to_string(), vec!["عقيقة", "العقيقة"]);
        }
        // Dzikir/remembrance
        for key in &["dzikir", "zikir", "berdzikir", "dhikr", "remembrance"] {
            self.term_map.insert(key.to_string(), vec!["ذكر", "الذكر", "الأذكار"]);
        }
        // Quran recitation
        for key in &["membaca quran", "baca quran", "tilawah", "recitation"] {
            self.term_map.insert(key.to_string(), vec!["قراءة", "تلاوة", "القراءة"]);
        }

        // ═══ BATCH 3: Additional fiqh terms from skenario/kontemporer gap analysis ═══
        // Contract (akad)
        for key in &["akad", "contract", "perjanjian"] {
            self.term_map.insert(key.to_string(), vec!["عقد", "العقد", "العقود"]);
        }
        // Tasyahud (sitting in prayer)
        for key in &["tasyahud", "tasyahhud", "tahiyat", "tahiyyat"] {
            self.term_map.insert(key.to_string(), vec!["تشهد", "التشهد", "التحيات"]);
        }
        // Shaving (cukur)
        for key in &["cukur", "mencukur", "shaving"] {
            self.term_map.insert(key.to_string(), vec!["حلق", "الحلق"]);
        }
        // Nail polish (kutek — blocks wudu water)
        for key in &["kutek", "kuteks", "nail polish"] {
            self.term_map.insert(key.to_string(), vec!["طلاء الأظافر", "أظافر", "المسح"]);
        }
        // Bandage/cast (plester — wudu with bandage)
        for key in &["plester", "perban", "gips", "bandage", "cast"] {
            self.term_map.insert(key.to_string(), vec!["جبيرة", "الجبيرة", "المسح على الجبيرة"]);
        }
        // Piercing
        for key in &["piercing", "tindik"] {
            self.term_map.insert(key.to_string(), vec!["ثقب", "ثقب الأذن", "خرق"]);
        }
        // Epidemic/pandemic
        for key in &["pandemi", "wabah", "epidemic", "pandemic"] {
            self.term_map.insert(key.to_string(), vec!["وباء", "الوباء", "طاعون"]);
        }
        // Handshake (jabat tangan)
        for key in &["jabat", "berjabat", "handshake"] {
            self.term_map.insert(key.to_string(), vec!["مصافحة", "المصافحة"]);
        }
        // Gender/sex change
        for key in &["kelamin", "jenis kelamin", "gender"] {
            self.term_map.insert(key.to_string(), vec!["جنس", "تغيير الجنس"]);
        }
        // Cosplay/imitation
        for key in &["cosplay", "kostum"] {
            self.term_map.insert(key.to_string(), vec!["تشبه", "التشبه"]);
        }
        // Ring (cincin — wudu with ring)
        for key in &["cincin", "ring"] {
            self.term_map.insert(key.to_string(), vec!["خاتم", "الخاتم"]);
        }
        // Nails (kuku — wudu with long nails)
        for key in &["kuku", "nails"] {
            self.term_map.insert(key.to_string(), vec!["أظافر", "الأظافر", "قص الأظافر"]);
        }
        // Dream (mimpi — nocturnal emission)
        for key in &["mimpi", "mimpi basah", "wet dream"] {
            self.term_map.insert(key.to_string(), vec!["احتلام", "الاحتلام", "حلم"]);
        }
        // Eyebrow (alis — plucking eyebrows)
        for key in &["alis", "eyebrow", "mencabut alis"] {
            self.term_map.insert(key.to_string(), vec!["نمص", "النمص", "الحاجب"]);
        }
        // Hair extension
        for key in &["extension", "rambut sambung", "hair extension"] {
            self.term_map.insert(key.to_string(), vec!["وصل الشعر", "الوصل"]);
        }
        // Adopt (anak angkat)
        for key in &["adopsi", "adoption", "anak angkat"] {
            self.term_map.insert(key.to_string(), vec!["تبني", "التبني", "كفالة"]);
        }
        // Organ donation
        for key in &["donor", "donation", "sumbangan organ"] {
            self.term_map.insert(key.to_string(), vec!["تبرع", "التبرع", "نقل الأعضاء"]);
        }
        // PayLater / installment variants
        for key in &["cicilan", "installment", "angsuran"] {
            self.term_map.insert(key.to_string(), vec!["قسط", "أقساط", "بيع التقسيط"]);
        }
        // Online lending
        for key in &["pinjol", "fintech", "lending"] {
            self.term_map.insert(key.to_string(), vec!["قرض", "ربا", "فائدة"]);
        }
        // Voting/election
        for key in &["pemilu", "election", "pilkada", "voting", "memilih"] {
            self.term_map.insert(key.to_string(), vec!["انتخاب", "الانتخاب", "اختيار"]);
        }

        // ═══ Batch 4: English term gap-fill ═══
        // Alms/charity
        for key in &["alms", "charity", "charitable"] {
            self.term_map.insert(key.to_string(), vec!["صدقة", "الصدقة", "إحسان"]);
        }
        // Buying/selling/trade
        for key in &["buying", "selling", "trade", "trading", "transaction"] {
            self.term_map.insert(key.to_string(), vec!["بيع", "شراء", "تجارة", "البيوع"]);
        }
        // Conditions/requirements
        for key in &["conditions", "requirements", "prerequisites"] {
            self.term_map.insert(key.to_string(), vec!["شروط", "الشروط", "شرط"]);
        }
        // Creed/belief
        for key in &["creed", "belief", "theology"] {
            self.term_map.insert(key.to_string(), vec!["عقيدة", "العقيدة", "إيمان"]);
        }
        // Cryptocurrency
        self.term_map.insert("cryptocurrency".to_string(), vec!["عملة رقمية", "بيتكوين", "ربا", "صرف"]);
        // Custody
        for key in &["custody", "guardianship"] {
            self.term_map.insert(key.to_string(), vec!["حضانة", "الحضانة", "كفالة"]);
        }
        // Eclipse
        for key in &["eclipse", "lunar", "solar"] {
            self.term_map.insert(key.to_string(), vec!["كسوف", "خسوف", "صلاة الكسوف"]);
        }
        // Eid
        self.term_map.insert("eid".to_string(), vec!["عيد", "العيد", "عيد الفطر", "عيد الأضحى"]);
        // Ethics/morals
        for key in &["ethics", "morals", "morality", "virtue"] {
            self.term_map.insert(key.to_string(), vec!["أخلاق", "الأخلاق", "فضيلة", "آداب"]);
        }
        // Guardian/wali
        self.term_map.insert("guardian".to_string(), vec!["ولي", "الولي", "ولاية"]);
        // Istisqa (rain prayer)
        self.term_map.insert("istisqa".to_string(), vec!["استسقاء", "صلاة الاستسقاء"]);
        // Janabah (major impurity)
        self.term_map.insert("janabah".to_string(), vec!["جنابة", "الجنابة", "غسل الجنابة"]);
        // Jihad
        self.term_map.insert("jihad".to_string(), vec!["جهاد", "الجهاد", "قتال"]);
        // Lease/rent
        for key in &["lease", "rent", "rental", "leasing"] {
            self.term_map.insert(key.to_string(), vec!["إجارة", "الإجارة", "أجرة"]);
        }
        // Makeup/cosmetics
        for key in &["makeup", "cosmetics", "beautification"] {
            self.term_map.insert(key.to_string(), vec!["زينة", "تجميل", "الزينة"]);
        }
        // Men/women
        self.term_map.insert("men".to_string(), vec!["رجال", "الرجال", "رجل"]);
        self.term_map.insert("women".to_string(), vec!["نساء", "النساء", "المرأة"]);
        // Missed (prayers)
        self.term_map.insert("missed".to_string(), vec!["قضاء", "فائتة", "الفوائت"]);
        // Narration/hadith chain
        for key in &["narration", "narrator", "chain"] {
            self.term_map.insert(key.to_string(), vec!["رواية", "إسناد", "سند", "راوي"]);
        }
        // Night (prayer)
        self.term_map.insert("night".to_string(), vec!["ليل", "الليل", "قيام الليل"]);
        // Photography/images
        for key in &["photography", "photos", "images", "pictures"] {
            self.term_map.insert(key.to_string(), vec!["تصوير", "صورة", "التصوير"]);
        }
        // Pillars
        for key in &["pillars", "pillar", "rukun"] {
            self.term_map.insert(key.to_string(), vec!["أركان", "ركن", "الأركان"]);
        }
        // Pledge/collateral
        self.term_map.insert("pledge".to_string(), vec!["رهن", "الرهن", "ضمان"]);
        // Predestination/fate
        for key in &["predestination", "fate", "destiny", "qadr"] {
            self.term_map.insert(key.to_string(), vec!["قضاء", "قدر", "القضاء والقدر"]);
        }
        // Rain
        self.term_map.insert("rain".to_string(), vec!["مطر", "استسقاء", "صلاة الاستسقاء"]);
        // Resident/traveler
        for key in &["resident", "traveler", "travel", "journey"] {
            self.term_map.insert(key.to_string(), vec!["مقيم", "مسافر", "السفر", "قصر"]);
        }
        // Silk
        self.term_map.insert("silk".to_string(), vec!["حرير", "الحرير", "لبس الحرير"]);
        // Tithe/ushr
        for key in &["tithe", "ushr", "tenth"] {
            self.term_map.insert(key.to_string(), vec!["عشر", "العشر", "زكاة الزروع"]);
        }
        // Treason/rebellion
        for key in &["treason", "rebellion", "revolt"] {
            self.term_map.insert(key.to_string(), vec!["بغي", "البغاة", "خروج"]);
        }
        // Vaping/smoking
        for key in &["vaping", "vape", "smoking", "cigarette", "tobacco"] {
            self.term_map.insert(key.to_string(), vec!["تدخين", "التدخين", "تبغ"]);
        }
        // War/combat
        self.term_map.insert("war".to_string(), vec!["حرب", "الحرب", "جهاد", "قتال"]);
        // Wedding/ceremony
        self.term_map.insert("wedding".to_string(), vec!["زفاف", "وليمة", "عرس", "وليمة العرس"]);
        // Direction (qibla)
        self.term_map.insert("direction".to_string(), vec!["قبلة", "اتجاه", "استقبال القبلة"]);
        // Defense/self-defense
        for key in &["defense", "defence", "self-defense"] {
            self.term_map.insert(key.to_string(), vec!["دفاع", "الدفاع", "دفع الصائل"]);
        }
        // Commentary/exegesis
        for key in &["commentary", "exegesis", "interpretation"] {
            self.term_map.insert(key.to_string(), vec!["تفسير", "التفسير", "شرح", "تأويل"]);
        }

        // ═══ Batch 5: Usul fiqh, standalone worship, comparative religion terms ═══
        // Usul fiqh methodology terms
        for key in &["istihsan", "istihsaan"] {
            self.term_map.insert(key.to_string(), vec!["استحسان", "الاستحسان"]);
        }
        for key in &["istishab", "istishhab"] {
            self.term_map.insert(key.to_string(), vec!["استصحاب", "الاستصحاب"]);
        }
        for key in &["urf", "'urf"] {
            self.term_map.insert(key.to_string(), vec!["عرف", "العرف", "العادة"]);
        }
        for key in &["maqashid", "maqasid", "maqosid"] {
            self.term_map.insert(key.to_string(), vec!["مقاصد الشريعة", "المقاصد", "مقاصد"]);
        }
        for key in &["istidlal", "istidlaal"] {
            self.term_map.insert(key.to_string(), vec!["استدلال", "الاستدلال"]);
        }
        for key in &["dzariah", "dzari'ah", "zariah", "zari'ah"] {
            self.term_map.insert(key.to_string(), vec!["ذريعة", "سد الذرائع", "الذرائع"]);
        }
        for key in &["hifzh", "hifz", "hifdz"] {
            self.term_map.insert(key.to_string(), vec!["حفظ", "الحفظ"]);
        }
        for key in &["istinbath", "istinbat"] {
            self.term_map.insert(key.to_string(), vec!["استنباط", "الاستنباط"]);
        }
        for key in &["tarjih", "tarjeh"] {
            self.term_map.insert(key.to_string(), vec!["ترجيح", "الترجيح"]);
        }
        // Standalone worship terms (previously only in phrase_map)
        for key in &["tarawih", "taraweeh", "taraweh"] {
            self.term_map.insert(key.to_string(), vec!["تراويح", "التراويح", "صلاة التراويح"]);
        }
        for key in &["witir", "witr", "witer"] {
            self.term_map.insert(key.to_string(), vec!["وتر", "الوتر", "صلاة الوتر"]);
        }
        for key in &["basmalah", "basmala", "bismillah"] {
            self.term_map.insert(key.to_string(), vec!["بسملة", "البسملة", "بسم الله"]);
        }
        self.term_map.insert("tarji'".to_string(), vec!["ترجيع", "الترجيع"]);
        self.term_map.insert("tarji".to_string(), vec!["ترجيع", "الترجيع"]);
        // Betrothal/engagement
        for key in &["khitbah", "meminang", "melamar", "pinangan", "lamaran"] {
            self.term_map.insert(key.to_string(), vec!["خطبة", "الخطبة", "خطبة النكاح"]);
        }
        // Comparative religion
        for key in &["trinitas", "trinity"] {
            self.term_map.insert(key.to_string(), vec!["تثليث", "الثالوث"]);
        }
        for key in &["jizyah", "jizya", "jizyat"] {
            self.term_map.insert(key.to_string(), vec!["جزية", "الجزية"]);
        }
        // Food categories
        self.term_map.insert("sushi".to_string(), vec!["سمك", "أكل السمك", "حكم الأسماك"]);
        self.term_map.insert("sashimi".to_string(), vec!["سمك", "أكل السمك نيئاً", "اللحم النيء"]);
        // Fiqh analysis terms
        self.term_map.insert("illat".to_string(), vec!["علة", "العلة"]);
        for key in &["mansukh", "nasikh", "naskh"] {
            self.term_map.insert(key.to_string(), vec!["نسخ", "الناسخ والمنسوخ", "النسخ"]);
        }
        self.term_map.insert("mutlaq".to_string(), vec!["مطلق", "المطلق"]);
        self.term_map.insert("muqayyad".to_string(), vec!["مقيد", "المقيد"]);
        self.term_map.insert("aam".to_string(), vec!["عام", "العام"]);
        self.term_map.insert("khash".to_string(), vec!["خاص", "الخاص"]);

        // ═══════════════════════════════════════════════════════════
        // BATCH 6 (V16): 479 ZERO-RESULT FIXES — confirmed by audit_zeros.py
        // All 479 failures were zero-term translation failures; this batch
        // adds every missing term identified in that audit.
        // ═══════════════════════════════════════════════════════════

        // ── HAJJ: missing pillar terms ──
        for key in &["jumrah", "jamroh", "jumroh"] {
            self.term_map.insert(key.to_string(), vec!["جمرة", "الجمرات", "رمي الجمرات"]);
        }
        for key in &["tahallul", "tahalul", "tahallal"] {
            self.term_map.insert(key.to_string(), vec!["تحلل", "التحلل", "التحلل الأول", "التحلل الثاني"]);
        }
        for key in &["mabit"] {
            self.term_map.insert(key.to_string(), vec!["مبيت", "المبيت بمزدلفة", "المبيت بمنى"]);
        }
        for key in &["muzdalifah"] {
            self.term_map.insert(key.to_string(), vec!["مزدلفة", "المبيت بمزدلفة"]);
        }
        for key in &["sahur", "sahor"] {
            self.term_map.insert(key.to_string(), vec!["سحور", "السحور", "الإمساك"]);
        }
        for key in &["imsak", "imsakiah"] {
            self.term_map.insert(key.to_string(), vec!["إمساك", "وقت الإمساك"]);
        }

        // ── MUAMALAT: missing contracts & commercial terms ──
        for key in &["wakalah", "wakala"] {
            self.term_map.insert(key.to_string(), vec!["وكالة", "الوكالة", "الوكيل"]);
        }
        for key in &["kafalah", "kafala"] {
            self.term_map.insert(key.to_string(), vec!["كفالة", "الكفالة", "ضمان"]);
        }
        for key in &["khiyar"] {
            self.term_map.insert(key.to_string(), vec!["خيار", "الخيار", "خيار المجلس", "خيار الشرط", "خيار العيب"]);
        }
        for key in &["gharar"] {
            self.term_map.insert(key.to_string(), vec!["غرر", "الغرر", "بيع الغرر"]);
        }
        for key in &["maysir", "qimar"] {
            self.term_map.insert(key.to_string(), vec!["ميسر", "الميسر", "قمار"]);
        }
        for key in &["murabahah", "murabaha"] {
            self.term_map.insert(key.to_string(), vec!["مرابحة", "المرابحة", "بيع المرابحة"]);
        }
        for key in &["istishna", "istisnaa"] {
            self.term_map.insert(key.to_string(), vec!["استصناع", "الاستصناع", "عقد الاستصناع"]);
        }
        for key in &["syuf'ah", "syufah", "syufa"] {
            self.term_map.insert(key.to_string(), vec!["شفعة", "الشفعة"]);
        }
        for key in &["luqathah", "luqatha"] {
            self.term_map.insert(key.to_string(), vec!["لقطة", "اللقطة"]);
        }
        for key in &["ji'alah", "ji'ala", "ji'alah"] {
            self.term_map.insert(key.to_string(), vec!["جعالة", "الجعالة"]);
        }
        for key in &["qardh", "qard"] {
            self.term_map.insert(key.to_string(), vec!["قرض", "القرض"]);
        }
        for key in &["hadhanah", "hadzanah"] {
            self.term_map.insert(key.to_string(), vec!["حضانة", "الحضانة"]);
        }
        for key in &["syirkah"] {
            self.term_map.insert(key.to_string(), vec!["شركة", "الشركة", "الشركات"]);
        }
        for key in &["abdan"] {
            self.term_map.insert(key.to_string(), vec!["شركة الأبدان", "الأبدان"]);
        }
        for key in &["inan"] {
            self.term_map.insert(key.to_string(), vec!["شركة العنان", "العنان"]);
        }
        for key in &["mufawadhah"] {
            self.term_map.insert(key.to_string(), vec!["شركة المفاوضة", "المفاوضة"]);
        }
        for key in &["kpr", "KPR"] {
            self.term_map.insert(key.to_string(), vec!["تمويل عقاري", "مرابحة عقارية", "بيع بالتقسيط"]);
        }
        // dzawil furudh = heirs with fixed shares
        for key in &["dzawil", "zawil", "ashhabul"] {
            self.term_map.insert(key.to_string(), vec!["ذوو الفروض", "أصحاب الفروض"]);
        }
        for key in &["furudh"] {
            self.term_map.insert(key.to_string(), vec!["الفروض", "ذوو الفروض"]);
        }
        for key in &["karya", "karangan", "tulisan"] {
            self.term_map.insert(key.to_string(), vec!["مؤلفات", "كتب", "تأليف"]);
        }

        // ── AQIDAH: Theological terms ──
        for key in &["kufur", "kufr"] {
            self.term_map.insert(key.to_string(), vec!["كفر", "الكفر", "أنواع الكفر"]);
        }
        for key in &["nifaq", "kemunafikan"] {
            self.term_map.insert(key.to_string(), vec!["نفاق", "النفاق", "المنافق"]);
        }
        for key in &["munafik", "munafiq"] {
            self.term_map.insert(key.to_string(), vec!["منافق", "المنافق", "علامات النفاق"]);
        }
        for key in &["fasiq", "fasik"] {
            self.term_map.insert(key.to_string(), vec!["فاسق", "الفسق", "الفاسق"]);
        }
        for key in &["asy'ariyah", "asyariyah", "ashariyah"] {
            self.term_map.insert(key.to_string(), vec!["أشعرية", "الأشعرية"]);
        }
        for key in &["maturidiyah", "maturidiyyah"] {
            self.term_map.insert(key.to_string(), vec!["ماتريدية", "الماتريدية"]);
        }
        for key in &["manhaj"] {
            self.term_map.insert(key.to_string(), vec!["منهج", "منهج السلف"]);
        }
        for key in &["maulid", "maulud", "milad nabi"] {
            self.term_map.insert(key.to_string(), vec!["مولد", "المولد النبوي", "الاحتفال بالمولد"]);
        }
        for key in &["jimat", "azimat", "talisman", "amulet"] {
            self.term_map.insert(key.to_string(), vec!["تميمة", "التمائم"]);
        }
        for key in &["rajah"] {
            self.term_map.insert(key.to_string(), vec!["رقية", "الرقية"]);
        }
        for key in &["keramat", "karamah", "karomah"] {
            self.term_map.insert(key.to_string(), vec!["كرامة", "الكرامة", "كرامات الأولياء"]);
        }

        // ── IBADAH: Prayer specifics ──
        for key in &["tahajjud", "qiyamullail"] {
            self.term_map.insert(key.to_string(), vec!["تهجد", "التهجد", "قيام الليل", "صلاة التهجد"]);
        }
        for key in &["masah"] {
            self.term_map.insert(key.to_string(), vec!["مسح", "المسح على الخفين", "خفان"]);
        }
        for key in &["wirid", "wird"] {
            self.term_map.insert(key.to_string(), vec!["ورد", "الأوراد", "ورد الصباح", "ورد المساء"]);
        }
        for key in &["istighatsah", "istighasah", "istighosah"] {
            self.term_map.insert(key.to_string(), vec!["استغاثة", "الاستغاثة"]);
        }
        for key in &["ratib", "ratibah"] {
            self.term_map.insert(key.to_string(), vec!["راتب", "الراتبة", "السنن الرواتب"]);
        }
        for key in &["i'tidal", "iktidal"] {
            self.term_map.insert(key.to_string(), vec!["اعتدال", "الاعتدال", "الاعتدال من الركوع"]);
        }
        for key in &["tumakninah", "tumaninah", "tuma'ninah"] {
            self.term_map.insert(key.to_string(), vec!["طمأنينة", "الطمأنينة"]);
        }
        for key in &["ta'awwudz", "ta'awwuz", "taawudz"] {
            self.term_map.insert(key.to_string(), vec!["تعوذ", "الاستعاذة", "أعوذ بالله"]);
        }
        for key in &["amin", "amiin", "ameen"] {
            self.term_map.insert(key.to_string(), vec!["آمين", "التأمين", "الجهر بآمين"]);
        }
        for key in &["shalawat", "salawat"] {
            self.term_map.insert(key.to_string(), vec!["الصلاة على النبي", "صلوات", "فضل الصلاة على النبي"]);
        }
        for key in &["istighfar", "istighfaar"] {
            self.term_map.insert(key.to_string(), vec!["استغفار", "الاستغفار", "فضل الاستغفار"]);
        }
        for key in &["istinja", "istinja'"] {
            self.term_map.insert(key.to_string(), vec!["استنجاء", "الاستنجاء"]);
        }
        for key in &["waktu"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["وقت", "الوقت", "الأوقات"]);
        }

        // ── JINAYAT: Criminal fiqh ──
        for key in &["qishas", "qisas"] {
            self.term_map.insert(key.to_string(), vec!["قصاص", "القصاص", "حد القصاص"]);
        }
        for key in &["hirabah", "hiraba"] {
            self.term_map.insert(key.to_string(), vec!["حرابة", "الحرابة", "المحاربة"]);
        }
        for key in &["bughat", "bugat"] {
            self.term_map.insert(key.to_string(), vec!["بغاة", "البغاة", "الخروج على الإمام"]);
        }
        for key in &["jinayah", "jinayat"] {
            self.term_map.insert(key.to_string(), vec!["جناية", "الجنايات"]);
        }
        for key in &["janin", "jaenin"] {
            self.term_map.insert(key.to_string(), vec!["جنين", "الجنين", "الجناية على الجنين"]);
        }
        for key in &["arsy"] {
            self.term_map.insert(key.to_string(), vec!["أرش", "الأرش", "دية الأطراف"]);
        }
        for key in &["hukumah"] {
            self.term_map.insert(key.to_string(), vec!["حكومة", "حكومة العدل"]);
        }
        for key in &["ghurah", "ghurah janin"] {
            self.term_map.insert(key.to_string(), vec!["غرة", "دية الجنين"]);
        }

        // ── AKHLAQ: Virtues and vices ──
        for key in &["tawadhu", "tawadu"] {
            self.term_map.insert(key.to_string(), vec!["تواضع", "التواضع"]);
        }
        for key in &["kibr", "takabbur"] {
            self.term_map.insert(key.to_string(), vec!["كبر", "الكبر", "التكبر"]);
        }
        for key in &["husnuzhan", "husnu dzan"] {
            self.term_map.insert(key.to_string(), vec!["حسن الظن"]);
        }
        for key in &["su'uzhan", "suuzhan"] {
            self.term_map.insert(key.to_string(), vec!["سوء الظن"]);
        }
        for key in &["birrul walidain", "birr al walidain"] {
            self.term_map.insert(key.to_string(), vec!["بر الوالدين", "عقوق الوالدين"]);
        }
        for key in &["silaturahmi", "silaturahim"] {
            self.term_map.insert(key.to_string(), vec!["صلة الرحم", "الرحم"]);
        }
        for key in &["keutamaan", "fadilah", "fadhilah"] {
            self.term_map.insert(key.to_string(), vec!["فضل", "فضائل", "الفضل"]);
        }
        for key in &["mahmudah", "terpuji"] {
            self.term_map.insert(key.to_string(), vec!["صفات محمودة", "الفضائل"]);
        }
        for key in &["madzmumah", "tercela"] {
            self.term_map.insert(key.to_string(), vec!["صفات مذمومة", "الرذائل"]);
        }

        // ── TASAWUF: Spiritual states (maqamat) ──
        for key in &["muraqabah", "muroqobah"] {
            self.term_map.insert(key.to_string(), vec!["مراقبة", "المراقبة"]);
        }
        for key in &["muhasabah", "muhasabat"] {
            self.term_map.insert(key.to_string(), vec!["محاسبة", "المحاسبة", "محاسبة النفس"]);
        }
        for key in &["mahabbah"] {
            self.term_map.insert(key.to_string(), vec!["محبة", "المحبة", "المحبة لله"]);
        }
        for key in &["khauf"] {
            self.term_map.insert(key.to_string(), vec!["خوف", "الخوف", "الخشية"]);
        }
        for key in &["raja'", "raja"] {
            // Islamic spiritual concept: hope/longing for Allah's mercy
            self.term_map.entry(key.to_string()).or_insert(vec!["رجاء", "الرجاء"]);
        }
        for key in &["zuhud", "zuhd"] {
            self.term_map.insert(key.to_string(), vec!["زهد", "الزهد"]);
        }
        for key in &["wara'", "wara"] {
            self.term_map.insert(key.to_string(), vec!["ورع", "الورع"]);
        }
        for key in &["tarekat", "thariqat", "tariqah"] {
            self.term_map.insert(key.to_string(), vec!["طريقة", "الطريقة", "الطرق الصوفية"]);
        }
        for key in &["naqsyabandiyah", "naqsybandiyah", "naqshbandiyya"] {
            self.term_map.insert(key.to_string(), vec!["نقشبندية", "الطريقة النقشبندية"]);
        }
        for key in &["qadiriyah", "qadiriyyah", "qadiri"] {
            self.term_map.insert(key.to_string(), vec!["قادرية", "الطريقة القادرية"]);
        }

        // ── ULUMUL QURAN: Quran sciences ──
        for key in &["makiyyah", "makkiyah"] {
            self.term_map.insert(key.to_string(), vec!["مكية", "المكي", "السور المكية"]);
        }
        for key in &["madaniyyah", "madaniyah"] {
            self.term_map.insert(key.to_string(), vec!["مدنية", "المدني", "السور المدنية"]);
        }
        for key in &["muhkam"] {
            self.term_map.insert(key.to_string(), vec!["محكم", "المحكم", "المحكم والمتشابه"]);
        }
        for key in &["mutasyabih", "mutashabih"] {
            self.term_map.insert(key.to_string(), vec!["متشابه", "المتشابه"]);
        }
        for key in &["i'jaz", "ijaz"] {
            self.term_map.insert(key.to_string(), vec!["إعجاز", "الإعجاز", "إعجاز القرآن"]);
        }
        for key in &["qira'at", "qiraah", "qiraat"] {
            self.term_map.insert(key.to_string(), vec!["قراءات", "القراءات السبع", "القراءات"]);
        }
        for key in &["tahfidz", "hafidz"] {
            self.term_map.insert(key.to_string(), vec!["حفظ القرآن", "تحفيظ القرآن"]);
        }
        for key in &["quran", "alquran", "qur'an"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["القرآن", "القرآن الكريم"]);
        }

        // ── HADITH BOOKS: proper noun references ──
        for key in &["bukhari"] {
            self.term_map.insert(key.to_string(), vec!["صحيح البخاري", "البخاري"]);
        }
        for key in &["abu dawud"] {
            self.term_map.insert(key.to_string(), vec!["سنن أبي داود", "أبو داود"]);
        }
        for key in &["tirmidzi", "tirmizi", "tirmidhi"] {
            self.term_map.insert(key.to_string(), vec!["سنن الترمذي", "الترمذي"]);
        }
        for key in &["nasa'i", "nasai"] {
            self.term_map.insert(key.to_string(), vec!["سنن النسائي", "النسائي"]);
        }
        for key in &["ibnu majah", "ibn majah"] {
            self.term_map.insert(key.to_string(), vec!["سنن ابن ماجه", "ابن ماجه"]);
        }
        for key in &["musnad"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مسند أحمد", "المسند"]);
        }
        for key in &["muwattha"] {
            self.term_map.insert(key.to_string(), vec!["الموطأ", "موطأ مالك"]);
        }

        // ── CLASSICAL KITAB: Book title references ──
        for key in &["ihya"] {
            self.term_map.insert(key.to_string(), vec!["إحياء علوم الدين", "الغزالي"]);
        }
        for key in &["bidayatul mujtahid"] {
            self.term_map.insert(key.to_string(), vec!["بداية المجتهد", "ابن رشد"]);
        }
        for key in &["fathul qarib"] {
            self.term_map.insert(key.to_string(), vec!["فتح القريب", "التقريب"]);
        }
        for key in &["fathul mu'in", "fathul muin"] {
            self.term_map.insert(key.to_string(), vec!["فتح المعين", "زين الدين"]);
        }
        for key in &["kifayatul akhyar"] {
            self.term_map.insert(key.to_string(), vec!["كفاية الأخيار"]);
        }
        for key in &["tuhfatul muhtaj"] {
            self.term_map.insert(key.to_string(), vec!["تحفة المحتاج", "ابن حجر الهيتمي"]);
        }
        for key in &["nihayatul muhtaj"] {
            self.term_map.insert(key.to_string(), vec!["نهاية المحتاج", "الرملي"]);
        }
        for key in &["mughnil muhtaj"] {
            self.term_map.insert(key.to_string(), vec!["مغني المحتاج", "الشربيني"]);
        }
        for key in &["raudhatut thalibin", "raudhat thalibin"] {
            self.term_map.insert(key.to_string(), vec!["روضة الطالبين", "النووي"]);
        }
        for key in &["riyadhus shalihin"] {
            self.term_map.insert(key.to_string(), vec!["رياض الصالحين", "النووي"]);
        }
        for key in &["bulughul maram"] {
            self.term_map.insert(key.to_string(), vec!["بلوغ المرام", "ابن حجر العسقلاني"]);
        }
        for key in &["subulussalam"] {
            self.term_map.insert(key.to_string(), vec!["سبل السلام", "الصنعاني"]);
        }
        for key in &["nailul authar"] {
            self.term_map.insert(key.to_string(), vec!["نيل الأوطار", "الشوكاني"]);
        }
        for key in &["kifayah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["كفاية", "الكفاية"]);
        }
        for key in &["tuhfah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["تحفة"]);
        }
        for key in &["nihayah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["نهاية"]);
        }
        for key in &["mughni"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مغني"]);
        }
        for key in &["raudhah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["روضة"]);
        }
        for key in &["bulugh"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["بلوغ"]);
        }
        for key in &["subul"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["سبل"]);
        }

        // ── USUL FIQH: additional principles ──
        for key in &["mujmal"] {
            self.term_map.insert(key.to_string(), vec!["مجمل", "المجمل"]);
        }
        for key in &["mubayyan", "bayyin"] {
            self.term_map.insert(key.to_string(), vec!["مبين", "البيان", "المبين"]);
        }
        for key in &["haqiqi"] {
            self.term_map.insert(key.to_string(), vec!["حقيقة", "الحقيقي"]);
        }
        for key in &["majazi"] {
            self.term_map.insert(key.to_string(), vec!["مجاز", "المجاز"]);
        }
        for key in &["rukhshah", "rukhsah"] {
            self.term_map.insert(key.to_string(), vec!["رخصة", "الرخصة"]);
        }
        for key in &["azimah", "aziimah"] {
            self.term_map.insert(key.to_string(), vec!["عزيمة", "العزيمة"]);
        }
        for key in &["dharurah", "darurah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ضرورة", "الضرورة", "الاضطرار"]);
        }
        for key in &["kaidah"] {
            self.term_map.insert(key.to_string(), vec!["قاعدة", "القواعد", "القواعد الفقهية"]);
        }
        for key in &["mujtahid"] {
            self.term_map.insert(key.to_string(), vec!["مجتهد", "الاجتهاد", "مجتهد مطلق"]);
        }
        for key in &["khas", "khusus"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["خاص", "الخاص"]);
        }

        // ── SIRAH: Islamic history ──
        for key in &["badr"] {
            self.term_map.insert(key.to_string(), vec!["غزوة بدر", "بدر"]);
        }
        for key in &["uhud"] {
            self.term_map.insert(key.to_string(), vec!["غزوة أحد", "أحد"]);
        }
        for key in &["khandaq", "ahzab"] {
            self.term_map.insert(key.to_string(), vec!["غزوة الخندق", "الأحزاب"]);
        }
        for key in &["fathu makkah"] {
            self.term_map.insert(key.to_string(), vec!["فتح مكة"]);
        }
        for key in &["isra miraj", "isra' mi'raj"] {
            self.term_map.insert(key.to_string(), vec!["الإسراء والمعراج", "إسراء"]);
        }
        for key in &["piagam madinah"] {
            self.term_map.insert(key.to_string(), vec!["وثيقة المدينة", "صحيفة المدينة"]);
        }
        for key in &["khulafaur rasyidin"] {
            self.term_map.insert(key.to_string(), vec!["الخلفاء الراشدون"]);
        }
        for key in &["umayyah"] {
            self.term_map.insert(key.to_string(), vec!["بنو أمية", "الدولة الأموية"]);
        }
        for key in &["abbasiyah"] {
            self.term_map.insert(key.to_string(), vec!["بنو العباس", "الدولة العباسية"]);
        }
        for key in &["perang"] {
            self.term_map.insert(key.to_string(), vec!["غزوة", "معركة", "حرب"]);
        }

        // ── SCHOLARS: proper noun references ──
        for key in &["ibnu taimiyah", "ibn taimiyah", "ibnu taymiyah"] {
            self.term_map.insert(key.to_string(), vec!["ابن تيمية"]);
        }
        for key in &["ibnu qayyim", "ibn qayyim", "ibnul qayyim"] {
            self.term_map.insert(key.to_string(), vec!["ابن القيم"]);
        }
        for key in &["ibnu hajar haitami", "ibn hajar haitami"] {
            self.term_map.insert(key.to_string(), vec!["ابن حجر الهيتمي"]);
        }
        for key in &["ibnu hajar", "ibn hajar"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ابن حجر", "ابن حجر العسقلاني"]);
        }
        for key in &["abu bakar", "abu bakr"] {
            self.term_map.insert(key.to_string(), vec!["أبو بكر", "أبو بكر الصديق"]);
        }
        for key in &["umar bin khattab"] {
            self.term_map.insert(key.to_string(), vec!["عمر بن الخطاب"]);
        }
        for key in &["utsman bin affan"] {
            self.term_map.insert(key.to_string(), vec!["عثمان بن عفان"]);
        }
        for key in &["khadijah"] {
            self.term_map.insert(key.to_string(), vec!["خديجة", "خديجة بنت خويلد"]);
        }
        for key in &["aisyah", "aisha"] {
            self.term_map.insert(key.to_string(), vec!["عائشة", "عائشة بنت أبي بكر"]);
        }
        for key in &["fatimah"] {
            self.term_map.insert(key.to_string(), vec!["فاطمة", "فاطمة الزهراء"]);
        }
        for key in &["hamzah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["حمزة بن عبد المطلب"]);
        }
        for key in &["khalid bin walid"] {
            self.term_map.insert(key.to_string(), vec!["خالد بن الوليد"]);
        }
        // ─── Single-word fallbacks for dead multi-word scholar keys ───
        for key in &["khalid"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["خالد", "خالد بن الوليد"]);
        }
        for key in &["sina"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ابن سينا", "سينا"]);
        }
        for key in &["rusyd"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ابن رشد", "رشد"]);
        }
        for key in &["khaldun"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ابن خلدون", "خلدون"]);
        }
        for key in &["utsman"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["عثمان", "عثمان بن عفان"]);
        }
        for key in &["khattab"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الخطاب", "عمر بن الخطاب"]);
        }
        for key in &["affan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["عفان", "عثمان بن عفان"]);
        }
        for key in &["jalaluddin"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["جلال الدين", "السيوطي"]);
        }
        for key in &["bakar"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["أبو بكر", "الصديق"]);
        }
        for key in &["riwayat"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["رواية", "سيرة"]);
        }
        for key in &["ibn"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ابن", "بن"]);
        }
        for key in &["binti"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["بنت"]);
        }
        for key in &["bin"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["بن"]);
        }
        // ─── Islamic month single-word fallbacks (multi-word keys are dead) ───
        for key in &["rabiul", "rabi"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ربيع", "ربيع الأول"]);
        }
        for key in &["jumadil", "jumada"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["جمادى"]);
        }
        for key in &["dzulqa'dah", "dzulqadah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ذو القعدة"]);
        }
        for key in &["dzulhijjah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ذو الحجة"]);
        }
        for key in &["ibn sina", "ibnu sina", "avicenna"] {
            self.term_map.insert(key.to_string(), vec!["ابن سينا"]);
        }
        for key in &["ibn rusyd", "ibnu rusyd", "averroes"] {
            self.term_map.insert(key.to_string(), vec!["ابن رشد"]);
        }
        for key in &["ibn khaldun", "ibnu khaldun"] {
            self.term_map.insert(key.to_string(), vec!["ابن خلدون"]);
        }
        for key in &["suyuthi", "as-suyuthi", "jalaluddin suyuthi"] {
            self.term_map.insert(key.to_string(), vec!["السيوطي", "جلال الدين السيوطي"]);
        }
        for key in &["nawawi", "imam nawawi", "an nawawi"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["النووي", "الإمام النووي"]);
        }
        for key in &["ghazali", "al ghazali", "imam ghazali"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الغزالي", "حجة الإسلام"]);
        }
        for key in &["biografi", "riwayat hidup"] {
            self.term_map.insert(key.to_string(), vec!["سيرة", "ترجمة", "حياة"]);
        }

        // ── ISLAMIC MONTHS ──
        for key in &["muharram"] {
            self.term_map.insert(key.to_string(), vec!["محرم", "شهر محرم"]);
        }
        for key in &["rabiul awal", "rabi al awwal"] {
            self.term_map.insert(key.to_string(), vec!["ربيع الأول", "شهر المولد"]);
        }
        for key in &["rabiul akhir"] {
            self.term_map.insert(key.to_string(), vec!["ربيع الآخر"]);
        }
        for key in &["jumadil awal"] {
            self.term_map.insert(key.to_string(), vec!["جمادى الأولى"]);
        }
        for key in &["jumadil akhir"] {
            self.term_map.insert(key.to_string(), vec!["جمادى الآخرة"]);
        }
        for key in &["rajab"] {
            self.term_map.insert(key.to_string(), vec!["رجب", "شهر رجب"]);
        }
        for key in &["sya'ban", "syaban", "sha'ban"] {
            self.term_map.insert(key.to_string(), vec!["شعبان", "شهر شعبان"]);
        }
        for key in &["syawal", "shawwal"] {
            self.term_map.insert(key.to_string(), vec!["شوال", "شهر شوال"]);
        }
        for key in &["dzulqa'dah", "dzulqadah"] {
            self.term_map.insert(key.to_string(), vec!["ذو القعدة"]);
        }
        for key in &["dzulhijjah", "dzulhijja"] {
            self.term_map.insert(key.to_string(), vec!["ذو الحجة", "شهر ذي الحجة"]);
        }
        for key in &["nisfu sya'ban", "nisfu syaban"] {
            self.term_map.insert(key.to_string(), vec!["ليلة النصف من شعبان", "نصف شعبان"]);
        }
        for key in &["nisfu"] {
            self.term_map.insert(key.to_string(), vec!["نصف", "ليلة النصف"]);
        }

        // ── DAYS OF WEEK ──
        for key in &["senin", "hari senin", "monday"] {
            self.term_map.insert(key.to_string(), vec!["الاثنين", "يوم الاثنين"]);
        }
        for key in &["selasa", "tuesday"] {
            self.term_map.insert(key.to_string(), vec!["الثلاثاء", "يوم الثلاثاء"]);
        }
        for key in &["rabu", "wednesday"] {
            self.term_map.insert(key.to_string(), vec!["الأربعاء", "يوم الأربعاء"]);
        }
        for key in &["kamis", "thursday"] {
            self.term_map.insert(key.to_string(), vec!["الخميس", "يوم الخميس"]);
        }
        for key in &["sabtu", "saturday"] {
            self.term_map.insert(key.to_string(), vec!["السبت", "يوم السبت"]);
        }
        for key in &["ahad", "minggu", "sunday"] {
            self.term_map.insert(key.to_string(), vec!["الأحد", "يوم الأحد"]);
        }

        // ── PARADISE / HELL / ANGELS ──
        for key in &["paradise", "heaven", "jannah", "surga", "syurga"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["جنة", "الجنة", "نعيم الجنة"]);
        }
        for key in &["hellfire", "hell", "jahannam", "neraka"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["نار", "جهنم", "عذاب النار"]);
        }
        for key in &["angels", "angel", "malaikat"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ملائكة", "الملائكة"]);
        }
        for key in &["hypocrisy", "hypocrite"] {
            self.term_map.insert(key.to_string(), vec!["نفاق", "المنافق", "علامات النفاق"]);
        }
        for key in &["nasheed", "nasyid"] {
            self.term_map.insert(key.to_string(), vec!["نشيد", "الأناشيد الإسلامية"]);
        }
        for key in &["shoes", "sandals"] {
            self.term_map.insert(key.to_string(), vec!["نعل", "الخفين", "حذاء"]);
        }
        for key in &["langit"] {
            self.term_map.insert(key.to_string(), vec!["سماء", "السماوات"]);
        }
        for key in &["bumi"] {
            self.term_map.insert(key.to_string(), vec!["أرض", "الأرض"]);
        }
        for key in &["pintu", "gate"] {
            self.term_map.insert(key.to_string(), vec!["باب", "أبواب"]);
        }
        for key in &["lapisan"] {
            self.term_map.insert(key.to_string(), vec!["طبقة", "طبقات"]);
        }
        for key in &["10 sahabat", "sepuluh sahabat"] {
            self.term_map.insert(key.to_string(), vec!["العشرة المبشرون بالجنة"]);
        }

        // ── TYPO FIXES (from eval audit) ──
        for key in &["wudloo", "wuhu"] {
            self.term_map.insert(key.to_string(), vec!["وضوء", "الوضوء", "الطهارة"]);
        }
        for key in &["shalt"] {
            self.term_map.insert(key.to_string(), vec!["صلاة", "الصلاة"]);
        }
        for key in &["pussa", "posa"] {
            self.term_map.insert(key.to_string(), vec!["صوم", "صيام", "الصيام"]);
        }
        for key in &["zkat", "zkaat"] {
            self.term_map.insert(key.to_string(), vec!["زكاة", "الزكاة"]);
        }
        for key in &["qadha'", "qodho", "qodha"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["قضاء", "القضاء", "الفوائت"]);
        }
        for key in &["adzanm", "adzann"] {
            self.term_map.insert(key.to_string(), vec!["أذان", "الأذان"]);
        }
        for key in &["mitsqal", "mithqal"] {
            self.term_map.insert(key.to_string(), vec!["مثقال", "المثقال"]);
        }
        for key in &["istiwa'", "istiwa"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["استواء", "الاستواء"]);
        }

        // ── CONTEXT / GENERIC QUERY WORDS ──
        for key in &["sejarah", "tarikh"] {
            self.term_map.insert(key.to_string(), vec!["تاريخ", "التاريخ"]);
        }
        for key in &["makna", "arti", "artinya"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["معنى", "المعنى", "تعريف"]);
        }
        for key in &["manfaat", "faedah"] {
            self.term_map.insert(key.to_string(), vec!["فائدة", "فوائد", "المنافع"]);
        }
        for key in &["bahaya", "mudharat"] {
            self.term_map.insert(key.to_string(), vec!["ضرر", "الضرر", "مضار"]);
        }
        for key in &["amalan", "amal"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["عمل", "أعمال"]);
        }
        for key in &["peristiwa", "kejadian"] {
            self.term_map.insert(key.to_string(), vec!["حادثة", "واقعة", "أحداث"]);
        }
        for key in &["pengarang", "penulis", "author"] {
            self.term_map.insert(key.to_string(), vec!["مؤلف", "كاتب", "صاحب"]);
        }

        // ── CONTEMPORARY ISSUES ──
        for key in &["drama korea", "drakor"] {
            self.term_map.insert(key.to_string(), vec!["فيلم", "اللهو"]);
        }
        for key in &["komik", "manga", "anime"] {
            self.term_map.insert(key.to_string(), vec!["رسم", "تصوير"]);
        }
        for key in &["pengantin", "mempelai"] {
            self.term_map.insert(key.to_string(), vec!["عروس", "العروسان", "الزفاف"]);
        }
        for key in &["ventilator", "alat bantu napas"] {
            self.term_map.insert(key.to_string(), vec!["أجهزة الإنعاش", "إيقاف الأجهزة الطبية"]);
        }
        for key in &["polusi", "pencemaran"] {
            self.term_map.insert(key.to_string(), vec!["تلوث", "البيئة"]);
        }
        for key in &["stunning", "terkejut"] {
            self.term_map.insert(key.to_string(), vec!["تصعيق", "الصعق قبل الذبح"]);
        }
        for key in &["kenalan", "berkenalan"] {
            self.term_map.insert(key.to_string(), vec!["تعارف", "التعارف"]);
        }
        for key in &["aplikasi", "app"] {
            self.term_map.insert(key.to_string(), vec!["الإنترنت", "التواصل الاجتماعي"]);
        }
        for key in &["lgbtq", "gay", "lesbi"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["لواط", "السحاق", "قوم لوط"]);
        }
        for key in &["pluralisme", "toleransi"] {
            self.term_map.insert(key.to_string(), vec!["تسامح", "التعايش", "التعددية"]);
        }
        for key in &["syariah", "syariat"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["شريعة", "الشريعة"]);
        }
        for key in &["khilafah", "khilafa"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["خلافة", "الخلافة"]);
        }
        for key in &["pasar modal"] {
            self.term_map.insert(key.to_string(), vec!["سوق المال", "الأسهم"]);
        }
        for key in &["crowdfunding"] {
            self.term_map.insert(key.to_string(), vec!["تمويل جماعي", "مشاركة"]);
        }
        for key in &["pesantren", "ponpes"] {
            self.term_map.insert(key.to_string(), vec!["معهد", "المدرسة الدينية"]);
        }
        for key in &["takbiran"] {
            self.term_map.insert(key.to_string(), vec!["تكبير العيد", "تكبيرات العيد"]);
        }
        for key in &["thr"] {
            self.term_map.insert(key.to_string(), vec!["عطية", "هدية العيد"]);
        }
        for key in &["kafan", "kain kafan"] {
            self.term_map.insert(key.to_string(), vec!["كفن", "الكفن", "عدد الكفن"]);
        }
        for key in &["arisan"] {
            self.term_map.insert(key.to_string(), vec!["جمعية", "قرض"]);
        }
        for key in &["kontrak", "perjanjian kerja"] {
            self.term_map.insert(key.to_string(), vec!["عقد العمل", "الإجارة"]);
        }
        for key in &["dosa"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ذنب", "الذنوب", "الكبائر"]);
        }
        for key in &["ampun", "pengampunan"] {
            self.term_map.insert(key.to_string(), vec!["مغفرة", "المغفرة", "التوبة"]);
        }
        for key in &["bioetika", "bioethics"] {
            self.term_map.insert(key.to_string(), vec!["الأخلاق الطبية"]);
        }
        for key in &["iklim", "perubahan iklim", "climate change"] {
            self.term_map.insert(key.to_string(), vec!["بيئة", "التلوث"]);
        }
        for key in &["pesawat", "airplane"] {
            self.term_map.insert(key.to_string(), vec!["طائرة", "الصلاة في الطائرة"]);
        }
        for key in &["hijaiyah", "huruf hijaiyah"] {
            self.term_map.insert(key.to_string(), vec!["الحروف الهجائية", "حروف"]);
        }
        for key in &["aqidah awam", "aqidatul awam"] {
            self.term_map.insert(key.to_string(), vec!["عقيدة العوام", "الجوهرة"]);
        }

        // ── WORSHIP CONFIG WORDS ──
        for key in &["salam"] {
            // salam in prayer context = تسليم; as greeting = سلام
            self.term_map.entry(key.to_string()).or_insert(vec!["تسليم", "السلام", "سلام"]);
        }
        for key in &["awam"] {
            self.term_map.insert(key.to_string(), vec!["عوام", "العوام"]);
        }
        for key in &["nadhom", "nadhm", "nadham"] {
            self.term_map.insert(key.to_string(), vec!["نظم", "منظومة"]);
        }

        // ══════════════════════════════════════════════════════════════
        // BATCH 7 (V17): Fix multi-word dead-code keys + construct-state forms
        // ══════════════════════════════════════════════════════════════

        // ── Arabic construct-state book title components ──
        // Needed for queries like "kitab fathul qarib tentang apa" where
        // "fathul" ≠ "fath" and multi-word key "fathul qarib" never matches
        for key in &["fathul", "fath"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["فتح", "الفتح"]);
        }
        for key in &["qarib"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["فتح القريب", "التقريب"]);
        }
        for key in &["muin", "mu'in"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["فتح المعين", "زين الدين"]);
        }
        for key in &["raudhatut", "raudhatu"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["روضة الطالبين", "النووي"]);
        }
        for key in &["thalibin", "talibin"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["روضة الطالبين", "الطالبين"]);
        }
        for key in &["riyadhus", "riyadhu"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["رياض الصالحين", "النووي"]);
        }
        for key in &["shalihin", "salihin"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["رياض الصالحين", "الصالحين"]);
        }
        for key in &["bulughul", "bulughu"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["بلوغ المرام", "ابن حجر العسقلاني"]);
        }
        for key in &["nihayatul", "nihayatu"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["نهاية المحتاج", "الرملي"]);
        }
        for key in &["mughnil"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مغني المحتاج", "الشربيني"]);
        }
        for key in &["tuhfatul", "tuhfatu"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["تحفة المحتاج", "ابن حجر الهيتمي"]);
        }
        for key in &["kifayatul"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["كفاية الأخيار", "تقي الدين"]);
        }
        for key in &["akhyar"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["كفاية الأخيار", "الأخيار"]);
        }
        for key in &["nailul"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["نيل الأوطار", "الشوكاني"]);
        }
        for key in &["authar"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["نيل الأوطار", "الأوطار"]);
        }
        for key in &["sunan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["السنن", "السنن النبوية"]);
        }
        for key in &["majah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["سنن ابن ماجه", "ابن ماجه"]);
        }
        for key in &["dawud"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["سنن أبي داود", "أبو داود"]);
        }
        for key in &["bidayatul", "bidayah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["بداية المجتهد", "ابن رشد"]);
        }

        // ── Single scholar component keys (critical: multi-word keys are dead code) ──
        for key in &["taimiyah", "taymiyah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ابن تيمية"]);
        }
        for key in &["qayyim"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ابن القيم"]);
        }
        for key in &["haitami"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ابن حجر الهيتمي"]);
        }
        for key in &["rusyd", "rusydi"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ابن رشد", "أبو الوليد"]);
        }
        for key in &["khaldun"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ابن خلدون"]);
        }
        for key in &["sina"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ابن سينا", "أبو علي"]);
        }
        for key in &["walid"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["خالد بن الوليد"]);
        }

        // ── Interrogative and filler words (better than zero) ──
        for key in &["siapakah", "siapa"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["من", "سيرة"]);
        }
        for key in &["kontribusi"] {
            self.term_map.insert(key.to_string(), vec!["مساهمات", "إسهامات", "دور"]);
        }
        for key in &["kitab"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["كتاب", "الكتب"]);
        }
        for key in &["isi", "kandungan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مضمون", "محتوى"]);
        }
        for key in &["bulan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["شهر", "الأشهر"]);
        }
        for key in &["hari"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["يوم", "الأيام"]);
        }
        for key in &["malam"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ليلة", "الليل"]);
        }
        for key in &["tulis", "tulisan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مؤلف", "مؤلفات"]);
        }

        // ── Month name components (multi-word month keys are dead code) ──
        for key in &["rabiul"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ربيع"]);
        }
        for key in &["jumadil"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["جمادى"]);
        }

        // ── Additional person and role words ──
        for key in &["murid"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["طالب", "تلميذ", "مريد"]);
        }
        for key in &["guru"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["شيخ", "أستاذ", "معلم"]);
        }
        for key in &["ulama", "ulema"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["علماء", "العلماء"]);
        }
        for key in &["sahabat", "shahabi"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["صحابة", "الصحابة"]);
        }
        for key in &["nabi", "rasul"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["النبي", "الرسول"]);
        }

        // ── Common words missing from dictionary ──
        for key in &["surah", "surat"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["سورة", "السور"]);
        }
        for key in &["ayat"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["آية", "الآيات"]);
        }
        for key in &["juz"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["جزء", "الأجزاء"]);
        }
        for key in &["langit"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["سماء", "السماوات"]);
        }
        for key in &["bumi"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["أرض", "الأرض"]);
        }
        for key in &["pintu"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["باب", "أبواب"]);
        }
        for key in &["lapisan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["طبقة", "طبقات"]);
        }
        for key in &["huruf"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["حرف", "الحروف"]);
        }
        for key in &["angka", "nomor"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["عدد", "رقم"]);
        }
        for key in &["am"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["العام", "عام"]);
        }
        for key in &["penting"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مهم", "أهمية"]);
        }
        for key in &["terkenal", "masyhur"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مشهور", "معروف"]);
        }
        for key in &["singkat"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["موجز", "مختصر"]);
        }
        for key in &["kadar"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مقدار", "قدر"]);
        }
        for key in &["minimal", "sekurang"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["حد أدنى", "الأقل"]);
        }
        // Sufi concept variants
        for key in &["raja"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["رجاء", "الرجاء"]);
        }
        // Birthdays/mawlid
        for key in &["ulang tahun", "birthday"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["عيد الميلاد", "المولد"]);
        }
        for key in &["nasheed", "nasyid"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["أناشيد", "نشيد"]);
        }
        for key in &["lgbtq", "lgbt"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["المثلية", "الشذوذ"]);
        }

        // ─── BATCH 8: Single-word fallbacks for dead multi-word sirah/history keys ───
        // All multi-word term_map lookups (e.g. "fathu makkah") are dead code —
        // the tokenizer splits on whitespace, so only single-word lookups work.
        for key in &["fathu"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["فتح", "فتح مكة"]);
        }
        for key in &["isra"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الإسراء", "إسراء"]);
        }
        for key in &["miraj"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["المعراج", "معراج"]);
        }
        for key in &["piagam"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["وثيقة", "ميثاق", "صحيفة"]);
        }
        for key in &["khalifah", "kholifah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["خليفة", "الخلفاء"]);
        }
        for key in &["khulafaur", "khulafa"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الخلفاء الراشدون", "الخلفاء"]);
        }
        for key in &["rasyidin", "rashidin"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الراشدون", "الخلفاء الراشدون"]);
        }
        for key in &["bani"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["بنو", "آل"]);
        }

        // ─── BATCH 8: Colloquial Indonesian modern terms ───
        for key in &["chatting", "ngobrol online"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["محادثة", "التحدث مع الأجنبية"]);
        }
        for key in &["nonton", "menonton"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مشاهدة", "النظر"]);
        }
        for key in &["cewek", "perempuan asing"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["فتاة", "امرأة أجنبية"]);
        }
        for key in &["komik", "manga"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["رسوم مصورة", "كتاب مصور"]);
        }
        for key in &["kenalan", "berkenalan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["التعارف", "المعرفة"]);
        }
        for key in &["drakor", "drama"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مسلسل", "مسلسلات"]);
        }
        for key in &["aplikasi", "app"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["وسيلة اتصال", "التقنية الحديثة"]);
        }

        // ─── BATCH 8: Common misspellings / typos ───
        // Users who mistype Arabic Islamic terms in Roman script
        for key in &["wudloo", "wudu'", "wuḍu"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["وضوء", "الوضوء"]);
        }
        for key in &["wuhu"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["وضوء", "الوضوء"]);
        }
        for key in &["shalt", "shallt", "sollt"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["صلاة", "الصلاة"]);
        }
        for key in &["pussa", "pwasa", "puasaa"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["صوم", "صيام"]);
        }
        for key in &["zkat", "zkah", "zakaat"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["زكاة", "الزكاة"]);
        }

        // ─── BATCH 8: Islamic concepts still missing ───
        for key in &["wiping", "usap"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مسح", "المسح"]);
        }
        for key in &["masah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مسح", "المسح على الخفين"]);
        }
        for key in &["socks", "khuf", "khuff"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["خف", "الخفين", "المسح على الخفين"]);
        }
        for key in &["tahajjud"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["التهجد", "قيام الليل", "صلاة الليل"]);
        }
        for key in &["paradise", "surga", "jannah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["جنة", "الجنة", "الفردوس"]);
        }
        for key in &["hellfire", "neraka", "jahannam"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["نار", "جهنم", "النار"]);
        }
        for key in &["angels", "malaikat"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ملائكة", "الملائكة"]);
        }
        for key in &["duties", "tugas", "kewajiban"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["واجبات", "فرائض"]);
        }
        for key in &["saints", "wali", "waliyullah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الأولياء", "ولي الله"]);
        }
        for key in &["miracles", "mukjizat", "karamah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["كرامة", "معجزة", "الكرامات"]);
        }
        for key in &["guarantee", "kafalah", "kafala"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["كفالة", "الكفالة"]);
        }
        for key in &["agency", "wakalah", "wakala"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["وكالة", "التوكيل"]);
        }
        for key in &["options", "khiyar"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["خيار", "الخيار"]);
        }
        for key in &["uncertainty", "gharar"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["غرر", "الغرر"]);
        }
        for key in &["highway", "hirabah", "hiraba"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["حرابة", "السرقة الكبرى"]);
        }
        for key in &["hypocrisy", "munafik", "nifak"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["نفاق", "المنافق"]);
        }
        for key in &["celebrating", "perayaan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الاحتفال", "عيد"]);
        }
        for key in &["mawlid", "birthday prophet"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["المولد النبوي", "مولد"]);
        }
        for key in &["KPR", "kpr"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["تمويل عقاري", "القرض العقاري", "بيع بالتقسيط"]);
        }
        for key in &["stunning", "pemingsanan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["تخدير", "ذبح بالتخدير"]);
        }

        // ─── BATCH 8 (cont.): Terms that appear in V15 zero queries ───
        for key in &["aib"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["عيب", "الخيار بالعيب"]);
        }
        for key in &["mutlak"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مطلق", "الاجتهاد المطلق"]);
        }
        for key in &["ulumuddin", "ulum ud-din"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["علوم الدين", "إحياء علوم الدين"]);
        }
        for key in &["melempar", "melontar"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["رمي", "رمي الجمرات"]);
        }
        for key in &["aqabah", "aqobah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["جمرة العقبة", "العقبة"]);
        }
        for key in &["pembeli"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مشتري", "المشتري"]);
        }
        for key in &["tsani", "thani"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ثاني", "الثاني"]);
        }
        for key in &["fiqhiyyah", "fiqhiyah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["فقهية", "القواعد الفقهية"]);
        }
        for key in &["ula", "wal-ula"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الأولى", "الأول"]);
        }
        for key in &["wustha"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الوسطى", "الأوسط"]);
        }
        for key in &["pagi"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["صباح", "الصباح"]);
        }
        for key in &["petang", "sore"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مساء", "المساء"]);
        }
        for key in &["tawadhu", "tawadu"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["تواضع", "التواضع"]);
        }
        for key in &["husnuzhan", "husnu zhan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["حسن الظن", "ظن الخير"]);
        }
        for key in &["su'uzhan", "suuzhan", "su uzhan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["سوء الظن", "الظن"]);
        }
        for key in &["birrul", "birr"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["بر", "بر الوالدين"]);
        }
        for key in &["walidain", "waalidain"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الوالدين", "بر الوالدين"]);
        }
        for key in &["denda"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["غرامة", "دية"]);
        }
        for key in &["janin"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["جنين", "الجنين"]);
        }
        for key in &["makiyyah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مكية", "السور المكية"]);
        }
        for key in &["madaniyyah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مدنية", "السور المدنية"]);
        }
        for key in &["muhkam"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["محكم", "المحكم"]);
        }
        for key in &["mutasyabih"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["متشابه", "المتشابه"]);
        }
        for key in &["i'jaz", "ijaz"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["إعجاز", "إعجاز القرآن"]);
        }
        for key in &["kemukjizatan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["إعجاز", "المعجزة"]);
        }
        for key in &["makna"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["معنى", "تعريف"]);
        }

        // ─── BATCH 9: Final cleanup — standalone words missing single-word keys ───
        for key in &["awal"] {  // "first/beginning" — used in tahallul awal, rabiul awal
            self.term_map.entry(key.to_string()).or_insert(vec!["الأول", "أول"]);
        }
        for key in &["akhir"] {  // "last/end" — used in rabiul akhir, jumadil akhir
            self.term_map.entry(key.to_string()).or_insert(vec!["الآخر", "آخر"]);
        }
        for key in &["shiddiq", "siddiq", "siddik"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الصديق", "أبو بكر الصديق"]);
        }
        for key in &["jumlah"] {  // "amount/total"
            self.term_map.entry(key.to_string()).or_insert(vec!["عدد", "كمية"]);
        }
        for key in &["pasar"] {  // "market" — for pasar modal syariah
            self.term_map.entry(key.to_string()).or_insert(vec!["سوق", "الأسواق"]);
        }
        for key in &["modal"] {  // "capital" — for pasar modal
            self.term_map.entry(key.to_string()).or_insert(vec!["رأس مال", "المال"]);
        }
        for key in &["sistem"] {  // "system" — for sistem khilafah
            self.term_map.entry(key.to_string()).or_insert(vec!["نظام", "النظام"]);
        }
        for key in &["implementasi"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["تطبيق", "تنفيذ"]);
        }
        for key in &["kurikulum"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["منهج", "مناهج"]);
        }
        for key in &["modernisasi"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["التحديث", "التجديد"]);
        }
        for key in &["tradisi"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["تراث", "عرف"]);
        }
        for key in &["kapan"] {  // "when" — question word
            self.term_map.entry(key.to_string()).or_insert(vec!["متى", "وقت"]);
        }
        for key in &["dimana"] {  // "where" — question word
            self.term_map.entry(key.to_string()).or_insert(vec!["أين", "مكان"]);
        }
        for key in &["mengapa"] {  // "why" — question word
            self.term_map.entry(key.to_string()).or_insert(vec!["لماذا", "حكمة"]);
        }
        for key in &["berapa"] {  // "how many/much" — question word
            self.term_map.entry(key.to_string()).or_insert(vec!["كم", "عدد"]);
        }
        for key in &["amalan", "amal"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["عمل", "أعمال"]);
        }
        for key in &["celebrate", "merayakan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["احتفال", "الاحتفال"]);
        }
        for key in &["listen", "dengar", "mendengar"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["سماع", "الاستماع"]);
        }
        for key in &["shoes", "sepatu", "alas kaki"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["نعال", "الحذاء"]);
        }
        for key in &["climate", "lingkungan", "environment"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["بيئة", "المناخ"]);
        }
        for key in &["pesantren", "pondok"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["معهد", "المدرسة الإسلامية"]);
        }
        for key in &["ditanya", "pertanyaan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["سؤال", "مسألة"]);
        }

        // ─── BATCH 9 (cont.): Chapter / book structural terms ───
        // Users often query "syarah fathul mu'in bab thaharah" etc.
        for key in &["bab"] {  // chapter in Arabic kitab — written in Latin by users
            self.term_map.entry(key.to_string()).or_insert(vec!["باب", "أبواب"]);
        }
        for key in &["pasal", "fasal"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["فصل", "الفصول"]);
        }
        for key in &["syarah", "pensyarah", "syarh"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["شرح", "الشرح"]);
        }
        for key in &["sharih", "pensyarah"] {  // commentator of a kitab
            self.term_map.entry(key.to_string()).or_insert(vec!["شارح"]);
        }
        for key in &["risalah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["رسالة", "الرسالة"]);
        }
        for key in &["nadhom", "nadhm", "nadham"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["نظم", "منظومة"]);
        }
        for key in &["matan", "matn"] {  // base text of a kitab
            self.term_map.entry(key.to_string()).or_insert(vec!["متن", "المتن"]);
        }
        for key in &["mukhtashar", "mukhtasar"] {  // abridged version
            self.term_map.entry(key.to_string()).or_insert(vec!["مختصر", "الملخص"]);
        }

        // ─── BATCH 9 (cont.): More Islamic practices missing ───
        for key in &["talqin"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["التلقين"]);
        }
        for key in &["arisan"] {  // Indonesian rotating savings group
            self.term_map.entry(key.to_string()).or_insert(vec!["جمعية", "القرض الحسن"]);
        }
        for key in &["tahun baru"] {  // new year
            self.term_map.entry(key.to_string()).or_insert(vec!["رأس السنة", "السنة الجديدة"]);
        }
        for key in &["hijriyah", "hijri"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["هجرية", "التقويم الهجري"]);
        }
        for key in &["THR", "thr"] {  // Tunjangan Hari Raya — Indonesian holiday bonus
            self.term_map.entry(key.to_string()).or_insert(vec!["هدية", "عطاء", "الأجر"]);
        }
        for key in &["pesawat"] {  // airplane — check if already exists, add if not
            self.term_map.entry(key.to_string()).or_insert(vec!["طائرة", "الطائرة"]);
        }
        for key in &["janda", "duda"] {  // widow, widower
            self.term_map.entry(key.to_string()).or_insert(vec!["أرملة", "أيم"]);
        }
        for key in &["tunangan", "bertunangan"] {  // fiancee, engagement
            self.term_map.entry(key.to_string()).or_insert(vec!["خطبة", "المخطوبة"]);
        }
        for key in &["foto", "gambar", "memotret"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["تصوير", "صورة"]);
        }

        // ─── BATCH 10: English plural forms and additional edge cases ───
        for key in &["birthdays", "birthday"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["عيد الميلاد", "المولد"]);
        }
        for key in &["graves", "grave", "tomb", "kubur", "kuburan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["قبر", "القبور"]);
        }
        for key in &["prayers", "prayer"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["صلاة", "الصلاة"]);
        }
        for key in &["sins", "sin", "dosa"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ذنب", "الذنوب", "إثم"]);
        }
        for key in &["scholars", "scholar"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["العلماء", "عالم"]);
        }
        for key in &["companions", "sahabat"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["صحابة", "الصحابة"]);
        }
        for key in &["women", "woman", "female"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["المرأة", "النساء"]);
        }
        for key in &["men", "man", "male"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الرجل", "الرجال"]);
        }
        for key in &["books", "book"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["كتاب", "الكتب"]);
        }
        for key in &["ruling", "rulings"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["حكم", "أحكام"]);
        }
        for key in &["evidence", "dalil", "dalil-dalil"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["دليل", "الأدلة"]);
        }
        for key in &["hadith", "hadis", "hadist"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["حديث", "الحديث"]);
        }
        for key in &["verse", "verses", "ayat"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["آية", "الآيات"]);
        }
        for key in &["surah", "sura", "chapter"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["سورة", "السور"]);
        }
        for key in &["hukum"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["حكم", "أحكام"]);
        }
        for key in &["boleh"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["جواز", "يجوز", "مباح"]);
        }
        for key in &["tidak boleh", "dilarang"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["لا يجوز", "حرام", "محرم"]);
        }
        for key in &["wajib", "fardhu"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["واجب", "فرض"]);
        }
        for key in &["sunah", "sunnah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["سنة", "مستحب"]);
        }
        for key in &["makruh", "mekruh"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مكروه", "الكراهة"]);
        }

        // ─── BATCH 9 (cont.): English terms for Islamic queries ───
        for key in &["islamic", "islamically"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الإسلام", "الإسلامي"]);
        }
        for key in &["muslim", "muslims"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مسلم", "المسلمون"]);
        }
        for key in &["pray", "praying"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["صلاة", "الصلاة"]);
        }
        for key in &["responsibility", "obligation"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مسؤولية", "واجب"]);
        }
        for key in &["perspective", "view", "opinion"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["وجهة نظر", "رأي"]);
        }
        for key in &["farming", "agriculture"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["زراعة", "مزرعة"]);
        }
        for key in &["factory", "pabrik"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مزرعة", "ذبح"]);  // factory farming → slaughter
        }
        for key in &["perspective", "view", "viewpoint"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["رأي", "وجهة النظر"]);
        }
        for key in &["shoes", "footwear", "alas kaki"] {
            // already added as "shoes" above but ensuring here
            self.term_map.entry(key.to_string()).or_insert(vec!["نعال", "الحذاء"]);
        }
        for key in &["description", "description of"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["وصف", "صفة"]);
        }
        for key in &["signs", "tanda-tanda"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["علامات", "أمارات"]);
        }
        for key in &["overview", "introduction", "pengantar"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مقدمة", "نظرة عامة"]);
        }

        // ─── BATCH 11: Missing terms for V15 zeros ───
        for key in &["tempat", "lokasi", "place", "location"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مكان", "موضع"]);
        }
        for key in &["pencuri", "perampok", "thief"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["سارق", "السرقة"]);
        }
        for key in &["pembunuhan", "membunuh", "kill", "murder"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["قتل", "القتل", "الجناية على النفس"]);
        }
        for key in &["potong", "memotong", "amputation"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["قطع", "البتر"]);
        }
        for key in &["azl", "'azl", "coitus interruptus"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["العزل", "العزل عن المرأة"]);
        }
        for key in &["perwakilan", "wakil"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["وكالة", "وكيل"]);
        }
        for key in &["kuqathah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["لقطة"]);
        }
        for key in &["furudh", "fardhu"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["فروض", "الفرائض"]);
        }
        for key in &["perang", "pertempuran", "battle", "war"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["غزوة", "معركة"]);
        }
        for key in &["badr"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["بدر", "غزوة بدر"]);
        }
        for key in &["uhud"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["أحد", "غزوة أحد"]);
        }
        for key in &["khandaq", "ahzab"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["خندق", "الأحزاب", "غزوة الخندق"]);
        }
        for key in &["pluralisme", "pluralism"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["التعددية", "التسامح"]);
        }
        for key in &["toleransi", "tolerance"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["التسامح", "التعايش"]);
        }
        for key in &["khilafah", "caliphate", "khilafa"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الخلافة", "الحكم الإسلامي"]);
        }
        for key in &["crowdfunding"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["التمويل الجماعي", "التبرع"]);
        }
        for key in &["bioethics"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الأخلاق الطبية", "الفقه الطبي"]);
        }
        for key in &["sengaja", "intentional", "deliberate"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["عمد", "القتل العمد"]);
        }
        for key in &["ganti rugi", "diyat", "diat"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["دية", "الدية", "الأرش"]);
        }
        for key in &["arsy", "arsy pelukaan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["أرش", "الجراح"]);
        }
        for key in &["pelukaan", "peluka", "injury", "wound"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["جراح", "الجراح", "جناية"]);
        }
        for key in &["kibr", "sombong", "arrogance"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["كبر", "التكبر", "الكبرياء"]);
        }
        for key in &["karamah", "keramat"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الكرامة", "كرامات الأولياء"]);
        }
        for key in &["mawlid", "maulid", "maulud"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["المولد", "مولد النبي", "الاحتفال بالمولد"]);
        }
        for key in &["perayaan", "merayakan", "commemorate"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["احتفال", "الاحتفال"]);
        }
        for key in &["lgbtq", "lgbt", "homosexuality", "homoseksual"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الشذوذ الجنسي", "اللواط", "المثلية"]);
        }
        for key in &["nasheed", "nasyid", "anasheed"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["أناشيد", "النشيد الإسلامي"]);
        }
        for key in &["kafan", "shroud"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["كفن", "الكفن"]);
        }
        for key in &["jumlah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["عدد", "كمية"]);
        }
        for key in &["airplane", "pesawat", "kapal terbang"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الطائرة", "السفر"]);
        }
        for key in &["9", "10", "7", "8", "28", "30"] {
            // Number queries — map to general "عدد" to avoid zero but also keep as latin_term
            self.term_map.entry(key.to_string()).or_insert(vec!["عدد"]);
        }

        // ─── BATCH 12: More missing terms from V15 zeros ───
        for key in &["ied", "idul", "lebaran"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["عيد", "العيد", "عيد الفطر"]);
        }
        for key in &["kain"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["كسوة", "قماش"]);
        }
        for key in &["dijamin", "terjamin"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مضمون", "مبشرون بالجنة"]);
        }
        for key in &["tahun"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["سنة", "عام"]);
        }
        for key in &["baru", "new"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["جديد", "المحدث"]);
        }
        for key in &["modernitas", "modernity"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الحداثة", "التجديد"]);
        }
        for key in &["bacaan", "membaca", "recitation"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["قراءة", "تلاوة"]);
        }
        for key in &["pegawai", "karyawan", "employee"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["موظف", "عامل", "أجير"]);
        }
        for key in &["tangan", "hand"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["يد", "اليد"]);
        }
        for key in &["kontrak", "contract"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["عقد", "عقود"]);
        }
        for key in &["salam"] {
            // Islamic contract "salam" = forward sale; also greeting
            self.term_map.entry(key.to_string()).or_insert(vec!["السلم", "بيع السلم", "سلام"]);
        }
        for key in &["istishna"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الاستصناع", "عقد الاستصناع"]);
        }
        for key in &["pluralisme"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["التعددية", "التسامح الديني"]);
        }
        for key in &["bihdats", "bidah", "bid'ah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["بدعة", "البدعة", "محدثات الأمور"]);
        }
        for key in &["adab", "etika"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["أدب", "الآداب"]);
        }
        for key in &["saleh", "sholeh", "shaleh"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["صالح", "الصالحون"]);
        }
        for key in &["ihsan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["إحسان", "الإحسان"]);
        }
        for key in &["tazkiyah", "tazkiyatun", "nafs"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["تزكية النفس", "تزكية"]);
        }
        for key in &["ikhlas", "sincere"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["إخلاص", "الإخلاص"]);
        }
        for key in &["sabar", "patience"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["صبر", "الصبر"]);
        }
        for key in &["syukur", "gratitude"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["شكر", "الشكر"]);
        }
        for key in &["qanaah", "contentment"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["قناعة"]);
        }
        for key in &["maulid", "mawlid", "milad"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["المولد", "مولد النبي"]);
        }
        for key in &["haul", "haol"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الحول", "الذكرى السنوية"]);
        }
        for key in &["yasinan", "yassin"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["قراءة يس", "سورة يس"]);
        }
        for key in &["istigfar", "istighfar"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["استغفار", "طلب المغفرة"]);
        }
        for key in &["shalawat", "salawat", "sholawat", "salawat"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الصلاة على النبي", "الصلوات"]);
        }
        for key in &["silaturahmi", "silaturrahim"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["صلة الرحم", "التواصل"]);
        }
        for key in &["menolong", "tolong", "help"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مساعدة", "التعاون"]);
        }

        // ─── BATCH 13: Additional coverage for colloquial/query patterns ───
        for key in &["kerja", "bekerja", "pekerjaan", "work", "job"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["عمل", "الكسب", "العمل"]);
        }
        for key in &["ampuni", "diampuni", "ampunan", "forgiveness"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مغفرة", "التوبة", "الغفران"]);
        }
        for key in &["dosa", "sin", "dosanya"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ذنب", "إثم", "الخطيئة"]);
        }
        for key in &["mencabut", "withdraw", "removal"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["نزع", "سحب"]);
        }
        for key in &["napas", "nefas", "breath"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["نفس", "التنفس"]);
        }
        for key in &["polusi", "pollution", "udara", "air"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["تلوث", "البيئة"]);
        }
        for key in &["pengantin", "bride", "groom"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["عروس", "الزوجان الجديدان"]);
        }
        for key in &["larangan", "prohibition"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["تحريم", "محظورات"]);
        }
        for key in &["keras", "jahri", "jahar"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["جهر", "الجهر"]);
        }
        for key in &["pelan", "sirri", "siri", "quiet", "silent"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["سر", "الإسرار"]);
        }
        for key in &["stunning", "sembelih", "slaughter", "zabh"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ذبح", "الذبح", "التذكية"]);
        }
        for key in &["amin"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["آمين", "التأمين"]);
        }
        for key in &["hafiz", "hafal", "memorization"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["حفظ", "الحفظ", "حافظ"]);
        }
        for key in &["ihram"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["إحرام", "الإحرام"]);
        }
        for key in &["thawaf", "tawaf"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["طواف", "الطواف"]);
        }
        for key in &["sa'i", "sai"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["سعي", "السعي بين الصفا والمروة"]);
        }
        for key in &["wukuf"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["وقوف", "الوقوف بعرفة"]);
        }
        for key in &["arafah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["عرفة", "يوم عرفة"]);
        }
        for key in &["mina"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["منى"]);
        }
        for key in &["subulussalam", "subulus", "subul"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["سبل السلام", "الصنعاني"]);
        }
        for key in &["muwattha", "muwatta", "muwatha"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الموطأ", "موطأ مالك"]);
        }
        for key in &["malik"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مالك", "الإمام مالك"]);
        }
        for key in &["pengarang", "author", "karangan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مؤلف", "صاحب الكتاب"]);
        }
        for key in &["perawi", "narrator"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["راوي", "الرواة"]);
        }

        // ─── BATCH 14: Specific fiqh subtypes and remaining V15 zeros ───
        for key in &["abdan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["شركة الأبدان", "الأعمال"]);
        }
        for key in &["inan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["شركة عنان", "عنان"]);
        }
        for key in &["mufawadhah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["شركة المفاوضة", "المفاوضة"]);
        }
        for key in &["wujuh"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["شركة الوجوه", "الوجوه"]);
        }
        for key in &["aib", "cacat", "defect"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["عيب", "خيار العيب"]);
        }
        for key in &["khiyar"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["خيار", "الخيار"]);
        }
        for key in &["mujtahid"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مجتهد", "الاجتهاد"]);
        }
        for key in &["mutlak", "absolute"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مطلق", "مجتهد مطلق"]);
        }
        for key in &["dharurah", "darurat", "necessity"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ضرورة", "الضرورة", "حالة الاضطرار"]);
        }
        for key in &["nifaq", "munafiq"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["نفاق", "النفاق", "المنافق"]);
        }
        for key in &["kufur", "kafir", "disbelief"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["كفر", "الكفر", "الكافر"]);
        }
        for key in &["syirik", "shirk", "polytheism"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["شرك", "الشرك"]);
        }
        for key in &["riddah", "murtad", "apostasy"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ردة", "المرتد", "الردة"]);
        }
        for key in &["hadhanah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["حضانة", "الحضانة"]);
        }
        for key in &["nafkah", "nafaqah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["نفقة", "النفقة"]);
        }
        for key in &["mahar"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مهر", "المهر"]);
        }
        for key in &["iddah", "idah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["عدة", "العدة"]);
        }
        for key in &["khalwat", "khalwah", "seclusion"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["خلوة", "الخلوة"]);
        }
        for key in &["taaruf", "ta'aruf"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["التعارف", "مجلس التعارف"]);
        }
        for key in &["nusyuz"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["نشوز", "النشوز"]);
        }
        for key in &["fasakh", "fasah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["فسخ", "الفسخ"]);
        }
        for key in &["li'an", "lian"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["لعان"]);
        }
        for key in &["zihar", "dzihar"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ظهار"]);
        }
        for key in &["kafarat"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["كفارة", "الكفارة"]);
        }
        for key in &["fidyah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["فدية"]);
        }
        for key in &["umur", "age", "usia"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["سن", "العمر"]);
        }
        for key in &["sampai", "until", "hingga"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["إلى", "حتى"]);
        }
        for key in &["waqaf", "wakaf", "endowment"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["وقف", "الوقف"]);
        }
        for key in &["hibah", "hiba"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["هبة", "الهبة"]);
        }
        for key in &["wasiat"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["وصية", "الوصية"]);
        }
        for key in &["warisan", "mawaris"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ميراث", "المواريث"]);
        }
        for key in &["ashhabul faradh", "ashabul"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["أصحاب الفروض"]);
        }
        for key in &["ashobah", "ashabah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["عصبة"]);
        }
        for key in &["dzawul arham", "dzawil"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ذوو الأرحام"]);
        }

        // ─── BATCH 15: Prayer directional terms and other gaps ───
        for key in &["kanan", "kiri", "right", "left"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["يمين", "يسار", "التسليم"]);
        }
        for key in &["salam ke kanan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["السلام عن اليمين"]);
        }
        for key in &["taslim", "taslem"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["تسليم", "التسليم"]);
        }
        for key in &["am"] {
            // Usul fiqh: 'am = general
            self.term_map.entry(key.to_string()).or_insert(vec!["عام", "العام والخاص"]);
        }
        for key in &["naskh", "nasakh"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["نسخ", "الناسخ والمنسوخ"]);
        }
        for key in &["kilas", "singkat", "brief", "ringkasan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ملخص", "مختصر"]);
        }
        for key in &["terkenal", "masyhur", "famous"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مشهور", "معروف"]);
        }
        for key in &["ilmiah", "academic"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["علمي", "أكاديمي"]);
        }
        for key in &["lafal", "lafaz", "wording", "phrasing"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["لفظ", "الألفاظ"]);
        }
        for key in &["bunuh diri", "suicide"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الانتحار", "قتل النفس"]);
        }
        for key in &["euthanasia", "tasri'i"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الموت الرحيم", "القتل الرحيم"]);
        }
        for key in &["minuman", "drink", "beverages"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مشروبات", "الشراب"]);
        }
        for key in &["makanan", "food", "makan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["طعام", "الأطعمة"]);
        }
        for key in &["halal", "halaal"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["حلال", "الحلال"]);
        }
        for key in &["haram"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["حرام", "الحرام"]);
        }
        for key in &["najis", "impure"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["نجس", "النجاسة"]);
        }
        for key in &["suci", "thaharah", "tahara", "purity"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["طهارة", "الطهارة"]);
        }
        for key in &["junub", "janabah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["جنابة", "الجنابة"]);
        }
        for key in &["mandi", "ghusl", "mandi wajib"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["غسل", "الغسل"]);
        }
        for key in &["haid", "haydh", "menstruation"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["حيض", "الحيض"]);
        }
        for key in &["nifas"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["نفاس", "النفاس"]);
        }
        for key in &["istihadhah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["استحاضة"]);
        }
        for key in &["tayammum"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["تيمم", "التيمم"]);
        }
        for key in &["qiblat", "qibla", "kiblat"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["قبلة", "القبلة"]);
        }
        for key in &["orang", "person", "seseorang"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["شخص", "إنسان"]);
        }
        for key in &["anak", "child", "children"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ولد", "أولاد", "طفل"]);
        }
        for key in &["ibu", "mother", "ummi"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["أم", "والدة"]);
        }
        for key in &["ayah", "bapak", "father", "abi"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["أب", "والد"]);
        }
        for key in &["suami", "husband"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["زوج", "الزوج"]);
        }
        for key in &["istri", "isteri", "wife"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["زوجة", "الزوجة"]);
        }

        // ─── BATCH 16: Prayer/Quran terms and temporal words ───
        for key in &["fatihah", "fatiha", "al-fatihah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الفاتحة", "فاتحة الكتاب"]);
        }
        for key in &["sebelum", "sebelumnya", "before"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["قبل", "السابق"]);
        }
        for key in &["sesudah", "setelah", "setelahnya", "after"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["بعد", "اللاحق"]);
        }
        for key in &["lengkap", "lengkapnya", "complete", "full"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["كامل", "تام"]);
        }
        for key in &["pertama", "first", "awal"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["أول", "البداية"]);
        }
        for key in &["terakhir", "last", "akhir"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["آخر", "الأخير"]);
        }
        for key in &["dua", "qunut", "doa qunut"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["القنوت", "دعاء القنوت"]);
        }
        for key in &["tasyahud", "tahiyat"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["التشهد", "التحيات"]);
        }
        for key in &["ruku", "ruku'"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ركوع", "الركوع"]);
        }
        for key in &["sujud"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["سجود", "السجود"]);
        }
        for key in &["qiyam", "berdiri"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["قيام", "القيام"]);
        }
        for key in &["duduk", "julud"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["جلوس", "القعود"]);
        }
        for key in &["rakaat", "rakat"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ركعة", "الركعات"]);
        }
        for key in &["jamak", "jam'", "combining"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["جمع", "الجمع بين الصلاتين"]);
        }
        for key in &["qasar", "qashr", "qashr", "shortening"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["قصر", "قصر الصلاة"]);
        }
        for key in &["witir", "witr"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["وتر", "صلاة الوتر"]);
        }
        for key in &["tarawih", "taraweh"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["تراويح", "صلاة التراويح"]);
        }
        for key in &["shalat sunnah", "sunnah rawatib"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["السنن الرواتب", "النوافل"]);
        }
        for key in &["rawatib"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الرواتب", "السنن الرواتب"]);
        }
        for key in &["dhuha", "duha"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الضحى", "صلاة الضحى"]);
        }
        for key in &["isyraq", "isyrak"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["صلاة الإشراق"]);
        }
        for key in &["aurat", "awrah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["عورة", "ستر العورة"]);
        }
        for key in &["sutroh", "sutrah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["سترة"]);
        }
        for key in &["makmum", "makmun"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مأموم", "المأموم"]);
        }
        for key in &["memimpin", "lead", "kepemimpinan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["إمامة", "قيادة"]);
        }
        for key in &["masbuk"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["المسبوق", "إدراك الصلاة"]);
        }
        for key in &["lupa", "sahwi", "forget"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["سهو", "السهو في الصلاة"]);
        }
        for key in &["sujud sahwi", "sajdah sahwi"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["سجود السهو"]);
        }

        // ─── BATCH 17: Remaining critical terms from zero analysis ───

        // Salaf / theological schools
        for key in &["salaf", "salafi", "salafy"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["السلف", "السلف الصالح", "السلفية"]);
        }
        for key in &["ushuluddin", "ushul ad-din", "usul diin"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["أصول الدين", "أصول الفقه"]);
        }
        for key in &["jamiah", "jami'ah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["جامع", "الجامع"]);
        }
        for key in &["tabarruk"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["التبرك", "البركة"]);
        }

        // Usul fiqh terms
        for key in &["khas", "khusus", "specific"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["خاص", "التخصيص"]);
        }
        for key in &["mubayyan", "bayyin"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["المبين", "البيان"]);
        }
        for key in &["majazi", "majaz"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["المجاز", "مجازي"]);
        }
        for key in &["haqiqi"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الحقيقة", "حقيقي"]);
        }
        for key in &["takhshish", "takhsis"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["التخصيص"]);
        }
        for key in &["mutlaq", "mutlak"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["المطلق"]);
        }
        for key in &["muqayyad", "muqayyid"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["المقيد", "التقييد"]);
        }
        for key in &["mantuq", "mafhum"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["المنطوق", "المفهوم"]);
        }
        for key in &["ijtihad"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الاجتهاد", "اجتهاد"]);
        }
        for key in &["taqlid"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["التقليد", "مقلد"]);
        }
        for key in &["ittiba'", "ittiba"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الاتباع"]);
        }
        for key in &["istidlal"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الاستدلال"]);
        }
        for key in &["talaqqi"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["التلقي", "تلقي الأسانيد"]);
        }

        // Additional prayer/worship vocabulary
        for key in &["niat", "berniat"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["نية", "النية"]);
        }
        for key in &["takbir", "takbiratul ihram"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["التكبير", "تكبيرة الإحرام"]);
        }
        for key in &["iqamat", "iqamah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الإقامة"]);
        }
        for key in &["subuh", "shubh", "fajr"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الفجر", "صلاة الصبح"]);
        }
        for key in &["dzuhur", "zhuhur", "dhuhur"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الظهر", "صلاة الظهر"]);
        }
        for key in &["ashar", "asr"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["العصر", "صلاة العصر"]);
        }
        for key in &["maghrib", "maghrib"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["المغرب", "صلاة المغرب"]);
        }
        for key in &["isya", "isya'", "isha"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["العشاء", "صلاة العشاء"]);
        }
        for key in &["jumat", "jum'at", "juma'ah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الجمعة", "صلاة الجمعة"]);
        }
        for key in &["khutbah", "kutbah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الخطبة", "خطبة الجمعة"]);
        }
        for key in &["shaf", "saff", "saf"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الصف", "تسوية الصفوف"]);
        }
        for key in &["berjamaah", "jamaah", "jama'ah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الجماعة", "صلاة الجماعة"]);
        }
        for key in &["munfarid", "sendirian"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["المنفرد", "صلاة المنفرد"]);
        }

        // Hajj/Umrah vocabulary
        for key in &["masjidil haram", "masjid haram"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["المسجد الحرام", "الحرم المكي"]);
        }
        for key in &["madinah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["المدينة المنورة", "المدينة"]);
        }
        for key in &["ziarah", "ziyarah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الزيارة", "زيارة القبور"]);
        }
        for key in &["istilam"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الاستلام", "استلام الحجر الأسود"]);
        }
        for key in &["hajar aswad"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الحجر الأسود"]);
        }
        for key in &["dam", "fidyah haji"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الدم", "دم الجبران"]);
        }
        for key in &["mabit"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["المبيت", "المبيت بمزدلفة"]);
        }
        for key in &["kerikil"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الحصى", "رمي الجمار"]);
        }
        for key in &["badal haji"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["حج البدل", "النيابة في الحج"]);
        }

        // General contextual terms
        for key in &["contoh", "misalnya", "example"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مثال", "نموذج"]);
        }
        for key in &["jelaskan", "penjelasan", "explain"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["بيان", "شرح"]);
        }
        for key in &["pengertian", "definisi", "definition"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["تعريف", "المعنى"]);
        }
        for key in &["syarat", "syarat-syarat", "conditions"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["شروط", "الشروط"]);
        }
        for key in &["rukun", "arkan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["أركان", "الأركان"]);
        }
        for key in &["sunah", "sunahnya", "sunnah"] { // duplicate-safe via or_insert
            self.term_map.entry(key.to_string()).or_insert(vec!["السنة", "المستحب"]);
        }
        for key in &["mustahab", "mandub"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["المستحب", "المندوب"]);
        }
        for key in &["mubah", "jaiz"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["المباح", "الجائز"]);
        }
        for key in &["membatal", "membatalkan", "batal"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مفسد", "المبطلات"]);
        }

        // Social / modern Islamic issues
        for key in &["media sosial", "sosial media"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["وسائل التواصل الاجتماعي"]);
        }
        for key in &["foto", "foto selfie"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["التصوير", "الصورة"]);
        }
        for key in &["video", "film"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الفيلم", "التصوير"]);
        }
        for key in &["musik", "music", "lagu"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الموسيقى", "الغناء"]);
        }
        for key in &["game", "permainan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["اللعب", "اللهو"]);
        }
        for key in &["investasi", "saham"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الاستثمار", "الأسهم"]);
        }
        for key in &["asuransi", "insurance"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["التأمين", "التأمين الإسلامي"]);
        }
        for key in &["bank konvensional"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["البنوك الربوية", "البنك التقليدي"]);
        }
        for key in &["kredit", "cicilan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الأقساط", "التقسيط"]);
        }
        for key in &["utang", "hutang", "debt"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الدين", "الديون"]);
        }

        // Missing months / periods
        for key in &["rabiul akhir", "rabiul tsani"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ربيع الآخر", "ربيع الثاني"]);
        }
        for key in &["jumadil akhir", "jumadil tsani"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["جمادى الآخرة", "جمادى الثانية"]);
        }
        for key in &["rajab"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["رجب", "شهر رجب"]);
        }
        for key in &["nisfu"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["النصف", "ليلة النصف"]);
        }

        // ══════════════════════════════════════════════════════════════
        // BATCH 18: Core Islamic domain keywords (confirmed missing)
        // These caused guaranteed zero results because the entire query
        // was in Latin and none of the meaningful terms had Arabic expansion.
        // ══════════════════════════════════════════════════════════════

        // ── P0: PRIMARY DOMAIN KEYWORDS ──
        // "aqidah" was only used as a FiqhDomain string - never in term_map
        for key in &["aqidah", "akidah", "aqeedah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["العقيدة", "عقائد", "عقيدة"]);
        }
        // "ibadah" likewise was only a domain string, not in term_map
        for key in &["ibadah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["العبادة", "العبادات", "الطاعة"]);
        }
        // "fiqh/fikih" — generic Islamic jurisprudence keyword
        for key in &["fiqh", "fikih", "fiqih"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الفقه", "علم الفقه", "الأحكام"]);
        }
        // "ilmu" — generic "knowledge/science" used in compound queries like "ilmu fiqh"
        for key in &["ilmu"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["العلم", "علم"]);
        }
        // Prophethood concepts
        for key in &["nubuwwah", "nubuah", "kenabian", "prophethood"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["النبوة", "الرسالة", "النبيون"]);
        }

        // ── P1: ISLAMIC ADJECTIVE SUFFIXES ──
        // "islamiyah/islami" — appears in compound queries like "aqidah islamiyah"
        for key in &["islamiyah", "islamiah", "islami", "islamik"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الإسلامية", "الإسلامي", "إسلامي"]);
        }

        // ── P2: POPULAR SURAH NAMES ──
        for key in &["yasin", "yaseen", "yaaseen", "yaasin"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["يس", "سورة يس"]);
        }
        for key in &["baqarah", "al-baqarah", "albaqarah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["البقرة", "سورة البقرة"]);
        }
        for key in &["alkahf", "alkahfi", "kahfi"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الكهف", "سورة الكهف"]);
        }
        for key in &["al-ikhlas"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الإخلاص", "قل هو الله أحد"]);
        }
        for key in &["falaq", "al-falaq"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الفلق", "سورة الفلق"]);
        }
        for key in &["ar-rahman", "arrahman", "surat rahman"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الرحمن", "سورة الرحمن"]);
        }
        for key in &["almulk", "al-mulk", "muluk"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الملك", "سورة الملك", "تبارك"]);
        }
        for key in &["waqiah", "waqiyah", "al-waqiah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الواقعة", "سورة الواقعة"]);
        }
        for key in &["hujurat", "al-hujurat"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الحجرات", "سورة الحجرات"]);
        }
        for key in &["ahzab", "al-ahzab"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الأحزاب", "سورة الأحزاب"]);
        }
        for key in &["an-nisa", "annisa"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["النساء", "سورة النساء"]);
        }
        for key in &["maidah", "al-maidah", "almaidah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["المائدة", "سورة المائدة"]);
        }
        for key in &["at-talaq", "attalaq"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الطلاق", "سورة الطلاق"]);
        }
        for key in &["ar-rum", "arrum", "surat rum"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الروم", "سورة الروم"]);
        }
        for key in &["al-imran", "al imran", "ali imran"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["آل عمران", "سورة آل عمران"]);
        }
        for key in &["al-anfal", "anfal"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الأنفال", "سورة الأنفال"]);
        }
        for key in &["al-hasyr", "hasyr", "alhasyr"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الحشر", "سورة الحشر"]);
        }

        // ══════════════════════════════════════════════════════════════
        // BATCH 19: High-frequency words confirmed missing from term_map
        // ══════════════════════════════════════════════════════════════

        // ── P0: "islam" standalone — appears in almost every query ──
        // e.g. "hukum X dalam islam", "menurut pandangan islam", "fiqh islam"
        for key in &["islam"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الإسلام", "إسلام"]);
        }
        // "science", "knowledge" to complement batch18 "ilmu"
        for key in &["science", "knowledge", "sciences"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["العلم", "علم", "علوم"]);
        }

        // ── P1: Social / political context words ──
        for key in &["keluarga", "family", "household"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["أسرة", "العائلة", "الأهل"]);
        }
        for key in &["masyarakat", "society", "komunitas", "community"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مجتمع", "الأمة", "الناس"]);
        }
        for key in &["negara", "state", "pemerintahan", "government"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["دولة", "الحكومة", "الدولة"]);
        }
        for key in &["pemimpin", "kepemimpinan", "leader", "leadership"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["قيادة", "الإمارة", "رئيس"]);
        }
        for key in &["hak", "rights", "right"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["حق", "الحقوق"]);
        }
        for key in &["kewajiban", "obligation", "tugas", "duties"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["واجب", "الفريضة", "الوجوب"]);
        }
        for key in &["larangan", "prohibition", "pantangan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["نهي", "التحريم", "المحرمات"]);
        }

        // ── P1: Demographics ──
        for key in &["pria", "laki-laki", "lelaki", "male"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الرجل", "الذكر", "رجل"]);
        }
        for key in &["remaja", "pemuda", "youth", "teenager"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["شاب", "الشباب", "مراهق"]);
        }
        for key in &["dewasa", "adult", "orang dewasa"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["بالغ", "الراشد", "البالغ"]);
        }

        // ── P2: Quranic sciences & learning terms ──
        for key in &["tajwid", "tajweed"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["تجويد", "التجويد", "أحكام التلاوة"]);
        }
        for key in &["makhraj", "makhroj", "makhraj huruf"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مخرج", "مخارج الحروف"]);
        }
        for key in &["mad", "mad far'i", "mad asli"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مد", "أحكام المد"]);
        }
        for key in &["idgham"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["إدغام", "حكم الإدغام"]);
        }
        for key in &["ikhfa", "ikhfaa"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["إخفاء", "حكم الإخفاء"]);
        }
        for key in &["iqlab"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["إقلاب", "حكم الإقلاب"]);
        }
        for key in &["idzhar", "izhar"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["إظهار", "حكم الإظهار"]);
        }

        // ── P2: Practical wisdom/ethics terms ──
        for key in &["hikmah", "hikmat", "wisdom"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["حكمة", "الحكمة"]);
        }
        for key in &["nasihat", "nashihat", "nasehat", "advice", "counsel"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["نصيحة", "النصيحة"]);
        }
        for key in &["rezeki", "rizki", "rizq", "sustenance", "provision"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["رزق", "الرزق"]);
        }
        for key in &["wasilah", "wasila", "means", "instrument"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["وسيلة", "الوسيلة"]);
        }
        for key in &["mudharat", "mudhorat", "damage", "harm"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ضرر", "المضرة", "المفسدة"]);
        }

        // ── P2: Islamic sects / groups often searched ──
        for key in &["sunni", "ahlussunnah", "aswaja", "ahlusunnah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["أهل السنة", "السنة والجماعة"]);
        }
        for key in &["syiah", "syi'ah", "shia", "syiyah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الشيعة", "شيعة"]);
        }
        for key in &["wahhabi", "wahhabiyah", "wahabisme"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الوهابية", "ابن عبد الوهاب"]);
        }
        for key in &["salafi", "salafiyah", "salafiyyah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["السلفية", "السلف الصالح"]);
        }
        for key in &["khawarij", "kharijites"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الخوارج"]);
        }
        for key in &["muktazilah", "mu'tazilah", "mutazilah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["المعتزلة"]);
        }

        // ── P3: Zakat asnaf (8 recipients) ──
        for key in &["mustahiq", "mustahig", "penerima zakat"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مستحق", "مصارف الزكاة", "أصناف الزكاة"]);
        }
        for key in &["amil", "amil zakat"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["عامل", "عامل الزكاة"]);
        }
        for key in &["muallaf"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مؤلفة القلوب", "المؤلف"]);
        }
        for key in &["gharim", "gharimin"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الغارمين", "الغارم"]);
        }
        for key in &["ibnu sabil", "ibn sabil"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ابن السبيل"]);
        }
        for key in &["fi sabilillah", "sabilillah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["في سبيل الله", "سبيل الله"]);
        }

        // ── P3: Biography/history query context words ──
        for key in &["kehidupan", "hayat", "life"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["حياة", "السيرة", "الحياة"]);
        }
        for key in &["masa", "zaman", "era", "period", "abad"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["عصر", "زمان", "مرحلة"]);
        }
        for key in &["perkembangan", "development", "pertumbuhan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["تطور", "نمو"]);
        }
        for key in &["pengaruh", "influence", "dampak"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["أثر", "تأثير"]);
        }
        for key in &["hubungan", "relationship", "connection"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["علاقة", "الصلة"]);
        }

        // ── P3: Worshippers & roles ──
        for key in &["mushaf", "quran book"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مصحف", "المصحف"]);
        }
        for key in &["hafiz", "hafidz", "hafizh", "memorizer"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["حافظ", "الحافظ", "حفظة القرآن"]);
        }
        for key in &["qari", "qorri", "reciter"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["قارئ", "القراء"]);
        }
        for key in &["mufassir", "tafsir scholar"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مفسر", "المفسرون"]);
        }
        for key in &["muhadits", "muhaddits", "hadith scholar"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["محدث", "المحدثون"]);
        }
        for key in &["mufti"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مفتي", "الإفتاء"]);
        }

        // ── P3: Common question starters seen in queries ──
        for key in &["mengapa", "kenapa", "why"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["لماذا"]);
        }
        for key in &["bagaimana", "how", "cara"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["كيف", "كيفية"]);
        }
        for key in &["kapan", "when"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["متى"]);
        }
        for key in &["dimana", "where"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["أين"]);
        }

        // ══════════════════════════════════════════════════════════════
        // BATCH 20: Final zero-result fixes from V17b eval analysis
        // Targets: "berbuat baik kepada sesama" + "mencabut alat bantu napas"
        // + preemptive coverage for similar query patterns
        // ══════════════════════════════════════════════════════════════

        // ── "berbuat baik kepada sesama" ──
        // All four words were unmapped in V17b → zero results
        for key in &["baik", "good", "kebaikan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["حسن", "خير", "الإحسان"]);
        }
        for key in &["sesama", "orang lain", "manusia", "others", "fellow"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الناس", "الآخرين", "الغير"]);
        }
        for key in &["berbuat", "buat", "perbuatan", "action", "deed"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["فعل", "عمل", "الأعمال"]);
        }
        for key in &["kepada", "terhadap", "toward"] {
            // Preposition; map to empty so it doesn't block result
            self.term_map.entry(key.to_string()).or_insert(vec![]);
        }

        // ── "mencabut alat bantu napas" ──
        // Context: withdrawing life-support/ventilator (bioethics query)
        for key in &["mencabut", "cabut", "melepas", "withdraw", "remove"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["نزع", "فصل", "إيقاف"]);
        }
        for key in &["alat", "alat-alat", "peralatan", "device", "tool", "machine"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["جهاز", "الأجهزة", "آلة"]);
        }
        for key in &["napas", "pernafasan", "bernapas", "breathing", "breath"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["تنفس", "التنفس", "الشهيق"]);
        }
        for key in &["bantu", "membantu", "bantuan", "assistance", "support"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مساعدة", "معاون", "إسناد"]);
        }

        // ── Additional jinayat/compensation terms (fix "ganti rugi" fragments) ──
        for key in &["ganti", "penggantian", "compensation", "replace"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["تعويض", "الأرش", "دية"]);
        }
        for key in &["rugi", "kerugian", "damage", "loss"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ضرر", "خسارة"]);
        }

        // ── Self-defense terms (fix "pembunuhan untuk bela diri") ──
        for key in &["bela", "membela", "defend", "defense"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["دفع", "الدفاع"]);
        }
        for key in &["diri", "diri sendiri", "self"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["النفس", "الذات"]);
        }

        // ── "semi" prefix patterns ──
        for key in &["semi", "partly", "sebagian"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["شبه", "نصف"]);
        }

        // ── Generic Indonesian verbs that appear in queries ──
        for key in &["tidak", "bukan", "tidak boleh", "not"] {
            self.term_map.entry(key.to_string()).or_insert(vec![]);  // negation, no Arabic needed
        }
        for key in &["untuk", "bagi", "for"] {
            self.term_map.entry(key.to_string()).or_insert(vec![]);  // preposition, no Arabic needed
        }
        for key in &["dengan", "bersama", "with", "together"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مع"]);
        }
        for key in &["dalam", "di dalam", "inside"] {
            self.term_map.entry(key.to_string()).or_insert(vec![]);  // preposition
        }
        for key in &["tentang", "mengenai", "regarding", "about"] {
            self.term_map.entry(key.to_string()).or_insert(vec![]);  // preposition
        }

        // ══════════════════════════════════════════════════════════════
        // BATCH 21: Fix "apa" degenerate query (last V17b zero)
        // "apa" = Indonesian for "what?" → Arabic "ما" (mā)
        // Without this, standalone "apa" query returns 0 results in Arabic corpus.
        // ══════════════════════════════════════════════════════════════
        for key in &["apa", "apakah", "apa itu", "what"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ما", "الإسلام"]);
        }

        // ══════════════════════════════════════════════════════════════
        // BATCH 22: Improve 42 low-result (1-result) queries from V17b
        // Three categories:
        //   A) Usul al-fiqh maxims (qawa'id) in transliteration
        //   B) Modern technology concepts (pandangan islam tentang X)
        //   C) Modern social/political concepts
        // ══════════════════════════════════════════════════════════════

        // ── A) QAWA'ID FIQHIYYAH — Usul al-fiqh maxims ──
        // "al yaqin la yazul bi al syak" (certainty not removed by doubt)
        for key in &["yaqin", "yakin", "certainty", "yakin yaitu", "al-yaqin"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["اليقين", "القطع", "الجزم"]);
        }
        for key in &["syak", "shak", "shakk", "doubt", "keraguan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الشك", "الشبهة"]);
        }
        // "al masyaqqah tajlib al taysir" (hardship brings ease)
        for key in &["masyaqqah", "mashaqqah", "mashaqqoh", "masyaqah", "hardship", "kesulitan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["المشقة", "الحرج", "الضيق"]);
        }
        for key in &["taysir", "taysiir", "ease", "kemudahan", "rukhsah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["التيسير", "التخفيف", "الرخصة"]);
        }
        // "al adah muhakkamah" (custom/practice can be the basis of ruling)
        for key in &["adah", "'adat", "adat", "custom", "kebiasaan", "uruf"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["العادة", "العرف", "التقاليد"]);
        }
        for key in &["muhakkamah", "muhakkam", "hukum adat"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["محكمة", "محكم"]);
        }
        // "dar'u al mafasid muqaddam ala jalb al mashalih" (prevention > benefit)
        for key in &["mafasid", "mafsadat", "mafsadah", "harm prevention", "kerusakan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["المفاسد", "الضرر", "الفساد", "درء المفاسد"]);
        }
        for key in &["mashalih", "masalih", "maslahah", "manfaat", "maslahah", "benefit"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["المصالح", "المصلحة", "النفع"]);
        }
        for key in &["muqaddam", "didahulukan", "priority", "precedence"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مقدم", "أولى", "الأولى"]);
        }
        // General qawa'id terms
        for key in &["qawaid", "qawa'id", "qa'idah", "legal maxim", "fikih maxim"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["القواعد الفقهية", "القاعدة", "ضابط"]);
        }
        for key in &["ushul", "usul fiqh", "ushul fiqih", "fiqh principles"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["أصول الفقه", "الأصول"]);
        }

        // ── B) MODERN TECHNOLOGY CONCEPTS ──
        // Artificial Intelligence
        for key in &["artificial intelligence", "kecerdasan buatan", "kecerdasan artifisial"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الذكاء الاصطناعي", "التقنية"]);
        }
        for key in &["ai", "machine learning", "deep learning"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الذكاء الاصطناعي", "تقنية المعلومات"]);
        }
        // Robotics
        for key in &["robot", "robotika", "robotics", "automation", "otomasi"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الآلة", "الروبوت", "التقنية"]);
        }
        // Communication technology
        for key in &["smartphone", "handphone", "ponsel", "telepon", "hp"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الهاتف الذكي", "الاتصالات"]);
        }
        for key in &["internet", "iot", "internet of things", "jaringan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الإنترنت", "شبكة الاتصالات"]);
        }
        for key in &["drone", "pesawat tanpa awak", "uav"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الطائرة", "الطائرات المسيرة"]);
        }
        for key in &["blockchain", "cryptocurrency", "bitcoin", "kripto"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["العملات الرقمية", "المعاملات الرقمية", "المال"]);
        }
        for key in &["cloud computing", "komputasi awan", "saas"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["تقنية المعلومات", "الخدمات الرقمية"]);
        }
        for key in &["e-commerce", "perdagangan elektronik", "jual beli online", "e commerce"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["التجارة الإلكترونية", "البيع والشراء", "المعاملات"]);
        }
        for key in &["edtech", "pendidikan teknologi", "online learning"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["التعليم", "التعلم", "العلم"]);
        }
        for key in &["telemedicine", "pengobatan online", "dokter online"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["التداوي", "الطب", "العلاج"]);
        }
        for key in &["metaverse", "virtual reality", "augmented reality", "ar", "vr"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الواقع الافتراضي", "التقنية"]);
        }
        for key in &["deepfake", "manipulasi gambar", "hoaks"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الكذب", "الغش", "التلاعب"]);
        }
        for key in &["3d printing", "cetak tiga dimensi", "3d print"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الصناعة", "التصنيع", "التقنية"]);
        }
        for key in &["biometric", "biometrik", "fingerprint", "sidik jari"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الهوية", "القياسات الحيوية"]);
        }
        // Medical biotechnology
        for key in &["crispr", "gene editing", "rekayasa genetika", "stem cell", "sel punca"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["التدخل الجيني", "الطب", "البيولوجيا"]);
        }
        for key in &["nanotechnology", "nanoteknologi", "nanotek"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["التقنية", "الطب"]);
        }
        for key in &["brain computer interface", "bci", "antarmuka otak"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الدماغ", "العقل", "التقنية"]);
        }
        for key in &["autonomous vehicle", "mobil otonom", "self-driving"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["المركبة", "التقنية", "السيارات"]);
        }
        for key in &["space tourism", "pariwisata luar angkasa", "wisata luar angkasa"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الفضاء", "السفر", "السياحة"]);
        }
        for key in &["nuclear energy", "energi nuklir", "pembangkit nuklir"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الطاقة النووية", "الطاقة"]);
        }
        for key in &["smart home", "rumah pintar", "iot home"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["البيت", "الاتصالات"]);
        }
        // General technology
        for key in &["teknologi", "technology", "teknik", "inovasi", "innovation"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["التقنية", "الاختراع", "الصناعة"]);
        }

        // ── C) MODERN SOCIAL, POLITICAL & ETHICAL CONCEPTS ──
        for key in &["demokrasi", "democracy", "demokratis"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الديمقراطية", "الشورى", "الحكم"]);
        }
        for key in &["terorisme", "terrorism", "teroris", "terrorist"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الإرهاب", "الفتنة", "الخوارج"]);
        }
        for key in &["radikalisme", "radicalism", "radikal", "ekstremisme", "extremism"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["التطرف", "الغلو", "الراديكالية"]);
        }
        for key in &["nasionalisme", "nationalism", "nasional", "kebangsaan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["القومية", "الوطنية", "الأمة"]);
        }
        for key in &["filantropi", "philanthropy", "kedermawanan", "donasi", "donation"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الصدقة", "التبرع", "الكرم", "البر"]);
        }
        for key in &["kremasi", "cremate", "cremation", "membakar jenazah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["حرق", "الجنازة", "المحرم"]);
        }
        for key in &["mental health", "kesehatan mental", "kesehatan jiwa", "gangguan jiwa"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الصحة النفسية", "العقل", "النفس"]);
        }
        for key in &["surrogacy", "ibu pengganti", "sewa rahim", "titipan rahim"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الأم البديلة", "استئجار الرحم", "النسب"]);
        }
        for key in &["racism", "ras", "rasisme", "diskriminasi ras"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["العنصرية", "التمييز", "الجاهلية"]);
        }
        for key in &["hak asasi manusia", "ham", "human rights", "hak manusia"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["حقوق الإنسان", "حقوق", "الحقوق"]);
        }
        for key in &["pandangan", "perspektif", "pendapat", "view", "perspective", "opinion"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الرأي", "الحكم", "النظر"]);
        }
        for key in &["filosofi", "philosophy", "filsafat", "hikmat", "hikmah ilmu"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الفلسفة", "الحكمة", "المنطق"]);
        }
        for key in &["pendidikan", "education", "pembelajaran", "belajar", "mengajar"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["التعليم", "التربية", "العلم", "طلب العلم"]);
        }
        for key in &["tetangga", "jiran", "neighbor", "neighbour"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الجار", "الجيران", "حق الجار"]);
        }
        for key in &["membela", "defending", "pembela"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الدفاع", "الدفع", "النصرة"]);
        }
        for key in &["sayings", "says", "say"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["حكم", "قال"]);
        }

        // ══════════════════════════════════════════════════════════════
        // BATCH 23: Targeted fixes for remaining low-result queries
        // Sources: V17b queries with 1-3 results after BATCH 22
        // ══════════════════════════════════════════════════════════════

        // ── Transliterated qawa'id: specific grammatical forms ──
        // "al umur bi maqashidiha" → الأمور بمقاصدها
        // "umur" in this context = الأمور (matters), not age
        for key in &["maqashidiha", "maqasidiha", "maqashiduha"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مقاصدها", "مقاصد"]);
        }
        for key in &["lazul", "yazul", "tazul", "la yazul"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["يزول", "زال"]);
        }
        for key in &["jalb", "jalab"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["جلب", "جذب"]);
        }
        for key in &["dar'u", "dar", "dara'", "def'u", "daf'u"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["درء", "دفع", "رفع"]);
        }
        for key in &["ala", "alaa", "above", "over"] {
            self.term_map.entry(key.to_string()).or_insert(vec![]);  // preposition, skip
        }
        // "al adah muhakkamah" extra support
        for key in &["muhakkamah", "al-muhakkamah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["محكمة", "حاكم"]);
        }

        // ── Social media & digital era ──
        for key in &["social media", "media sosial", "medsos", "socmed"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["وسائل التواصل الاجتماعي", "الإعلام"]);
        }
        for key in &["social", "sosial"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["اجتماعي", "التواصل الاجتماعي"]);
        }
        for key in &["media", "medium"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["وسائل", "الإعلام"]);
        }
        for key in &["digital", "digitalisasi"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["رقمي", "الرقمي"]);
        }
        for key in &["era", "zaman", "masa kini", "modern"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["العصر", "الزمان", "الحديث"]);
        }
        for key in &["dai", "da'i", "muballigh", "preacher", "penceramah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الداعية", "المبلغ", "الداعي", "الدعوة"]);
        }

        // ── Salah hand-placement query: "meletakkan tangan di dada atau perut" ──
        // About placing hands on chest vs stomach during prayer
        for key in &["meletakkan", "meletakan", "place", "placing", "menaruh"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["وضع", "يضع"]);
        }
        for key in &["dada", "chest", "breast"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الصدر", "صدر"]);
        }
        for key in &["perut", "stomach", "belly"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["البطن", "بطن"]);
        }

        // ── "dai di era digital" ──
        for key in &["golongan", "era digital", "zaman digital"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["العصر الرقمي"]);
        }

        // ── "tafsir ayat kursi" ── (only 4 results — improve with specific terms)
        for key in &["ayat kursi", "aayat al-kursi", "ayatul kursi"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["آية الكرسي"]);
        }
        for key in &["kursi", "kursy"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الكرسي", "عرش"]);
        }

        // ── Ihya Ulumuddin specific queries ──
        // These have T:ihya ulumuddin mapped but only 5 results (diversity filter)
        // Adding more specific book terms might help variety
        for key in &["ihya", "ihya'", "ihya ulumuddin", "ihya ulum al din"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["إحياء علوم الدين", "إحياء"]);
        }
        for key in &["ghazali", "al-ghazali", "imam ghazali"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الغزالي", "أبو حامد الغزالي"]);
        }
        for key in &["ulum al din", "ulumuddin", "ulum", "keagamaan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["علوم الدين", "الدين"]);
        }

        // ── Body parts (for various prayer and fiqh queries) ──
        for key in &["kepala", "head"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الرأس", "رأس"]);
        }
        for key in &["kaki", "feet", "foot"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["القدم", "الرجل", "قدم"]);
        }
        for key in &["telinga", "ear"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الأذن", "أذن"]);
        }
        for key in &["mata", "eye", "eyes"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["العين", "عين"]);
        }
        for key in &["mulut", "mouth"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الفم"]);
        }
        for key in &["hidung", "nose"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الأنف"]);
        }
        for key in &["punggung", "back", "back body"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الظهر", "الظهر"]);
        }
        for key in &["leher", "neck"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["العنق", "الرقبة"]);
        }

        // BATCH 24: High-range quality improvements (9838-10030 "hukum X dalam keadaan Y" patterns)
        // Also general quality for any query using these common action/object words

        // ── Hair & cutting ──
        for key in &["rambut", "bulu", "hair"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["شعر", "الشعر"]);
        }
        for key in &["potong", "memotong", "potongan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["قطع", "قص", "حلق"]);
        }

        // ── Music / playing music ──
        for key in &["bermusik", "bermain musik", "memainkan musik"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الغناء", "المعازف", "الموسيقى"]);
        }

        // ── Perfume / fragrance ──
        for key in &["wewangian", "parfum", "minyak wangi", "pewangi", "fragrance", "perfume"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الطيب", "التطيب", "العطر"]);
        }

        // ── Statue / idol making ──
        for key in &["patung", "arca", "idol", "statue"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الصنم", "الأصنام", "صنم"]);
        }

        // ── Borrowing / loan ──
        for key in &["meminjam", "pinjam", "pinjaman", "borrow", "loan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["قرض", "الاقتراض", "الدين"]);
        }

        // ── Wearing / using (memakai wewangian, memakai emas, etc.) ──
        for key in &["memakai", "mengenakan", "pemakaian"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["لبس", "ارتداء"]);
        }

        // ── Not knowing / ignorance (dalam keadaan tidak tahu) ──
        for key in &["tidak tahu", "tidak mengetahui", "jahil", "ignorant"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["جاهل", "الجهل", "عدم العلم"]);
        }

        // ── Condition words for contextual queries ──
        for key in &["keadaan", "kondisi", "situasi", "state", "condition"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["حال", "الحال"]);
        }

        // ── Shaving beard / hair (potong rambut / mencukur) ──
        // (mencukur already mapped; reinforce rambut + jenggot pair context)
        for key in &["potong rambut", "cukur rambut", "gunting rambut"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["قص الشعر", "حلق الشعر", "الشعر"]);
        }

        // ── Making / creating ──
        for key in &["membuat", "pembuatan", "create", "making"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["صنع", "إنشاء"]);
        }

        // ── Dzulqa'dah sacred month context ──
        // Dzulqa'dah is one of 4 sacred months (الأشهر الحرم); expand to include that context
        // Using insert (not or_insert) to override earlier narrower mappings
        for key in &["dzulqa'dah", "dzulqadah", "dhul qa'dah"] {
            self.term_map.insert(key.to_string(), vec!["ذو القعدة", "الأشهر الحرم"]);
        }
        for key in &["dzulhijjah", "dzulhijja", "dhul hijjah"] {
            self.term_map.insert(key.to_string(), vec!["ذو الحجة", "الأشهر الحرم", "شهر ذي الحجة"]);
        }

        // BATCH 25: Quality improvements for 7000-7560 range — professions, inheritances, food animals
        // Based on analysis of query 7000-7560 dataset structure

        // ── Inheritance special cases (7500-7517) ──
        // aul: shares exceed denominator → expand denominator
        for key in &["aul", "awl"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["عول", "العول", "التعصيب"]);
        }
        // radd: shares less than denominator → remainder returned to heirs
        for key in &["radd", "rad"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["رد", "الرد", "مسألة الرد"]);
        }
        // gharrawain: famous inheritance case involving husband/wife + parent
        for key in &["gharrawain", "gharraoain", "udmariyah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الغراوان", "المسألة الغراوين"]);
        }
        // musytarakah/hijriyah: complex inheritance case
        for key in &["musytarakah", "musytarakah", "hijriyah", "hijariyah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["المشتركة", "الحجرية", "المشركة"]);
        }
        // akdariyah: famous problematic inheritance case
        for key in &["akdariyah", "akdhariyah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الأكدرية", "مسألة الأكدرية"]);
        }
        // mafqud: missing person (inheritance)
        for key in &["mafqud", "mafkud", "orang hilang"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مفقود", "المفقود", "أحكام المفقود"]);
        }
        // khuntsa musykil: intersex inheritance
        for key in &["khuntsa", "huntsa", "khuntsa musykil"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["خنثى", "الخنثى", "الخنثى المشكل"]);
        }

        // ── Food: sea creatures not yet mapped individually (7208-7280) ──
        for key in &["lobster", "udang karang"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["جراد البحر", "حيوان البحر", "القشريات"]);
        }
        for key in &["tiram", "oyster"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["محار", "المحار", "حيوان البحر"]);
        }
        for key in &["kerang", "clam", "shellfish"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["بلح البحر", "المحار", "حيوان البحر"]);
        }
        for key in &["cumi", "cumi-cumi", "squid"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["حبار", "الحبار", "حيوان البحر"]);
        }
        for key in &["ubur-ubur", "ubur", "jellyfish"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["قنديل البحر", "حيوان البحر"]);
        }
        for key in &["teripang", "sea cucumber"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["تريبانج", "حيوان البحر", "الخيار البحري"]);
        }

        // ── Land animals not yet mapped ──
        for key in &["unta", "camel"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["إبل", "الإبل", "الناقة"]);
        }
        for key in &["kerbau", "buffalo"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["جاموس", "الجاموس", "أكل الجاموس"]);
        }
        for key in &["bebek", "duck"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["بط", "البط", "أكل البط"]);
        }
        for key in &["merpati", "dove", "pigeon"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["حمام", "الحمام"]);
        }
        for key in &["rusa", "deer", "venison"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["غزال", "الغزال", "الصيد"]);
        }
        for key in &["burung puyuh", "quail"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["سمان", "طائر السمان"]);
        }

        // ── Special foods ──
        for key in &["tape", "tapai"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الخمر", "المسكر", "النبيذ", "التخمير"]);
        }
        for key in &["kombucha"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["المسكر", "الخمر", "التخمير"]);
        }
        for key in &["jamur", "mushroom"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الفطر", "الكمأة"]);
        }

        // ── Profession types for "hukum [profession] shalat/puasa" patterns (7010-7200) ──
        for key in &["tentara", "militer", "prajurit", "soldier", "military"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["جندي", "المجاهد", "الغازي"]);
        }
        for key in &["polisi", "police", "officer"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["شرطة", "شرطي"]);
        }
        for key in &["nelayan", "fisherman", "fisher"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["صياد", "الصياد"]);
        }
        for key in &["supir", "sopir", "driver"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["سائق", "السائق"]);
        }
        for key in &["pilot"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["طيار", "الطيار"]);
        }
        for key in &["astronot", "astronaut"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["رائد الفضاء", "الفضاء"]);
        }
        for key in &["mahasiswa", "university student"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["طالب", "الطلاب"]);
        }
        for key in &["pelajar"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["طالب", "المتعلم"]);
        }
        for key in &["pedagang", "merchant", "trader"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["تاجر", "البائع", "التاجر"]);
        }
        for key in &["petani", "farmer"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مزارع", "الفلاح", "الزراعة"]);
        }

        // ── Person categories ──
        for key in &["bayi", "infant", "newborn"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["رضيع", "الرضيع", "المولود"]);
        }
        for key in &["balita", "toddler"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["طفل", "الطفل الصغير"]);
        }
        for key in &["remaja", "teenager", "adolescent"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مراهق", "الشباب", "الشاب"]);
        }
        for key in &["lansia", "elderly", "orang tua"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["شيخ", "كبير السن", "الشيخ الكبير"]);
        }
        for key in &["difabel", "disabled", "penyandang cacat"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["معاق", "المعاق", "ذو العذر"]);
        }
        for key in &["tunanetra", "blind person"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["أعمى", "الأعمى", "العمياء"]);
        }
        for key in &["tunarungu", "deaf person"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["أصم", "الأصم", "الطرش"]);
        }
        for key in &["tunawicara", "mute person"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الأخرس", "الصمت"]);
        }
        for key in &["penghuni penjara", "prisoner", "narapidana"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["سجين", "المسجون"]);
        }
        for key in &["pengungsi", "refugee"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["لاجئ", "اللاجئ", "المهاجر"]);
        }
        for key in &["korban bencana", "disaster victim"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["منكوب", "المنكوبون", "الضرورة"]);
        }

        // BATCH 26: Wild animals, economic terms, market manipulation — 7700-7840 queries
        // ══════════════════════════════════════════════════════════════════════════════

        // ─── Wild/Exotic Land Animals (hukum memakan [animal]) ───
        for key in &["harimau", "macan", "tiger"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["نمر", "السباع", "الحيوانات المفترسة"]);
        }
        for key in &["singa", "lion"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["أسد", "الأسد", "السباع"]);
        }
        for key in &["serigala", "wolf"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ذئب", "الذئب", "السباع"]);
        }
        for key in &["rubah", "fox"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ثعلب", "الثعلب"]);
        }
        for key in &["beruang", "bear"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["دب", "الدب"]);
        }
        for key in &["gajah", "elephant"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["فيل", "الفيل"]);
        }
        for key in &["kuda nil", "badak uri", "hippopotamus"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["فرس النهر"]);
        }
        for key in &["badak", "rhinoceros"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["كركدن", "وحيد القرن"]);
        }
        for key in &["jerapah", "giraffe"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["زرافة"]);
        }
        for key in &["zebra"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["حمار الوحش"]);
        }
        for key in &["monyet", "kera", "monkey"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["قرد", "القرد", "الرئيسيات"]);
        }
        for key in &["gorila", "gorilla"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["غوريلا", "الرئيسيات"]);
        }
        for key in &["orangutan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["أورانغوتان", "الرئيسيات"]);
        }
        for key in &["landak", "hedgehog", "porcupine"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["شيهم", "القنفذ", "الحيوانات البرية"]);
        }
        for key in &["berang-berang", "otter"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["قندس", "الثعلب المائي"]);
        }
        for key in &["musang", "civet"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ابن عرس", "كلب الزباد"]);
        }

        // ─── Marine/Aquatic Animals ───
        for key in &["lumba-lumba", "lumba", "dolphin"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["دلفين", "حيوان البحر"]);
        }
        for key in &["paus", "whale"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["حوت", "الحوت", "حيوان البحر"]);
        }
        for key in &["hiu", "shark"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["قرش", "سمك القرش", "حيوان البحر"]);
        }
        for key in &["pari", "stingray"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["راي", "سمك الراي", "حيوان البحر"]);
        }
        for key in &["belut", "eel"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["جريث", "ثعبان البحر", "الأسماك"]);
        }
        for key in &["lele", "catfish"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["سلور", "سمك السلور", "الأسماك"]);
        }
        for key in &["nila", "tilapia"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["بلطي", "سمكة النيل", "الأسماك"]);
        }
        for key in &["gurame", "gourami"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["السمك", "حكم الأسماك"]);
        }

        // ─── Economic/Market Terms (7700-7750 range) ───
        for key in &["pajak", "tax", "taxation"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["ضريبة", "الجزية", "الخراج", "ضريبة المال"]);
        }
        for key in &["kartel", "cartel"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["احتكار", "الاحتكار"]);
        }
        for key in &["ijon"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["بيع الثمر قبل بدو صلاحه", "بيع السلم", "الغرر"]);
        }
        for key in &["tengkulak"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["السمسار", "الوسيط التجاري"]);
        }
        for key in &["menimbun", "penimbunan"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["احتكار", "الاحتكار", "تحريم الاحتكار"]);
        }
        for key in &["spekulasi", "spekulator"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["مضاربة", "الغرر", "بيع الغرر"]);
        }
        for key in &["manipulasi pasar", "market manipulation"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الغش", "غش التجارة", "التلاعب"]);
        }
        for key in &["insider trading"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الغش التجاري", "الخيانة"]);
        }
        for key in &["pencucian uang", "money laundering"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["غسيل الأموال", "المال الحرام"]);
        }
        for key in &["gratifikasi", "gratuity"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["رشوة", "الرشوة"]);
        }
        for key in &["pungli", "pungutan liar"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["رشوة", "اختلاس", "غصب"]);
        }
        for key in &["suap", "bribe", "bribery"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["رشوة", "الرشوة", "حكم الرشوة"]);
        }
        for key in &["korupsi", "corruption"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الفساد", "الاختلاس", "رشوة"]);
        }
        for key in &["PHK", "pemutusan hubungan kerja", "layoff", "fired"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["فسخ عقد العمل", "إنهاء العمل", "عقد العمل"]);
        }
        for key in &["outsourcing"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["إجارة", "عقد العمل", "الاستعانة بمصادر خارجية"]);
        }
        for key in &["kerja kontrak", "kontrak kerja"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["عقد العمل", "الإجارة"]);
        }
        for key in &["dumping"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الإغراق التجاري", "بيع بخسارة"]);
        }
        for key in &["upah minimum", "minimum wage"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الأجرة", "حد الأجر", "أجر العامل"]);
        }

        // ─── Digital economy (7720-7750) ───
        for key in &["sukuk", "obligasi syariah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["صكوك", "السندات الإسلامية"]);
        }
        for key in &["fintech", "fintech syariah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["التمويل الإسلامي الرقمي", "التكنولوجيا المالية"]);
        }
        for key in &["crowdfunding", "crowdfunding syariah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["التمويل الجماعي", "جمع التبرعات"]);
        }
        for key in &["jual beli followers", "jual followers"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["بيع ما لا قيمة له", "البيع الباطل"]);
        }
        for key in &["jual data pribadi", "jual data"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["بيع المعلومات", "الأمانة", "حفظ الأسرار"]);
        }

        // ─── Islamic political/social terms (7730-7740) ───
        for key in &["sistem khilafah", "khilafah islamiyah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الخلافة الإسلامية", "نظام الخلافة"]);
        }
        for key in &["implementasi syariah", "penerapan syariah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["تطبيق الشريعة", "إقامة الشريعة"]);
        }
        for key in &["hudud", "hukum hudud"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الحدود", "حدود الله", "عقوبة الحد"]);
        }
        for key in &["qishas", "qishash", "qisas"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["القصاص", "حكم القصاص"]);
        }
        for key in &["hukum pidana islam", "jinayat", "jinayah"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الجنايات", "جناية", "حدود الجنايات"]);
        }
        for key in &["filantropi", "philanthropy"] {
            self.term_map.entry(key.to_string()).or_insert(vec!["الخير", "البر", "العطاء"]);
        }
    }

    fn build_domain_detector(&mut self) {
        // ═══ v12: Weighted domain detection ═══
        // Weight 3 = primary (definitive domain keyword, e.g., "shalat" → ibadah)
        // Weight 2 = strong secondary (strongly associated)
        // Weight 1 = weak contextual (could belong to multiple domains, e.g., "perempuan", "emas")
        let domain_map: Vec<(&str, FiqhDomain, i32)> = vec![
            // Ibadah — PRIMARY (weight 3)
            ("shalat", FiqhDomain::Ibadah, 3), ("solat", FiqhDomain::Ibadah, 3),
            ("sholat", FiqhDomain::Ibadah, 3), ("salat", FiqhDomain::Ibadah, 3),
            ("puasa", FiqhDomain::Ibadah, 3), ("shaum", FiqhDomain::Ibadah, 3),
            ("zakat", FiqhDomain::Ibadah, 3), ("zakah", FiqhDomain::Ibadah, 3),
            ("haji", FiqhDomain::Ibadah, 3), ("umroh", FiqhDomain::Ibadah, 3),
            ("prayer", FiqhDomain::Ibadah, 3), ("fasting", FiqhDomain::Ibadah, 3),
            ("adzan", FiqhDomain::Ibadah, 3), ("qurban", FiqhDomain::Ibadah, 3),
            ("itikaf", FiqhDomain::Ibadah, 3), ("ihram", FiqhDomain::Ibadah, 3),
            ("tawaf", FiqhDomain::Ibadah, 3), ("sa'i", FiqhDomain::Ibadah, 3),
            ("wukuf", FiqhDomain::Ibadah, 3), ("kurban", FiqhDomain::Ibadah, 3),
            // Ibadah — SECONDARY (weight 2)
            ("doa", FiqhDomain::Ibadah, 2), ("dzikir", FiqhDomain::Ibadah, 2),
            ("kafarat", FiqhDomain::Ibadah, 2), ("kaffarah", FiqhDomain::Ibadah, 2),
            ("sumpah", FiqhDomain::Ibadah, 2), ("nadzar", FiqhDomain::Ibadah, 2),
            ("aqiqah", FiqhDomain::Ibadah, 2), ("fidyah", FiqhDomain::Ibadah, 2),
            ("iftar", FiqhDomain::Ibadah, 2), ("imam", FiqhDomain::Ibadah, 2),
            ("makmum", FiqhDomain::Ibadah, 2), ("khutbah", FiqhDomain::Ibadah, 2),
            ("subuh", FiqhDomain::Ibadah, 2), ("fajar", FiqhDomain::Ibadah, 2),
            ("dzuhur", FiqhDomain::Ibadah, 2), ("ashar", FiqhDomain::Ibadah, 2),
            ("maghrib", FiqhDomain::Ibadah, 2), ("isya", FiqhDomain::Ibadah, 2),
            ("qunut", FiqhDomain::Ibadah, 2), ("witir", FiqhDomain::Ibadah, 2),
            ("rakaat", FiqhDomain::Ibadah, 2), ("rakat", FiqhDomain::Ibadah, 2),
            ("jenazah", FiqhDomain::Ibadah, 2), ("janazah", FiqhDomain::Ibadah, 2),
            ("mayit", FiqhDomain::Ibadah, 2), ("sahwi", FiqhDomain::Ibadah, 2),
            ("tilawah", FiqhDomain::Ibadah, 2), ("tarawih", FiqhDomain::Ibadah, 2),
            // Ibadah — CONTEXTUAL (weight 1)
            ("wajib", FiqhDomain::Ibadah, 1), ("sunnah", FiqhDomain::Ibadah, 1),
            ("fardhu", FiqhDomain::Ibadah, 1), ("batal", FiqhDomain::Ibadah, 1),
            ("rukun", FiqhDomain::Ibadah, 1), ("darurat", FiqhDomain::Ibadah, 1),
            ("makan", FiqhDomain::Ibadah, 1), ("minum", FiqhDomain::Ibadah, 1),
            ("mati", FiqhDomain::Ibadah, 1), ("meninggal", FiqhDomain::Ibadah, 1),
            ("wafat", FiqhDomain::Ibadah, 1),

            // Thaharah — PRIMARY (weight 3)
            ("wudhu", FiqhDomain::Thaharah, 3), ("wudu", FiqhDomain::Thaharah, 3),
            ("tayammum", FiqhDomain::Thaharah, 3), ("najis", FiqhDomain::Thaharah, 3),
            ("junub", FiqhDomain::Thaharah, 3), ("janabah", FiqhDomain::Thaharah, 3),
            ("nifas", FiqhDomain::Thaharah, 3), ("istihadhah", FiqhDomain::Thaharah, 3),
            ("haid", FiqhDomain::Thaharah, 3), ("menstruasi", FiqhDomain::Thaharah, 3),
            // Thaharah — SECONDARY (weight 2)
            ("mandi", FiqhDomain::Thaharah, 2), ("suci", FiqhDomain::Thaharah, 2),
            ("bersuci", FiqhDomain::Thaharah, 2), ("purification", FiqhDomain::Thaharah, 3),
            ("istihalah", FiqhDomain::Thaharah, 2),

            // Muamalat — PRIMARY (weight 3)
            ("riba", FiqhDomain::Muamalat, 3), ("bunga", FiqhDomain::Muamalat, 3),
            ("bank", FiqhDomain::Muamalat, 3), ("asuransi", FiqhDomain::Muamalat, 3),
            ("gadai", FiqhDomain::Muamalat, 3), ("wakaf", FiqhDomain::Muamalat, 3),
            ("waris", FiqhDomain::Muamalat, 3), ("warisan", FiqhDomain::Muamalat, 3),
            ("wasiat", FiqhDomain::Muamalat, 3), ("hibah", FiqhDomain::Muamalat, 3),
            ("mudharabah", FiqhDomain::Muamalat, 3), ("musyarakah", FiqhDomain::Muamalat, 3),
            ("murabahah", FiqhDomain::Muamalat, 3),
            // Muamalat — SECONDARY (weight 2)
            ("jual", FiqhDomain::Muamalat, 2), ("beli", FiqhDomain::Muamalat, 2),
            ("utang", FiqhDomain::Muamalat, 2), ("sewa", FiqhDomain::Muamalat, 2),
            ("trade", FiqhDomain::Muamalat, 2), ("finance", FiqhDomain::Muamalat, 2),
            ("konvensional", FiqhDomain::Muamalat, 2), ("pegadaian", FiqhDomain::Muamalat, 2),
            ("akad", FiqhDomain::Muamalat, 2), ("dropship", FiqhDomain::Muamalat, 2),
            ("harta", FiqhDomain::Muamalat, 2),
            // Muamalat — CONTEXTUAL (weight 1)
            ("foto", FiqhDomain::Muamalat, 1), ("gambar", FiqhDomain::Muamalat, 1),
            ("tato", FiqhDomain::Muamalat, 1), ("musik", FiqhDomain::Muamalat, 1),
            ("rokok", FiqhDomain::Muamalat, 1), ("photo", FiqhDomain::Muamalat, 1),
            ("selfie", FiqhDomain::Muamalat, 1), ("online", FiqhDomain::Muamalat, 1),
            ("emas", FiqhDomain::Muamalat, 1), // contextual: "zakat emas" is ibadah

            // Munakahat — PRIMARY (weight 3)
            ("nikah", FiqhDomain::Munakahat, 3), ("cerai", FiqhDomain::Munakahat, 3),
            ("talak", FiqhDomain::Munakahat, 3), ("mahar", FiqhDomain::Munakahat, 3),
            ("iddah", FiqhDomain::Munakahat, 3), ("poligami", FiqhDomain::Munakahat, 3),
            ("marriage", FiqhDomain::Munakahat, 3), ("divorce", FiqhDomain::Munakahat, 3),
            ("khuluk", FiqhDomain::Munakahat, 3), ("fasakh", FiqhDomain::Munakahat, 3),
            // Munakahat — SECONDARY (weight 2)
            ("nafkah", FiqhDomain::Munakahat, 2), ("suami", FiqhDomain::Munakahat, 2),
            ("istri", FiqhDomain::Munakahat, 2), ("impoten", FiqhDomain::Munakahat, 2),
            ("wali", FiqhDomain::Munakahat, 2), ("nusyuz", FiqhDomain::Munakahat, 2),
            // Munakahat — CONTEXTUAL (weight 1) — "perempuan" alone shouldn't override ibadah
            ("perempuan", FiqhDomain::Munakahat, 1), ("wanita", FiqhDomain::Munakahat, 1),

            // Jinayat — PRIMARY (weight 3)
            ("hudud", FiqhDomain::Jinayat, 3), ("qishash", FiqhDomain::Jinayat, 3),
            ("qishas", FiqhDomain::Jinayat, 3), ("qisas", FiqhDomain::Jinayat, 3),
            ("zina", FiqhDomain::Jinayat, 3), ("pencurian", FiqhDomain::Jinayat, 3),
            ("diyat", FiqhDomain::Jinayat, 3), ("tazir", FiqhDomain::Jinayat, 3),
            ("ta'zir", FiqhDomain::Jinayat, 3),
            // Jinayat — SECONDARY (weight 2)
            ("bunuh", FiqhDomain::Jinayat, 2), ("hukuman", FiqhDomain::Jinayat, 2),
            ("mencuri", FiqhDomain::Jinayat, 2), ("curi", FiqhDomain::Jinayat, 2),
            ("membunuh", FiqhDomain::Jinayat, 2), ("pidana", FiqhDomain::Jinayat, 2),

            // Aqidah — PRIMARY (weight 3)
            ("tauhid", FiqhDomain::Aqidah, 3), ("syirik", FiqhDomain::Aqidah, 3),
            ("aqidah", FiqhDomain::Aqidah, 3), ("bid'ah", FiqhDomain::Aqidah, 3),
            ("bidah", FiqhDomain::Aqidah, 3), ("murtad", FiqhDomain::Aqidah, 3),
            ("qadar", FiqhDomain::Aqidah, 3), ("takdir", FiqhDomain::Aqidah, 3),
            ("rububiyah", FiqhDomain::Aqidah, 3), ("uluhiyah", FiqhDomain::Aqidah, 3),
            // Aqidah — SECONDARY (weight 2)
            ("iman", FiqhDomain::Aqidah, 2), ("kafir", FiqhDomain::Aqidah, 2),
            ("tawasul", FiqhDomain::Aqidah, 2), ("tawassul", FiqhDomain::Aqidah, 2),
            ("khurafat", FiqhDomain::Aqidah, 2),
            ("tawakal", FiqhDomain::Aqidah, 2), ("tawakkal", FiqhDomain::Aqidah, 2),
            ("maulid", FiqhDomain::Aqidah, 3), ("sifat", FiqhDomain::Aqidah, 2),

            // Tasawuf — PRIMARY (weight 3)
            ("tasawuf", FiqhDomain::Tasawuf, 3),
            // Tasawuf — SECONDARY (weight 2)
            ("taubat", FiqhDomain::Tasawuf, 2), ("tobat", FiqhDomain::Tasawuf, 2),
            ("ikhlas", FiqhDomain::Tasawuf, 2), ("riya", FiqhDomain::Tasawuf, 2),

            // Tafsir — PRIMARY (weight 3)
            ("tafsir", FiqhDomain::Tafsir, 3), ("quran", FiqhDomain::Tafsir, 3),
            // Tafsir — SECONDARY (weight 2)
            ("ayat", FiqhDomain::Tafsir, 2), ("surat", FiqhDomain::Tafsir, 2),

            // Hadits — PRIMARY (weight 3)
            ("hadits", FiqhDomain::Hadits, 3), ("hadis", FiqhDomain::Hadits, 3),
            ("hadith", FiqhDomain::Hadits, 3),
            // Hadits — SECONDARY (weight 2)
            ("sanad", FiqhDomain::Hadits, 2),

            // Food/health — CONTEXTUAL (weight 1)
            ("gelatin", FiqhDomain::Ibadah, 1), ("babi", FiqhDomain::Ibadah, 1),
            ("pork", FiqhDomain::Ibadah, 1), ("vaksin", FiqhDomain::Ibadah, 1),
            ("sakit", FiqhDomain::Ibadah, 1),

            // Akhlak
            ("adab", FiqhDomain::Akhlak, 3), ("akhlak", FiqhDomain::Akhlak, 3),

            // v15 batch 2: New domain keywords
            ("jamaah", FiqhDomain::Ibadah, 2), ("berjamaah", FiqhDomain::Ibadah, 2),
            ("jin", FiqhDomain::Aqidah, 2), ("sihir", FiqhDomain::Aqidah, 3),
            ("santet", FiqhDomain::Aqidah, 2), ("ruqyah", FiqhDomain::Aqidah, 2),
            ("cadar", FiqhDomain::Ibadah, 2), ("jilbab", FiqhDomain::Ibadah, 2),
            ("hijab", FiqhDomain::Ibadah, 2), ("niqab", FiqhDomain::Ibadah, 2),
            ("kiblat", FiqhDomain::Ibadah, 3), ("kentut", FiqhDomain::Ibadah, 2),
            ("jenggot", FiqhDomain::Ibadah, 2),
            ("tunangan", FiqhDomain::Munakahat, 2), ("taaruf", FiqhDomain::Munakahat, 2),
            ("janda", FiqhDomain::Munakahat, 2), ("mahar", FiqhDomain::Munakahat, 3),
            ("iddah", FiqhDomain::Munakahat, 3), ("nusyuz", FiqhDomain::Munakahat, 3),
            ("walimah", FiqhDomain::Munakahat, 2),
            ("bekam", FiqhDomain::Ibadah, 1), ("hijamah", FiqhDomain::Ibadah, 1),
            ("judi", FiqhDomain::Muamalat, 3), ("gambling", FiqhDomain::Muamalat, 3),
            ("zodiak", FiqhDomain::Aqidah, 2), ("horoskop", FiqhDomain::Aqidah, 2),
            ("dukun", FiqhDomain::Aqidah, 2), ("valentine", FiqhDomain::Aqidah, 2),
            ("natal", FiqhDomain::Aqidah, 2),
            ("narkoba", FiqhDomain::Jinayat, 2), ("ganja", FiqhDomain::Jinayat, 2),
            ("ikhtilat", FiqhDomain::Munakahat, 2),
            ("forex", FiqhDomain::Muamalat, 2), ("saham", FiqhDomain::Muamalat, 2),
            ("pinjaman", FiqhDomain::Muamalat, 2), ("obligasi", FiqhDomain::Muamalat, 2),
            ("dakwah", FiqhDomain::Akhlak, 2),
            ("kurban", FiqhDomain::Ibadah, 3), ("qurban", FiqhDomain::Ibadah, 3),
            ("aqiqah", FiqhDomain::Ibadah, 3), ("akikah", FiqhDomain::Ibadah, 3),
            ("dzikir", FiqhDomain::Ibadah, 2), ("zikir", FiqhDomain::Ibadah, 2),

            // v15 batch 3: Additional domain keywords
            ("tasyahud", FiqhDomain::Ibadah, 3), ("kutek", FiqhDomain::Thaharah, 2),
            ("plester", FiqhDomain::Thaharah, 2), ("cincin", FiqhDomain::Thaharah, 1),
            ("kuku", FiqhDomain::Thaharah, 1), ("mimpi", FiqhDomain::Thaharah, 2),
            ("akad", FiqhDomain::Muamalat, 2), ("cicilan", FiqhDomain::Muamalat, 2),
            ("paylater", FiqhDomain::Muamalat, 2), ("pinjol", FiqhDomain::Muamalat, 2),
            ("piercing", FiqhDomain::Muamalat, 1), ("tindik", FiqhDomain::Muamalat, 1),
            ("tato", FiqhDomain::Muamalat, 2), ("adopsi", FiqhDomain::Munakahat, 2),
            ("wasiat", FiqhDomain::Muamalat, 3), ("hibah", FiqhDomain::Muamalat, 3),
            ("transplantasi", FiqhDomain::Muamalat, 2),
            ("operasi", FiqhDomain::Muamalat, 1), ("cukur", FiqhDomain::Ibadah, 1),
            ("cosplay", FiqhDomain::Aqidah, 1), ("pemilu", FiqhDomain::Muamalat, 1),

            // v15 batch 4: English domain keywords
            ("prayer", FiqhDomain::Ibadah, 3), ("prayers", FiqhDomain::Ibadah, 3),
            ("worship", FiqhDomain::Ibadah, 3), ("fasting", FiqhDomain::Ibadah, 3),
            ("pilgrimage", FiqhDomain::Ibadah, 3), ("hajj", FiqhDomain::Ibadah, 3),
            ("alms", FiqhDomain::Ibadah, 3), ("tithe", FiqhDomain::Ibadah, 2),
            ("ablution", FiqhDomain::Thaharah, 3), ("purification", FiqhDomain::Thaharah, 3),
            ("ritual", FiqhDomain::Ibadah, 1), ("mosque", FiqhDomain::Ibadah, 2),
            ("congregation", FiqhDomain::Ibadah, 2), ("congregational", FiqhDomain::Ibadah, 2),
            ("funeral", FiqhDomain::Ibadah, 2), ("eclipse", FiqhDomain::Ibadah, 2),
            ("eid", FiqhDomain::Ibadah, 3), ("sacrifice", FiqhDomain::Ibadah, 2),
            ("marriage", FiqhDomain::Munakahat, 3), ("divorce", FiqhDomain::Munakahat, 3),
            ("wedding", FiqhDomain::Munakahat, 2), ("dowry", FiqhDomain::Munakahat, 3),
            ("custody", FiqhDomain::Munakahat, 2), ("guardian", FiqhDomain::Munakahat, 2),
            ("inheritance", FiqhDomain::Muamalat, 3), ("lease", FiqhDomain::Muamalat, 2),
            ("interest", FiqhDomain::Muamalat, 2), ("usury", FiqhDomain::Muamalat, 3),
            ("buying", FiqhDomain::Muamalat, 2), ("selling", FiqhDomain::Muamalat, 2),
            ("cryptocurrency", FiqhDomain::Muamalat, 2),
            ("insurance", FiqhDomain::Muamalat, 2), ("banking", FiqhDomain::Muamalat, 2),
            ("creed", FiqhDomain::Aqidah, 3), ("monotheism", FiqhDomain::Aqidah, 3),
            ("predestination", FiqhDomain::Aqidah, 3), ("apostasy", FiqhDomain::Aqidah, 3),
            ("jihad", FiqhDomain::Jinayat, 3), ("war", FiqhDomain::Jinayat, 2),
            ("treason", FiqhDomain::Jinayat, 2), ("punishment", FiqhDomain::Jinayat, 2),
            ("theft", FiqhDomain::Jinayat, 3), ("murder", FiqhDomain::Jinayat, 3),
            ("ethics", FiqhDomain::Akhlak, 3), ("morals", FiqhDomain::Akhlak, 3),
            ("manners", FiqhDomain::Akhlak, 2), ("etiquette", FiqhDomain::Akhlak, 2),
            ("commentary", FiqhDomain::Tafsir, 2), ("exegesis", FiqhDomain::Tafsir, 3),
            ("narration", FiqhDomain::Hadits, 2), ("narrator", FiqhDomain::Hadits, 2),
            ("vaping", FiqhDomain::Muamalat, 1), ("smoking", FiqhDomain::Muamalat, 1),
            ("photography", FiqhDomain::Muamalat, 1), ("silk", FiqhDomain::Muamalat, 1),
            ("gold", FiqhDomain::Muamalat, 1), ("women", FiqhDomain::Munakahat, 1),
            ("organ", FiqhDomain::Muamalat, 1), ("donation", FiqhDomain::Muamalat, 1),
            // Usul Fiqh
            ("istihsan", FiqhDomain::UsulFiqh, 3), ("istishab", FiqhDomain::UsulFiqh, 3),
            ("istidlal", FiqhDomain::UsulFiqh, 3), ("istinbath", FiqhDomain::UsulFiqh, 3),
            ("maqashid", FiqhDomain::UsulFiqh, 3), ("maqasid", FiqhDomain::UsulFiqh, 3),
            ("qiyas", FiqhDomain::UsulFiqh, 3), ("ijma", FiqhDomain::UsulFiqh, 3),
            ("ijtihad", FiqhDomain::UsulFiqh, 3), ("mujtahid", FiqhDomain::UsulFiqh, 2),
            ("tarjih", FiqhDomain::UsulFiqh, 3), ("illat", FiqhDomain::UsulFiqh, 2),
            ("nasikh", FiqhDomain::UsulFiqh, 3), ("mansukh", FiqhDomain::UsulFiqh, 3),
            ("naskh", FiqhDomain::UsulFiqh, 3), ("dzariah", FiqhDomain::UsulFiqh, 3),
            ("maslahah", FiqhDomain::UsulFiqh, 3), ("maslahat", FiqhDomain::UsulFiqh, 3),
            ("mutlaq", FiqhDomain::UsulFiqh, 2), ("muqayyad", FiqhDomain::UsulFiqh, 2),
            ("usul", FiqhDomain::UsulFiqh, 2), ("ushul", FiqhDomain::UsulFiqh, 2),
            ("dalil", FiqhDomain::UsulFiqh, 2), ("hujjah", FiqhDomain::UsulFiqh, 2),
            ("khilaf", FiqhDomain::UsulFiqh, 2), ("ikhtilaf", FiqhDomain::UsulFiqh, 2),
        ];

        for (keyword, domain, weight) in domain_map {
            self.domain_keywords.insert(keyword.to_string(), (domain, weight));
        }
    }
}

// ─── Utility Functions ───

fn is_arabic_char(c: char) -> bool {
    matches!(c,
        '\u{0600}'..='\u{06FF}' | // Arabic
        '\u{0750}'..='\u{077F}' | // Arabic Supplement
        '\u{08A0}'..='\u{08FF}' | // Arabic Extended-A
        '\u{FB50}'..='\u{FDFF}' | // Arabic Presentation Forms-A
        '\u{FE70}'..='\u{FEFF}'   // Arabic Presentation Forms-B
    )
}

fn strip_harakat(text: &str) -> String {
    text.chars()
        .filter(|c| !matches!(*c,
            '\u{064B}'..='\u{065F}' | // Arabic diacritics (fathah, dammah, kasrah, etc)
            '\u{0670}'              | // Small alef above
            '\u{06D6}'..='\u{06ED}'   // Other Arabic marks
        ))
        .collect()
}

fn tokenize_query(query: &str) -> Vec<String> {
    query
        .split(|c: char| c.is_whitespace() || c == '?' || c == '!' || c == ',' || c == '.')
        .filter(|s| !s.is_empty())
        .map(|s| s.to_string())
        .collect()
}

// ─── Long Query Intelligence ───

/// Extract question sentence(s) from long descriptive queries.
/// Returns (question_text, context_text). For queries with "description then question"
/// pattern, this isolates the actual question to prevent BM25 noise from context words.
fn extract_question_and_context(query: &str) -> (String, String) {
    let question_starters: &[&str] = &[
        "apakah", "bagaimana", "bolehkah", "gimana", "mengapa", "kenapa",
        "kapan", "dimana", "siapa", "bisakah", "haruskah", "perlukah",
        "maukah", "adakah", "dapatkan", "what", "how", "can ", "is it",
        "why", "when", "where", "who", "does", "should",
    ];

    let question_contains: &[&str] = &[
        "pertanyaannya", "yang ditanyakan", "yang saya tanyakan",
        "yang ingin saya tahu", "yang ingin ditanyakan",
        "hukumnya apa", "apa hukumnya", "bagaimana hukumnya",
        "boleh atau tidak", "sah atau tidak", "sah atau batal",
        "what is the ruling", "is it permissible",
    ];

    // Split into sentences by punctuation, tracking whether each ends with ?
    let mut sentences: Vec<(String, bool)> = Vec::new();
    let mut current = String::new();

    for c in query.chars() {
        if c == '?' || c == '.' || c == '!' || c == '\n' {
            let trimmed = current.trim().to_string();
            if !trimmed.is_empty() {
                let lower = trimmed.to_lowercase();
                let is_q = c == '?' ||
                    question_starters.iter().any(|m| lower.starts_with(m)) ||
                    question_contains.iter().any(|m| lower.contains(m));
                sentences.push((trimmed, is_q));
            }
            current = String::new();
        } else {
            current.push(c);
        }
    }
    // Last segment (no terminator)
    let trimmed = current.trim().to_string();
    if !trimmed.is_empty() {
        let lower = trimmed.to_lowercase();
        let is_q = question_starters.iter().any(|m| lower.starts_with(m)) ||
            question_contains.iter().any(|m| lower.contains(m));
        sentences.push((trimmed, is_q));
    }

    let mut question_parts: Vec<String> = Vec::new();
    let mut context_parts: Vec<String> = Vec::new();

    for (sent, is_q) in &sentences {
        if *is_q {
            question_parts.push(sent.clone());
        } else {
            context_parts.push(sent.clone());
        }
    }

    // If no question detected, use last sentence as question (common pattern)
    if question_parts.is_empty() && !context_parts.is_empty() {
        let last = context_parts.pop().unwrap();
        question_parts.push(last);
    }

    // If still empty (single sentence, no delimiters), treat whole as question
    if question_parts.is_empty() {
        return (query.to_string(), String::new());
    }

    (question_parts.join(" "), context_parts.join(" "))
}

// ─── Indonesian Morphological Root Extraction ───

/// Extract the Indonesian root word by stripping common prefixes and suffixes.
/// Indonesian has systematic affixation: me-/mem-/men-/meng-/meny- + ROOT + -kan/-an/-i
/// This dramatically expands effective dictionary coverage without adding every conjugation.
///
/// Examples:
///   "membatalkan" → "batal" (me+m+batal+kan)
///   "berwudhu"    → "wudhu" (ber+wudhu)
///   "menyembelih" → "sembelih" (meny→s+embelih)
///   "perbedaan"   → "beda" (per+beda+an)
///   "diharamkan"  → "haram" (di+haram+kan)
fn extract_indonesian_roots(word: &str) -> Vec<String> {
    let w = word.to_lowercase();
    if w.len() < 4 {
        return vec![];
    }

    let mut candidates = Vec::new();

    // ─── Handle Indonesian reduplication: karya-karya → karya, murid-murid → murid ───
    if let Some(idx) = w.find('-') {
        let first = &w[..idx];
        let second = &w[idx + 1..];
        if first.len() >= 3 {
            candidates.push(first.to_string());
        }
        if second.len() >= 3 && second != first {
            candidates.push(second.to_string());
        }
    }

    // Step 1: Strip suffixes first
    let suffixes: &[&str] = &["-nya", "nya", "kan", "an", "i"];
    let mut stems: Vec<String> = vec![w.clone()];

    for suffix in suffixes {
        if w.ends_with(suffix) && w.len() > suffix.len() + 2 {
            let stripped = w[..w.len() - suffix.len()].to_string();
            if stripped.len() >= 3 {
                stems.push(stripped);
            }
        }
    }

    // Step 2: Strip prefixes from each stem
    for stem in &stems {
        // ber- prefix
        if let Some(rest) = stem.strip_prefix("ber") {
            if rest.len() >= 3 { candidates.push(rest.to_string()); }
        }
        // per- prefix
        if let Some(rest) = stem.strip_prefix("per") {
            if rest.len() >= 3 { candidates.push(rest.to_string()); }
        }
        // pe- prefix (before -an suffix already stripped: "perbedaan" → "perbeda" → strip "per" → "beda")
        if let Some(rest) = stem.strip_prefix("pe") {
            if rest.len() >= 3 { candidates.push(rest.to_string()); }
        }
        // di- prefix
        if let Some(rest) = stem.strip_prefix("di") {
            if rest.len() >= 3 { candidates.push(rest.to_string()); }
        }
        // ter- prefix
        if let Some(rest) = stem.strip_prefix("ter") {
            if rest.len() >= 3 { candidates.push(rest.to_string()); }
        }
        // se- prefix
        if let Some(rest) = stem.strip_prefix("se") {
            if rest.len() >= 3 { candidates.push(rest.to_string()); }
        }
        // ke- prefix
        if let Some(rest) = stem.strip_prefix("ke") {
            if rest.len() >= 3 { candidates.push(rest.to_string()); }
        }
        // meny- prefix (root starts with s: menyembelih → sembelih)
        if let Some(rest) = stem.strip_prefix("meny") {
            if rest.len() >= 3 {
                candidates.push(format!("s{}", rest)); // meny + X → sX
                candidates.push(rest.to_string());
            }
        }
        // meng- prefix (root starts with vowel/g/h/k: mengerjakan → kerjakan/erjakan)
        else if let Some(rest) = stem.strip_prefix("meng") {
            if rest.len() >= 3 {
                candidates.push(rest.to_string());
                candidates.push(format!("k{}", rest)); // meng + X → kX
            }
        }
        // mem- prefix (root starts with b/f/p/v: membatalkan → batalkan)
        else if let Some(rest) = stem.strip_prefix("mem") {
            if rest.len() >= 3 {
                candidates.push(rest.to_string());
                candidates.push(format!("p{}", rest)); // mem + X → pX
            }
        }
        // men- prefix (root starts with d/t/c/j: mendengar → dengar, mentaati → taati)
        else if let Some(rest) = stem.strip_prefix("men") {
            if rest.len() >= 3 {
                candidates.push(rest.to_string());
                candidates.push(format!("t{}", rest)); // men + X → tX
            }
        }
        // me- prefix (general)
        else if let Some(rest) = stem.strip_prefix("me") {
            if rest.len() >= 3 { candidates.push(rest.to_string()); }
        }
    }

    // Step 3: For candidates that still have suffixes, strip again
    let mut final_roots = Vec::new();
    for c in &candidates {
        final_roots.push(c.clone());
        for suffix in &["kan", "an", "i"] {
            if c.ends_with(suffix) && c.len() > suffix.len() + 2 {
                let stripped = c[..c.len() - suffix.len()].to_string();
                if stripped.len() >= 3 {
                    final_roots.push(stripped);
                }
            }
        }
    }

    // Deduplicate and remove original word
    final_roots.sort();
    final_roots.dedup();
    final_roots.retain(|r| r != &w && r.len() >= 3);
    final_roots
}

// ─── Query Intent Pattern Detection ───

/// Detect semantic patterns in Indonesian queries and generate targeted Arabic phrases.
/// This captures higher-level query intent that individual word lookups miss.
///
/// Patterns detected:
///   "membatalkan X" / "yang membatalkan X" → مبطلات X / مفسدات X / نواقض X
///   "syarat sahnya X" → شروط صحة X / شروط X
///   "rukun X" → أركان X
///   "hikmah X" → حكمة X
///   "macam-macam X" / "jenis-jenis X" → أنواع X / أقسام X
fn detect_query_intent_patterns(words: &[String]) -> Vec<String> {
    let mut expansions = Vec::new();
    let lower: Vec<String> = words.iter().map(|w| w.to_lowercase()).collect();

    // Pattern: "membatalkan X" / "batal X" / "yang membatalkan"
    // → مبطلات / مفسدات / نواقض
    let cancel_words = ["membatalkan", "batalkan", "merusak", "merusakkan", "menggugurkan"];
    for cw in &cancel_words {
        if lower.iter().any(|w| w == cw || w.contains(cw)) {
            expansions.extend_from_slice(&[
                "مبطلات".to_string(), "مفسدات".to_string(), "نواقض".to_string(),
                "ما يبطل".to_string(), "ما يفسد".to_string(),
            ]);
            break;
        }
    }

    // Pattern: "syarat sah" / "syarat sahnya"
    if lower.iter().any(|w| w == "syarat" || w == "syaratnya") &&
       lower.iter().any(|w| w == "sah" || w == "sahnya" || w == "sahkah") {
        expansions.extend_from_slice(&[
            "شروط صحة".to_string(), "شروط".to_string(), "ما يشترط".to_string(),
        ]);
    }

    // Pattern: "macam" / "jenis" / "macam-macam"
    if lower.iter().any(|w| w == "macam" || w == "macam-macam" || w == "jenis" || w == "jenis-jenis") {
        expansions.extend_from_slice(&[
            "أنواع".to_string(), "أقسام".to_string(),
        ]);
    }

    // Pattern: "hikmah" / "wisdom"
    if lower.iter().any(|w| w == "hikmah" || w == "hikmat") {
        expansions.extend_from_slice(&[
            "حكمة".to_string(), "الحكمة".to_string(), "فوائد".to_string(),
        ]);
    }

    // Pattern: "perbedaan X dan Y" / "beda antara"
    if lower.iter().any(|w| w == "perbedaan" || w == "bedanya") {
        expansions.extend_from_slice(&[
            "الفرق".to_string(), "الفرق بين".to_string(),
        ]);
    }

    // Pattern: "tata cara" / "cara melakukan"
    if lower.iter().any(|w| w == "tatacara" || w == "caranya") ||
       (lower.iter().any(|w| w == "tata") && lower.iter().any(|w| w == "cara")) ||
       (lower.iter().any(|w| w == "cara") && lower.iter().any(|w| w == "melakukan" || w == "mengerjakan")) {
        expansions.extend_from_slice(&[
            "كيفية".to_string(), "صفة".to_string(),
        ]);
    }

    // Pattern: "hukum X bagi/untuk Y" → detect ruling inquiry
    // This overlaps with existing "hukum" mapping but adds nuance
    if lower.iter().any(|w| w == "hukumnya" || w == "hukumkah") {
        expansions.extend_from_slice(&[
            "حكم".to_string(), "أحكام".to_string(),
        ]);
    }

    // Pattern: "apakah boleh" / "boleh gak" / "boleh tidak" → permissibility
    if lower.iter().any(|w| w == "boleh" || w == "bolehkah") &&
       lower.iter().any(|w| w == "gak" || w == "tidak" || w == "nggak" || w == "apakah" || w == "ga") {
        expansions.extend_from_slice(&[
            "هل يجوز".to_string(), "جواز".to_string(), "حل".to_string(),
        ]);
    }

    // Pattern: "wajib atau sunnah" → classification
    if lower.iter().any(|w| w == "wajib") && lower.iter().any(|w| w == "sunnah" || w == "sunah") {
        expansions.extend_from_slice(&[
            "الوجوب والاستحباب".to_string(), "هل يجب".to_string(),
        ]);
    }

    // Pattern: "pakai/pake/memakai" → relates to clothing/wearing context
    if lower.iter().any(|w| w == "pakai" || w == "pake" || w == "memakai" || w == "mengenakan") {
        if lower.iter().any(|w| w == "shalat" || w == "solat" || w == "salat") {
            expansions.extend_from_slice(&[
                "لباس المصلي".to_string(), "ستر العورة".to_string(),
                "اللباس في الصلاة".to_string(),
            ]);
        }
    }

    // Pattern: "dimakan" / "boleh dimakan" / "halal dimakan" → food permissibility
    if lower.iter().any(|w| w == "dimakan" || w == "makan") &&
       lower.iter().any(|w| w == "boleh" || w == "halal" || w == "haram" || w == "gak" || w == "tidak") {
        expansions.extend_from_slice(&[
            "حكم أكل".to_string(), "حل الأكل".to_string(), "المحرمات من الطعام".to_string(),
        ]);
    }

    // Pattern: "gimana" / "gimana hukumnya" → how / ruling inquiry (colloquial)
    if lower.iter().any(|w| w == "gimana" || w == "bagaimana") {
        expansions.extend_from_slice(&[
            "كيف".to_string(), "حكم".to_string(),
        ]);
    }

    // Pattern: "sah gak" / "sah tidak" → validity question
    if lower.iter().any(|w| w == "sah" || w == "sahkah" || w == "sahnya") &&
       lower.iter().any(|w| w == "gak" || w == "tidak" || w == "nggak" || w == "ga" || w == "kah" || w == "apakah") {
        expansions.extend_from_slice(&[
            "صحة".to_string(), "هل يصح".to_string(), "شروط الصحة".to_string(),
        ]);
    }

    // Pattern: "termasuk" / "tergolong" → classification
    if lower.iter().any(|w| w == "termasuk" || w == "tergolong" || w == "apakah") {
        if lower.iter().any(|w| w == "riba" || w == "haram" || w == "najis" || w == "bid'ah" || w == "bidah" || w == "syirik") {
            expansions.extend_from_slice(&[
                "حكم".to_string(), "هل هو من".to_string(),
            ]);
        }
    }

    // Pattern: "kenapa diharamkan" / "kenapa haram" → reasoning behind prohibition
    if lower.iter().any(|w| w == "kenapa" || w == "mengapa" || w == "alasan") &&
       lower.iter().any(|w| w == "haram" || w == "diharamkan" || w == "dilarang") {
        expansions.extend_from_slice(&[
            "حكمة التحريم".to_string(), "علة التحريم".to_string(), "سبب التحريم".to_string(),
        ]);
    }

    // ═══ English intent patterns ═══

    // Pattern: "ruling on X" / "ruling of X" → حكم X
    if lower.iter().any(|w| w == "ruling") {
        expansions.extend_from_slice(&[
            "حكم".to_string(), "أحكام".to_string(),
        ]);
    }

    // Pattern: "is it permissible" / "is X allowed" / "is X halal" / "is X haram"
    if lower.iter().any(|w| w == "permissible" || w == "allowed" || w == "permitted" || w == "lawful") {
        expansions.extend_from_slice(&[
            "هل يجوز".to_string(), "جواز".to_string(), "حل".to_string(),
        ]);
    }

    // Pattern: "what invalidates X" / "things that break X"
    if lower.iter().any(|w| w == "invalidates" || w == "invalidate" || w == "nullifies" || w == "breaks" || w == "nullify") {
        expansions.extend_from_slice(&[
            "مبطلات".to_string(), "نواقض".to_string(), "ما يبطل".to_string(),
        ]);
    }

    // Pattern: "conditions of X" / "requirements for X"
    if lower.iter().any(|w| w == "conditions" || w == "requirements" || w == "prerequisites") {
        expansions.extend_from_slice(&[
            "شروط".to_string(), "الشروط".to_string(),
        ]);
    }

    // Pattern: "pillars of X" / "obligatory acts"
    if lower.iter().any(|w| w == "pillars" || w == "obligatory") {
        expansions.extend_from_slice(&[
            "أركان".to_string(), "واجبات".to_string(), "فرائض".to_string(),
        ]);
    }

    // Pattern: "types of X" / "categories of X"
    if lower.iter().any(|w| w == "types" || w == "categories" || w == "kinds" || w == "forms") {
        expansions.extend_from_slice(&[
            "أنواع".to_string(), "أقسام".to_string(),
        ]);
    }

    // Pattern: "how to perform X" / "how to do X" / "method of X"
    if lower.iter().any(|w| w == "perform" || w == "method" || w == "procedure") {
        expansions.extend_from_slice(&[
            "كيفية".to_string(), "صفة".to_string(),
        ]);
    }

    // Pattern: "difference between X and Y"
    if lower.iter().any(|w| w == "difference" || w == "distinction" || w == "versus" || w == "vs") {
        expansions.extend_from_slice(&[
            "الفرق".to_string(), "الفرق بين".to_string(),
        ]);
    }

    // Pattern: "wisdom behind X" / "reason for X"
    if lower.iter().any(|w| w == "wisdom" || w == "reason" || w == "rationale" || w == "purpose") {
        expansions.extend_from_slice(&[
            "حكمة".to_string(), "علة".to_string(),
        ]);
    }

    // Pattern: "is X valid" / "validity of X"
    if lower.iter().any(|w| w == "valid" || w == "validity" || w == "invalid") {
        expansions.extend_from_slice(&[
            "صحة".to_string(), "هل يصح".to_string(), "بطلان".to_string(),
        ]);
    }

    // Pattern: "prohibited" / "forbidden" / "haram"
    if lower.iter().any(|w| w == "prohibited" || w == "forbidden" || w == "haram" || w == "unlawful") {
        expansions.extend_from_slice(&[
            "تحريم".to_string(), "محرم".to_string(),
        ]);
    }

    // Pattern: "obligatory" / "mandatory" / "compulsory"
    if lower.iter().any(|w| w == "mandatory" || w == "compulsory" || w == "fard" || w == "wajib") {
        expansions.extend_from_slice(&[
            "وجوب".to_string(), "فرض".to_string(), "واجب".to_string(),
        ]);
    }

    // Pattern: "recommended" / "sunnah" / "encouraged"
    if lower.iter().any(|w| w == "recommended" || w == "encouraged" || w == "meritorious") {
        expansions.extend_from_slice(&[
            "مستحب".to_string(), "سنة".to_string(), "مندوب".to_string(),
        ]);
    }

    // ─── BATCH 17: Additional intent patterns ───

    // Pattern: "makna X" / "arti X" / "meaning of X" → definition/meaning context
    if lower.iter().any(|w| w == "makna" || w == "arti" || w == "artinya" || w == "meaning" || w == "definition") {
        expansions.extend_from_slice(&[
            "تعريف".to_string(), "معنى".to_string(), "مفهوم".to_string(),
        ]);
    }

    // Pattern: "manfaat X" / "benefit of X" / "benefits of X"
    if lower.iter().any(|w| w == "manfaat" || w == "faedah" || w == "benefit" || w == "benefits") {
        expansions.extend_from_slice(&[
            "فوائد".to_string(), "منافع".to_string(), "فضائل".to_string(),
        ]);
    }

    // Pattern: "bahaya X" / "danger/risk of X"
    if lower.iter().any(|w| w == "bahaya" || w == "mudharat" || w == "danger" || w == "risk" || w == "harm") {
        expansions.extend_from_slice(&[
            "مضار".to_string(), "مفاسد".to_string(), "أضرار".to_string(),
        ]);
    }

    // Pattern: "sejarah X" / "history of X"
    if lower.iter().any(|w| w == "sejarah" || w == "tarikh" || w == "history") {
        expansions.extend_from_slice(&[
            "تاريخ".to_string(), "نشأة".to_string(),
        ]);
    }

    // Pattern: "dalil X" / "evidence for X" / "proof of X"
    if lower.iter().any(|w| w == "dalil" || w == "dalilnya" || w == "evidence" || w == "proof" || w == "quran" || w == "hadits") {
        expansions.extend_from_slice(&[
            "دليل".to_string(), "الدليل".to_string(), "حجة".to_string(),
        ]);
    }

    // Pattern: "biografi X" / "siapakah X" / "riwayat hidup X" → biography
    if lower.iter().any(|w| w == "biografi" || w == "siapakah" || w == "siapa" || w == "profil" || w == "biography") {
        expansions.extend_from_slice(&[
            "ترجمة".to_string(), "سيرة".to_string(), "من هو".to_string(),
        ]);
    }

    // Pattern: "karya X" / "kitab X" / "buku X" → works/books
    if lower.iter().any(|w| w == "karya" || w == "karangan" || w == "tulisan" || w == "kitab") &&
       lower.iter().any(|w| w == "ibnu" || w == "imam" || w == "syaikh" || w == "al") {
        expansions.extend_from_slice(&[
            "مؤلفات".to_string(), "كتب".to_string(), "مصنفات".to_string(),
        ]);
    }

    // Pattern: "keutamaan X" / "fadilah X" / "virtue of X"
    if lower.iter().any(|w| w == "keutamaan" || w == "fadilah" || w == "fadhilah" || w == "virtue" || w == "merit") {
        expansions.extend_from_slice(&[
            "فضل".to_string(), "فضائل".to_string(), "ثواب".to_string(),
        ]);
    }

    // Pattern: "amalan X" / "practice of X" — sunnah acts
    if lower.iter().any(|w| w == "amalan" || w == "amal" || w == "practice" || w == "practices") {
        expansions.extend_from_slice(&[
            "أعمال".to_string(), "عمل".to_string(),
        ]);
    }

    // Pattern: "peristiwa penting X" / "events of X" — historical events
    if lower.iter().any(|w| w == "peristiwa" || w == "kejadian" || w == "events" || w == "event") {
        expansions.extend_from_slice(&[
            "أحداث".to_string(), "حوادث".to_string(), "وقائع".to_string(),
        ]);
    }

    // Pattern: "tentang X" → about X — general topic question
    if lower.iter().any(|w| w == "tentang" || w == "about" || w == "mengenai") {
        // Only add generic "بحث" (research/inquiry) if combined with Islamic terms
        if lower.iter().any(|w| ["shalat","puasa","zakat","haji","nikah","talak","riba","waris","fiqh","aqidah"].contains(&w.as_str())) {
            expansions.push("أحكام".to_string());
        }
    }

    expansions
}

/// Check if a word is a generic stopword that should not be single-word-expanded.
/// These are function words / pronouns / particles that would never be useful
/// search terms on their own. Content words (anak, suami, etc.) are NOT filtered
/// — they're handled by question extraction instead.
fn is_query_stopword(word: &str) -> bool {
    matches!(word,
        // Indonesian function words / pronouns / particles
        "saya" | "anda" | "kamu" | "kami" | "kita" | "mereka" | "dia" | "nya" |
        "yang" | "ini" | "itu" | "dan" | "atau" | "dari" | "untuk" | "dengan" |
        "di" | "ke" | "pada" | "oleh" | "dalam" | "juga" | "sudah" | "belum" |
        "bisa" | "akan" | "hanya" | "karena" | "tapi" | "tetapi" | "kalau" |
        "jika" | "maka" | "sedang" | "selama" | "setiap" | "sering" |
        "sampai" | "sekarang" | "sangat" | "selalu" | "tentu" | "pasti" |
        "lagi" | "masih" | "lalu" | "kemudian" | "pernah" |
        "dong" | "sih" | "deh" | "kok" | "yg" | "dgn" | "sdh" | "udah" |
        "gitu" | "gak" | "nggak" | "ngga" | "ga" | "enggak" |
        "seperti" | "bahwa" | "agar" | "supaya" | "namun" |
        "ada" | "punya" | "mau" | "harus" | "perlu" | "banyak" | "sedikit" |
        "soal" | "tentang" | "mengenai" | "terkait" |
        "kembali" | "menjadi" | "terhadap" | "antara" | "sekitar" |
        "jadi" | "ya" | "kan" | "tuh" | "sama" | "kadang" |
        "mungkin" | "tetap" | "terus" | "cuma" | "banget" |
        "begitu" | "demikian" | "tersebut" | "sebuah" | "suatu" |
        // English function words
        "the" | "a" | "an" | "is" | "are" | "was" | "were" | "be" | "been" |
        "have" | "has" | "had" | "do" | "does" | "did" | "would" |
        "could" | "should" | "may" | "might" | "must" | "shall" | "can" |
        "i" | "you" | "he" | "she" | "it" | "we" | "they" | "me" | "him" |
        "her" | "us" | "them" | "my" | "your" | "his" | "its" | "our" | "their" |
        "this" | "that" | "these" | "those" |
        "if" | "then" | "than" | "but" |
        "and" | "or" | "not" | "no" | "so" | "just" | "also" | "very" |
        "with" | "from" | "for" | "to" | "of" | "in" | "on" | "at" | "by" |
        "about" | "some" | "any" | "all" | "each" | "every" | "many" |
        "much" | "more" | "most" | "there" | "here" | "now" |
        "still" | "already" | "always" | "never" | "often" | "sometimes" |
        "because" | "since" | "while" | "although" | "though" | "however" |
        "well" | "too" | "really" | "quite" | "need" | "want" | "get" |
        "got" | "make" | "made" | "know" | "think" | "see" | "come" |
        "go" | "take" | "give" | "tell" | "say" | "said"
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_detect_indonesian() {
        let t = QueryTranslator::new();
        assert_eq!(t.detect_language("apa hukum shalat jumat"), QueryLang::Indonesian);
    }

    #[test]
    fn test_detect_arabic() {
        let t = QueryTranslator::new();
        assert_eq!(t.detect_language("ما حكم صلاة الجمعة"), QueryLang::Arabic);
    }

    #[test]
    fn test_detect_english() {
        let t = QueryTranslator::new();
        assert_eq!(t.detect_language("what is the ruling on friday prayer"), QueryLang::English);
    }

    #[test]
    fn test_expand_shalat() {
        let t = QueryTranslator::new();
        let result = t.translate("shalat jumat");
        assert!(!result.arabic_terms.is_empty());
        assert!(result.arabic_terms.iter().any(|t| t.contains("صلاة")));
        assert!(result.arabic_terms.iter().any(|t| t.contains("الجمعة")));
    }

    #[test]
    fn test_expand_nikah_siri() {
        let t = QueryTranslator::new();
        let result = t.translate("hukum nikah siri");
        assert!(result.arabic_terms.iter().any(|t| t.contains("نكاح")));
    }

    #[test]
    fn test_arabic_passthrough() {
        let t = QueryTranslator::new();
        let result = t.translate("حكم صلاة الجمعة");
        assert_eq!(result.detected_language, QueryLang::Arabic);
        assert!(!result.arabic_terms.is_empty());
    }

    #[test]
    fn test_long_query_term_reduction() {
        let t = QueryTranslator::new();
        // Long descriptive query followed by question
        let long_q = "Saya punya anak kecil yang masih bayi, umurnya baru 8 bulan. \
            Setiap kali saya shalat, anak saya sering digendong oleh istri saya. \
            Tapi kadang kalau istri saya sedang masak, saya harus shalat sambil \
            menggendong bayi tersebut. Yang jadi masalah, kadang popok bayi basah \
            dan saya khawatir ada najis yang mengenai baju saya saat shalat. \
            Pertanyaannya, apakah shalat saya tetap sah kalau menggendong bayi \
            yang popoknya mungkin terkena najis?";
        let result = t.translate(long_q);
        // Should have significantly fewer terms than processing every word
        assert!(result.arabic_terms.len() <= MAX_ARABIC_TERMS,
            "Long query should be capped: got {} terms", result.arabic_terms.len());
        // Must still find the core concepts
        assert!(result.arabic_terms.iter().any(|t| t.contains("صلاة") || t.contains("الصلاة")),
            "Must find salat");
        assert!(result.arabic_terms.iter().any(|t| t.contains("نجاسة") || t.contains("النجس")),
            "Must find najis");
    }

    #[test]
    fn test_question_extraction() {
        let (q, c) = extract_question_and_context(
            "Saya punya masalah tentang wudhu. Apakah boleh menyapu perban?"
        );
        assert!(q.to_lowercase().contains("apakah"), "Should extract question: got '{}'", q);
        assert!(c.to_lowercase().contains("masalah"), "Context should have description: got '{}'", c);
    }

    #[test]
    fn test_short_query_unchanged() {
        let t = QueryTranslator::new();
        // Short queries should still expand all words
        let result = t.translate("hukum shalat duduk");
        assert!(result.arabic_terms.iter().any(|t| t.contains("صلاة")));
        assert!(result.arabic_terms.iter().any(|t| t.contains("جالس") || t.contains("قاعد")));
    }
}
